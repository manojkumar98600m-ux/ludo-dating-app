# Ludo Dating App ❤️
A complete, mobile-first Ludo Dating application with 2–4 player tournament board logic, 18+ profile matchmaking, direct messaging with photos/voice, 1-on-1 WebRTC voice and video calls, WebSockets online rooms, PWA installability, and an administrative dashboard.

## VIP Membership Launch Pricing
- Original Price: ₹199 for 6 months
- Launch Discount: 75% OFF
- Offer Price: ₹50 for 6 months
- Terms: One-time payment (No auto-renewal or recurring charges)

## How to Run Locally
1. Install dependencies:
   ```bash
   npm install
   ```
2. Run development server:
   ```bash
   npm run dev
   ```
3. Open in your browser:
   ```
   http://localhost:3000
   ```

## How to Build Android APK with Capacitor
1. Install Capacitor CLI:
   ```bash
   npm install @capacitor/core @capacitor/cli @capacitor/android
   ```
2. Initialize Capacitor:
   ```bash
   npx cap init "Ludo Dating App" "com.ludodating.app" --web-dir dist
   ```
3. Build web assets:
   ```bash
   npm run build
   ```
4. Add Android platform:
   ```bash
   npx cap add android
   npx cap sync android
   ```
5. Open in Android Studio & Generate APK:
   ```bash
   npx cap open android
   ```
   In Android Studio, click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
