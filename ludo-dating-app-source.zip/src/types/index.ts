export type PlayerColor = 'red' | 'green' | 'yellow' | 'blue';

export interface Token {
  id: number; // 0..3
  color: PlayerColor;
  step: number; // -1 = in home yard, 0..50 = on outer track, 51..55 = colored home path, 56 = finished!
  finished: boolean;
}

export interface LudoPlayer {
  id: string; // userId or botId
  name: string;
  avatar: string;
  color: PlayerColor;
  isBot?: boolean;
  isHost?: boolean;
  tokens: Token[];
  hasRolled?: boolean;
  hasFinished?: boolean;
  rank?: number;
}

export interface GameState {
  roomId?: string;
  mode: 'local' | 'online' | 'bot';
  playerCount: 2 | 3 | 4;
  players: LudoPlayer[];
  currentTurnIndex: number;
  diceValue: number | null;
  hasRolled: boolean;
  validTokenMoves: number[]; // token indices that can move
  status: 'waiting' | 'playing' | 'ended';
  winner?: LudoPlayer;
  turnTimeLeft: number;
  turnDuration: number;
  lastActionLog: string;
  consecutiveSixes: number;
  moveHistory: {
    player: string;
    action: string;
    timestamp: number;
  }[];
}

export interface PrivacySettings {
  showOnlineStatus: boolean;
  showLastSeen: boolean;
  allowCallsFrom: 'everyone' | 'friends_and_matches' | 'friends_only';
  allowMessagesFrom: 'everyone' | 'matches_only' | 'friends_only';
  profileVisibility: 'public' | 'friends_only' | 'hidden';
}

export interface User {
  id: string;
  username: string;
  email: string;
  age: number; // 18+ required
  gender: 'female' | 'male' | 'non-binary' | 'other';
  lookingFor: 'all' | 'men' | 'women' | 'everyone';
  bio: string;
  photoUrl: string;
  interests: string[];
  city: string;
  coins: number;
  vipTier: 'none' | 'gold' | 'cupid';
  createdAt: string;
  lastSeen?: string;
  isOnline?: boolean;
  isBanned?: boolean;
  isAdmin?: boolean;
  privacy: PrivacySettings;
}

export interface DatingProfile extends User {
  distanceKm: number;
  ludoWins: number;
  ludoGames: number;
  matchCompatibility: number;
  isLiked?: boolean;
}

export interface Match {
  id: string;
  users: [string, string];
  otherUser: User;
  matchedAt: string;
  lastMessage?: string;
  lastMessageTime?: string;
  unreadCount?: number;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  recipientId: string;
  roomId?: string;
  text: string;
  photoUrl?: string; // photo attachment
  audioUrl?: string; // voice message audio
  giftType?: string;
  gameInviteRoomId?: string;
  status: 'sent' | 'delivered' | 'read';
  timestamp: string;
}

export interface FriendRelationship {
  id: string;
  fromUserId: string;
  toUserId: string;
  status: 'pending' | 'accepted' | 'declined';
  createdAt: string;
  otherUser: User;
}

export interface CallRecord {
  id: string;
  callerId: string;
  callerName: string;
  callerAvatar: string;
  receiverId: string;
  receiverName: string;
  receiverAvatar: string;
  callType: 'voice' | 'video';
  status: 'missed' | 'completed' | 'declined';
  durationSeconds: number;
  timestamp: string;
}

export interface ActiveCallState {
  callId: string;
  peerUser: User;
  callType: 'voice' | 'video';
  isIncoming: boolean;
  status: 'ringing' | 'connected' | 'ended';
  isMuted: boolean;
  isVideoOff: boolean;
  durationSeconds: number;
}

export interface ReportItem {
  id: string;
  reporterId: string;
  reporterName: string;
  targetUserId: string;
  targetUserName: string;
  reason: string;
  details: string;
  timestamp: string;
  status: 'pending' | 'resolved' | 'dismissed';
}

export interface SubscriptionRecord {
  id: string;
  userId: string;
  userName: string;
  planName: string;
  originalPriceInr: number;
  finalPriceInr: number;
  discountPercent: number;
  duration: string;
  autoRenew: false;
  coinsGranted: number;
  status: 'completed' | 'refunded';
  purchasedAt: string;
}
