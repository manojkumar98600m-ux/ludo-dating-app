/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Match, User } from './types';
import { api } from './services/api';
import { sound } from './services/sound';
import { LocalLudoGame } from './components/ludo/LocalLudoGame';
import { OnlineLudoGame } from './components/ludo/OnlineLudoGame';
import { DatingDiscovery } from './components/dating/DatingDiscovery';
import { MatchesAndChat } from './components/dating/MatchesAndChat';
import { FriendsView } from './components/friends/FriendsView';
import { UserProfileModal } from './components/profile/UserProfileModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { ReportModal } from './components/safety/ReportModal';
import { AuthModal } from './components/auth/AuthModal';
import { CallModal } from './components/calling/CallModal';
import {
  Dices,
  Heart,
  MessageCircle,
  Users,
  User as UserIcon,
  Crown,
  Volume2,
  VolumeX,
  Radio,
  Coins,
  Download,
  Sparkles,
  Smartphone,
  X,
} from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [activeTab, setActiveTab] = useState<'ludo' | 'dating' | 'friends' | 'chat' | 'profile'>('ludo');

  // Ludo sub-mode: local vs online multiplayer room
  const [ludoMode, setLudoMode] = useState<'local' | 'online'>('local');
  const [onlineRoomCode, setOnlineRoomCode] = useState<string>('');

  // Selected chat match
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);

  // Active 1-on-1 WebRTC Voice/Video Call
  const [activeCall, setActiveCall] = useState<{
    peerUser: { id: string; username: string; photoUrl: string };
    callType: 'voice' | 'video';
    isIncoming: boolean;
  } | null>(null);

  // Modals
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [reportTarget, setReportTarget] = useState<{ id: string; username: string } | null>(null);

  // Global sound toggle & PWA prompt
  const [isMuted, setIsMuted] = useState(false);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [installPrompt, setInstallPrompt] = useState<any>(null);
  const [showVipBanner, setShowVipBanner] = useState<boolean>(true);

  // Persistent App WebSocket for Call Signaling and Presence
  const appSocketRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    checkAuth();

    // Listen for PWA beforeinstallprompt on Android Chrome
    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
  }, []);

  // Connect App-level WebSocket for presence & calls
  useEffect(() => {
    if (!currentUser) return;

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);
    appSocketRef.current = ws;

    ws.onopen = () => {
      const token = api.getToken();
      if (token) {
        ws.send(JSON.stringify({ type: 'auth', token }));
      }
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'call:incoming') {
          sound.playNotification();
          setActiveCall({
            peerUser: data.caller,
            callType: data.callType || 'voice',
            isIncoming: true,
          });
        }
      } catch (e) {
        console.error(e);
      }
    };

    return () => {
      ws.close();
    };
  }, [currentUser]);

  const checkAuth = async () => {
    const token = api.getToken();
    if (token) {
      try {
        const res = await api.getMe();
        setCurrentUser(res.user);
      } catch {
        api.clearSession();
        // Fallback to quick demo user Maya
        await handleSwitchUser('user-maya');
      }
    } else {
      await handleSwitchUser('user-maya');
    }
    setAuthChecked(true);
  };

  const handleSwitchUser = async (userId: string) => {
    try {
      const res = await api.quickSwitch(userId);
      setCurrentUser(res.user);
      sound.playNotification();
    } catch (err) {
      console.error(err);
    }
  };

  const handleLogout = () => {
    api.clearSession();
    setCurrentUser(null);
    setShowProfileModal(false);
  };

  const handleToggleMute = () => {
    const next = !isMuted;
    setIsMuted(next);
    sound.setMuted(next);
  };

  const handleInstallPWA = async () => {
    if (!installPrompt) return;
    installPrompt.prompt();
    const { outcome } = await installPrompt.userChoice;
    if (outcome === 'accepted') {
      setInstallPrompt(null);
    }
  };

  // Launch online room from Chat or Match
  const handleStartLudoWithRoom = (roomCode: string) => {
    setOnlineRoomCode(roomCode);
    setLudoMode('online');
    setActiveTab('ludo');
  };

  const handleInviteToLudo = (otherUserId: string) => {
    const generatedCode = `LOVE-${Math.floor(1000 + Math.random() * 9000)}`;
    setOnlineRoomCode(generatedCode);
    setLudoMode('online');
    setActiveTab('ludo');
  };

  // Start outgoing call to peer
  const handleStartCall = (targetUser: User, callType: 'voice' | 'video') => {
    if (!appSocketRef.current || appSocketRef.current.readyState !== WebSocket.OPEN) {
      alert('Connecting to live call service. Please retry in a moment.');
      return;
    }

    sound.playStep();
    appSocketRef.current.send(
      JSON.stringify({
        type: 'call:initiate',
        receiverId: targetUser.id,
        callType,
      })
    );

    setActiveCall({
      peerUser: targetUser,
      callType,
      isIncoming: false,
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-rose-500 selection:text-white">
      {/* Top Mobile-First App Header */}
      <header className="sticky top-0 z-40 bg-slate-950/85 backdrop-blur-md border-b border-slate-800/80 px-3.5 py-2.5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-rose-500 to-amber-500 flex items-center justify-center shadow-md shadow-rose-500/20">
            <Heart className="w-4 h-4 text-white fill-current" />
          </div>
          <div>
            <span className="text-sm font-black tracking-tight text-white flex items-center gap-1">
              <span>Ludo Dating App</span>
              <span className="text-[10px] bg-rose-500/20 text-rose-300 font-bold px-1.5 py-0.2 rounded border border-rose-500/30">
                18+
              </span>
            </span>
          </div>
        </div>

        {/* Right Header Badges & Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Direct 1-Tap Source Code ZIP Download */}
          <a
            href="/api/download-zip"
            download="ludo-dating-app-source.zip"
            className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900 border border-slate-800 hover:border-rose-500/50 text-xs font-bold text-slate-200 shadow-inner transition active:scale-95 cursor-pointer"
            title="Download Complete Source Code ZIP"
          >
            <Download className="w-3.5 h-3.5 text-rose-400" />
            <span className="text-[11px]">ZIP</span>
          </a>

          {/* Virtual Coins Pill */}
          <button
            onClick={() => setShowProfileModal(true)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900 border border-slate-800 hover:border-amber-500/50 text-xs font-bold text-amber-300 shadow-inner cursor-pointer transition"
            title="Virtual Coins Balance"
          >
            <Coins className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-mono">{currentUser?.coins || 1000}</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={handleToggleMute}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white cursor-pointer transition"
            title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>

          {/* Admin Dashboard Quick Button */}
          {currentUser?.isAdmin && (
            <button
              onClick={() => setShowAdminModal(true)}
              className="p-1.5 rounded-xl bg-purple-950/80 border border-purple-500/40 text-purple-300 hover:text-white cursor-pointer shadow-sm transition"
              title="Admin Dashboard"
            >
              <Crown className="w-4 h-4 text-amber-300" />
            </button>
          )}

          {/* Profile Avatar Button */}
          {currentUser && (
            <button
              onClick={() => setShowProfileModal(true)}
              className="relative cursor-pointer hover:scale-105 transition"
              title="Open Profile"
            >
              <img
                src={currentUser.photoUrl}
                alt={currentUser.username}
                className="w-8 h-8 rounded-full object-cover border-2 border-rose-500 shadow"
              />
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border border-slate-950" />
            </button>
          )}
        </div>
      </header>

      {/* Special Launch Promotion VIP Banner */}
      {showVipBanner && (
        <div className="bg-gradient-to-r from-rose-900/90 via-pink-900/90 to-purple-900/90 border-b border-rose-500/30 px-3.5 py-1.5 flex items-center justify-between text-xs backdrop-blur-md">
          <div className="flex items-center gap-2 truncate">
            <Sparkles className="w-3.5 h-3.5 text-amber-300 flex-shrink-0 animate-pulse" />
            <div className="truncate">
              <strong className="text-white font-bold">🚀 Launch Offer:</strong>{' '}
              <span className="text-slate-300 line-through">₹199</span>{' '}
              <strong className="text-amber-300 font-extrabold font-mono">₹50 for 6 Months</strong>{' '}
              <span className="text-rose-200 text-[10px] font-medium hidden sm:inline">
                (75% OFF · No Auto-Renew)
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              onClick={() => setShowProfileModal(true)}
              className="px-2.5 py-0.5 rounded-full bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-[10px] shadow cursor-pointer transition active:scale-95"
            >
              Get VIP
            </button>
            <button
              onClick={() => setShowVipBanner(false)}
              className="text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* PWA In-App Install Prompt Banner (Android Chrome) */}
      {installPrompt && (
        <div className="bg-gradient-to-r from-blue-950/90 to-indigo-950/90 border-b border-blue-500/30 px-3.5 py-2 flex items-center justify-between text-xs backdrop-blur-md">
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-blue-400 flex-shrink-0 animate-bounce" />
            <span className="text-white font-bold">Install Ludo Dating App on Android Home Screen</span>
          </div>
          <button
            onClick={handleInstallPWA}
            className="px-3 py-1 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md cursor-pointer transition active:scale-95"
          >
            Install
          </button>
        </div>
      )}

      {/* Main Screen Content */}
      <main className="flex-1 pb-20 overflow-y-auto">
        {/* Tab 1: Play Ludo */}
        {activeTab === 'ludo' && (
          <div className="flex flex-col gap-2">
            <div className="max-w-md mx-auto w-full px-3 pt-2">
              <div className="flex rounded-2xl bg-slate-900 p-1 border border-slate-800 text-xs font-bold shadow-md">
                <button
                  onClick={() => setLudoMode('local')}
                  className={`flex-1 py-2 rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                    ludoMode === 'local'
                      ? 'bg-gradient-to-r from-amber-500 to-rose-500 text-white shadow-md'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Dices className="w-4 h-4" />
                  <span>Play Local & AI</span>
                </button>
                <button
                  onClick={() => setLudoMode('online')}
                  className={`flex-1 py-2 rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                    ludoMode === 'online'
                      ? 'bg-gradient-to-r from-rose-600 to-purple-600 text-white shadow-md'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
                  <span>Online Rooms & Voice</span>
                </button>
              </div>
            </div>

            {ludoMode === 'local' ? (
              <LocalLudoGame
                currentUser={currentUser}
                onNavigateToDating={() => setActiveTab('dating')}
              />
            ) : (
              <OnlineLudoGame
                currentUser={currentUser}
                initialRoomCode={onlineRoomCode}
                onExit={() => {
                  setLudoMode('local');
                  setOnlineRoomCode('');
                }}
              />
            )}
          </div>
        )}

        {/* Tab 2: Dating Discovery */}
        {activeTab === 'dating' && (
          <DatingDiscovery
            currentUser={currentUser}
            onOpenChatWithMatch={(m) => {
              setSelectedMatch(m);
              setActiveTab('chat');
            }}
            onInviteToLudo={handleInviteToLudo}
            onReportUser={(profile) => setReportTarget(profile)}
          />
        )}

        {/* Tab 3: Online Friends */}
        {activeTab === 'friends' && currentUser && (
          <FriendsView
            currentUser={currentUser}
            onOpenChat={(otherUserId) => {
              setActiveTab('chat');
            }}
            onStartCall={handleStartCall}
            onInviteToLudo={handleInviteToLudo}
          />
        )}

        {/* Tab 4: Chats & Matches */}
        {activeTab === 'chat' && (
          <MatchesAndChat
            currentUser={currentUser}
            selectedMatch={selectedMatch}
            onSelectMatch={setSelectedMatch}
            onStartLudoWithRoom={handleStartLudoWithRoom}
            onStartCall={handleStartCall}
            onReportUser={(other) => setReportTarget(other)}
            onUserCoinsUpdated={(coins) => {
              if (currentUser) {
                setCurrentUser({ ...currentUser, coins });
              }
            }}
          />
        )}

        {/* Tab 5: Profile & Settings */}
        {activeTab === 'profile' && currentUser && (
          <div className="max-w-md mx-auto w-full p-4">
            <UserProfileModal
              user={currentUser}
              onClose={() => setActiveTab('ludo')}
              onUpdateUser={setCurrentUser}
              onSwitchUser={handleSwitchUser}
              onLogout={handleLogout}
              onOpenAdmin={() => setShowAdminModal(true)}
            />
          </div>
        )}
      </main>

      {/* Bottom Sticky Mobile Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-lg border-t border-slate-800 px-3 py-2 flex items-center justify-around max-w-lg mx-auto shadow-2xl">
        <button
          onClick={() => {
            sound.playStep();
            setActiveTab('ludo');
          }}
          className={`flex flex-col items-center gap-1 py-1 px-2.5 rounded-2xl transition cursor-pointer ${
            activeTab === 'ludo'
              ? 'text-rose-400 font-bold scale-105'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Dices className="w-5 h-5" />
          <span className="text-[10px]">Ludo</span>
        </button>

        <button
          onClick={() => {
            sound.playStep();
            setActiveTab('dating');
          }}
          className={`flex flex-col items-center gap-1 py-1 px-2.5 rounded-2xl transition cursor-pointer ${
            activeTab === 'dating'
              ? 'text-rose-400 font-bold scale-105'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Heart className="w-5 h-5 fill-current" />
          <span className="text-[10px]">Dating</span>
        </button>

        <button
          onClick={() => {
            sound.playStep();
            setActiveTab('friends');
          }}
          className={`flex flex-col items-center gap-1 py-1 px-2.5 rounded-2xl transition cursor-pointer ${
            activeTab === 'friends'
              ? 'text-rose-400 font-bold scale-105'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Users className="w-5 h-5" />
          <span className="text-[10px]">Friends</span>
        </button>

        <button
          onClick={() => {
            sound.playStep();
            setActiveTab('chat');
          }}
          className={`flex flex-col items-center gap-1 py-1 px-2.5 rounded-2xl transition cursor-pointer ${
            activeTab === 'chat'
              ? 'text-rose-400 font-bold scale-105'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <MessageCircle className="w-5 h-5" />
          <span className="text-[10px]">Chats</span>
        </button>

        <button
          onClick={() => {
            sound.playStep();
            setShowProfileModal(true);
          }}
          className={`flex flex-col items-center gap-1 py-1 px-2.5 rounded-2xl transition cursor-pointer ${
            showProfileModal
              ? 'text-rose-400 font-bold scale-105'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <UserIcon className="w-5 h-5" />
          <span className="text-[10px]">Profile</span>
        </button>
      </nav>

      {/* Active 1-on-1 Voice or Video Call Screen */}
      {activeCall && currentUser && (
        <CallModal
          currentUser={currentUser}
          peerUser={activeCall.peerUser}
          callType={activeCall.callType}
          isIncoming={activeCall.isIncoming}
          onAcceptCall={() => {}}
          onRejectCall={() => setActiveCall(null)}
          onEndCall={() => setActiveCall(null)}
          socket={appSocketRef.current}
        />
      )}

      {/* Modals */}
      {authChecked && !currentUser && (
        <AuthModal
          onSuccess={(u) => {
            setCurrentUser(u);
            sound.playVictory();
          }}
        />
      )}

      {showProfileModal && currentUser && (
        <UserProfileModal
          user={currentUser}
          onClose={() => setShowProfileModal(false)}
          onUpdateUser={setCurrentUser}
          onSwitchUser={handleSwitchUser}
          onLogout={handleLogout}
          onOpenAdmin={() => setShowAdminModal(true)}
        />
      )}

      {showAdminModal && currentUser && (
        <AdminDashboard
          currentUser={currentUser}
          onClose={() => setShowAdminModal(false)}
          onUserSubscribed={(updatedUser) => setCurrentUser(updatedUser)}
        />
      )}

      {reportTarget && (
        <ReportModal
          targetUser={reportTarget}
          onClose={() => setReportTarget(null)}
          onUserBlocked={() => {
            setReportTarget(null);
            alert(`${reportTarget.username} has been blocked.`);
          }}
        />
      )}
    </div>
  );
}
