import React, { useState, useEffect, useRef } from 'react';
import { User } from '../../types';
import { sound } from '../../services/sound';
import {
  Mic,
  MicOff,
  Video,
  VideoOff,
  PhoneOff,
  Phone,
  ShieldCheck,
  User as UserIcon,
} from 'lucide-react';

interface CallModalProps {
  currentUser: User;
  peerUser: { id: string; username: string; photoUrl: string };
  callType: 'voice' | 'video';
  isIncoming: boolean;
  onAcceptCall: () => void;
  onRejectCall: () => void;
  onEndCall: (durationSeconds: number) => void;
  socket: WebSocket | null;
}

export const CallModal: React.FC<CallModalProps> = ({
  currentUser,
  peerUser,
  callType,
  isIncoming,
  onAcceptCall,
  onRejectCall,
  onEndCall,
  socket,
}) => {
  const [callStatus, setCallStatus] = useState<'ringing' | 'connected'>('ringing');
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(callType === 'voice');
  const [duration, setDuration] = useState(0);

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const rtcConfig: RTCConfiguration = {
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
    ],
  };

  // Start call session
  useEffect(() => {
    // Ringtone sound
    const ringInterval = setInterval(() => {
      if (callStatus === 'ringing') {
        sound.playNotification();
      }
    }, 2000);

    return () => clearInterval(ringInterval);
  }, [callStatus]);

  // Handle call timer when connected
  useEffect(() => {
    if (callStatus === 'connected') {
      timerRef.current = setInterval(() => {
        setDuration((prev) => prev + 1);
      }, 1000);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [callStatus]);

  // Setup WebRTC media stream
  const initializeMedia = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: callType === 'video',
      });
      localStreamRef.current = stream;

      if (localVideoRef.current && callType === 'video') {
        localVideoRef.current.srcObject = stream;
      }

      const pc = new RTCPeerConnection(rtcConfig);
      peerConnectionRef.current = pc;

      stream.getTracks().forEach((track) => pc.addTrack(track, stream));

      pc.ontrack = (event) => {
        if (remoteVideoRef.current) {
          remoteVideoRef.current.srcObject = event.streams[0];
        }
      };

      pc.onicecandidate = (event) => {
        if (event.candidate && socket?.readyState === WebSocket.OPEN) {
          socket.send(
            JSON.stringify({
              type: 'call:signal',
              targetUserId: peerUser.id,
              signal: { candidate: event.candidate },
            })
          );
        }
      };

      // If caller, send offer
      if (!isIncoming) {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        socket?.send(
          JSON.stringify({
            type: 'call:signal',
            targetUserId: peerUser.id,
            signal: { description: pc.localDescription },
          })
        );
      }
    } catch (err) {
      console.warn('Media devices access error:', err);
    }
  };

  // Listen for incoming call signals on socket
  useEffect(() => {
    if (!socket) return;

    const handleMessage = async (event: MessageEvent) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'call:accepted') {
          setCallStatus('connected');
          sound.playStep();
          await initializeMedia();
        } else if (data.type === 'call:rejected' || data.type === 'call:ended') {
          cleanup();
          onEndCall(duration);
        } else if (data.type === 'call:signal') {
          const pc = peerConnectionRef.current;
          if (data.signal?.description && pc) {
            await pc.setRemoteDescription(new RTCSessionDescription(data.signal.description));
            if (data.signal.description.type === 'offer') {
              const answer = await pc.createAnswer();
              await pc.setLocalDescription(answer);
              socket.send(
                JSON.stringify({
                  type: 'call:signal',
                  targetUserId: peerUser.id,
                  signal: { description: pc.localDescription },
                })
              );
            }
          } else if (data.signal?.candidate && pc) {
            await pc.addIceCandidate(new RTCIceCandidate(data.signal.candidate));
          }
        }
      } catch (e) {
        console.error(e);
      }
    };

    socket.addEventListener('message', handleMessage);
    return () => socket.removeEventListener('message', handleMessage);
  }, [socket, peerUser.id, duration]);

  const handleAccept = async () => {
    setCallStatus('connected');
    onAcceptCall();
    await initializeMedia();
  };

  const cleanup = () => {
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop());
      localStreamRef.current = null;
    }
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
      peerConnectionRef.current = null;
    }
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const handleHangup = () => {
    cleanup();
    socket?.send(
      JSON.stringify({
        type: 'call:hangup',
        otherUserId: peerUser.id,
        callType,
        durationSeconds: duration,
      })
    );
    onEndCall(duration);
  };

  const toggleMute = () => {
    if (localStreamRef.current) {
      const audioTrack = localStreamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsMuted(!audioTrack.enabled);
      }
    }
  };

  const toggleVideo = () => {
    if (localStreamRef.current) {
      const videoTrack = localStreamRef.current.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsVideoOff(!videoTrack.enabled);
      }
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-xl flex flex-col items-center justify-between p-6">
      {/* Top Header */}
      <div className="w-full max-w-sm flex items-center justify-between">
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-[11px] font-semibold text-emerald-400">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>End-to-End Encrypted</span>
        </div>
        <div className="text-xs font-mono font-bold text-slate-300">
          {callStatus === 'connected' ? formatTime(duration) : 'Ringing...'}
        </div>
      </div>

      {/* Main Body */}
      <div className="flex-1 w-full max-w-sm flex flex-col items-center justify-center my-auto">
        {callType === 'video' && callStatus === 'connected' ? (
          <div className="relative w-full aspect-[3/4] rounded-3xl overflow-hidden bg-slate-900 border border-slate-800 shadow-2xl">
            {/* Remote Video */}
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />

            {/* Local Video PIP Preview */}
            <div className="absolute bottom-3 right-3 w-28 aspect-[3/4] rounded-2xl overflow-hidden border-2 border-white/20 shadow-xl bg-slate-950">
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        ) : (
          /* Voice Call Avatar & Audio Wave Animation */
          <div className="flex flex-col items-center text-center gap-4">
            <div className="relative">
              <div className="w-28 h-28 rounded-full p-1 bg-gradient-to-tr from-rose-500 to-amber-500 shadow-2xl shadow-rose-500/30">
                <img
                  src={peerUser.photoUrl}
                  alt={peerUser.username}
                  className="w-full h-full rounded-full object-cover border-4 border-slate-950"
                />
              </div>

              {callStatus === 'connected' && (
                <div className="absolute inset-0 rounded-full border-4 border-rose-500 animate-ping opacity-40 pointer-events-none" />
              )}
            </div>

            <div>
              <h2 className="text-2xl font-black text-white">{peerUser.username}</h2>
              <p className="text-xs text-rose-300 font-semibold mt-1">
                {callStatus === 'connected'
                  ? `${callType === 'video' ? 'Video' : 'Voice'} Call Connected`
                  : isIncoming
                  ? `Incoming ${callType} Call...`
                  : `Calling ${peerUser.username}...`}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Action Controls Bar */}
      <div className="w-full max-w-sm flex items-center justify-center gap-4">
        {callStatus === 'ringing' && isIncoming ? (
          /* Incoming Call Actions: Accept or Reject */
          <div className="flex items-center gap-8">
            <button
              onClick={onRejectCall}
              className="w-16 h-16 rounded-full bg-rose-600 text-white shadow-xl shadow-rose-600/40 flex items-center justify-center transition active:scale-90 cursor-pointer"
              title="Decline"
            >
              <PhoneOff className="w-7 h-7" />
            </button>

            <button
              onClick={handleAccept}
              className="w-16 h-16 rounded-full bg-emerald-600 text-white shadow-xl shadow-emerald-600/40 flex items-center justify-center transition active:scale-90 cursor-pointer animate-bounce"
              title="Accept"
            >
              <Phone className="w-7 h-7" />
            </button>
          </div>
        ) : (
          /* Connected / Outgoing Call Controls */
          <div className="flex items-center gap-4 p-3 rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl">
            {/* Mic Toggle */}
            <button
              onClick={toggleMute}
              className={`p-3.5 rounded-2xl transition cursor-pointer ${
                isMuted
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                  : 'bg-slate-800 text-white hover:bg-slate-700'
              }`}
              title={isMuted ? 'Unmute Mic' : 'Mute Mic'}
            >
              {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            {/* Video Toggle (if video call) */}
            {callType === 'video' && (
              <button
                onClick={toggleVideo}
                className={`p-3.5 rounded-2xl transition cursor-pointer ${
                  isVideoOff
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                    : 'bg-slate-800 text-white hover:bg-slate-700'
                }`}
                title={isVideoOff ? 'Turn Camera On' : 'Turn Camera Off'}
              >
                {isVideoOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
              </button>
            )}

            {/* Hangup Red Button */}
            <button
              onClick={handleHangup}
              className="px-6 py-3.5 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-rose-600/40 cursor-pointer transition active:scale-95"
              title="End Call"
            >
              <PhoneOff className="w-5 h-5" />
              <span>End Call</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
