import React, { useState, useEffect } from 'react';
import { ReportItem, SubscriptionRecord, User } from '../../types';
import { api } from '../../services/api';
import { sound } from '../../services/sound';
import {
  X,
  ShieldAlert,
  CreditCard,
  Users,
  DollarSign,
  Ban,
  Check,
  Crown,
  Sparkles,
  RefreshCw,
} from 'lucide-react';

interface AdminDashboardProps {
  currentUser: User;
  onClose: () => void;
  onUserSubscribed?: (user: User) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  currentUser,
  onClose,
  onUserSubscribed,
}) => {
  const [tab, setTab] = useState<'overview' | 'subscriptions' | 'reports' | 'users'>('overview');
  const [stats, setStats] = useState<{
    totalUsers: number;
    activeReports: number;
    totalRevenue: number;
    subscriptionsCount: number;
    usersList: User[];
  } | null>(null);

  const [subscriptions, setSubscriptions] = useState<SubscriptionRecord[]>([]);
  const [reports, setReports] = useState<ReportItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [subscribing, setSubscribing] = useState<boolean>(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [sData, subData, repData] = await Promise.all([
        api.getAdminStats(),
        api.getAdminSubscriptions(),
        api.getAdminReports(),
      ]);
      setStats(sData);
      setSubscriptions(subData.subscriptions);
      setReports(repData.reports);
    } catch (err) {
      console.error('Failed to load admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleResolveReport = async (reportId: string, action: 'ban' | 'dismiss') => {
    try {
      sound.playStep();
      await api.resolveReport(reportId, action);
      loadData();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Report resolution error');
    }
  };

  const handleTestPurchase = async () => {
    setSubscribing(true);
    try {
      sound.playVictory();
      const res = await api.subscribe();
      alert(res.message);
      onUserSubscribed?.(res.user);
      loadData();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Subscription error');
    } finally {
      setSubscribing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950/70">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold">
              <Crown className="w-4 h-4 text-amber-300" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Admin Management Dashboard</h3>
              <p className="text-[11px] text-slate-400">Subscription Records & Community Moderation</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={loadData}
              className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
              title="Refresh Data"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950 text-xs">
          {[
            { id: 'overview', label: 'Overview', icon: DollarSign },
            { id: 'subscriptions', label: 'Subscription Ledger', icon: CreditCard },
            { id: 'reports', label: `Reports (${reports.filter((r) => r.status === 'pending').length})`, icon: ShieldAlert },
            { id: 'users', label: 'User Directory', icon: Users },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id as typeof tab)}
              className={`flex-1 py-3 font-bold flex items-center justify-center gap-1.5 border-b-2 transition cursor-pointer ${
                tab === t.id
                  ? 'border-purple-500 text-purple-300 bg-purple-500/10'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <t.icon className="w-3.5 h-3.5" />
              <span>{t.label}</span>
            </button>
          ))}
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
          {tab === 'overview' && (
            <div className="flex flex-col gap-4">
              {/* Stat Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Total Users</span>
                  <div className="text-xl font-black text-white mt-0.5">{stats?.totalUsers || 0}</div>
                  <span className="text-[10px] text-emerald-400 font-semibold">18+ Verified</span>
                </div>

                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Total Revenue</span>
                  <div className="text-xl font-black text-emerald-400 font-mono mt-0.5">
                    ₹{stats?.totalRevenue || 0}
                  </div>
                  <span className="text-[10px] text-slate-400 font-semibold">INR Payments</span>
                </div>

                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400">VIP Members</span>
                  <div className="text-xl font-black text-amber-300 mt-0.5">
                    {stats?.subscriptionsCount || 0}
                  </div>
                  <span className="text-[10px] text-slate-400">Active Plans</span>
                </div>

                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Pending Reports</span>
                  <div className="text-xl font-black text-rose-400 mt-0.5">
                    {stats?.activeReports || 0}
                  </div>
                  <span className="text-[10px] text-slate-400">Needs Review</span>
                </div>
              </div>

              {/* Special Launch Promotion VIP Plan */}
              <div className="p-4 rounded-3xl bg-gradient-to-br from-rose-950/60 via-slate-900 to-purple-950/60 border-2 border-rose-500/50 flex flex-col gap-3 shadow-xl">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">🚀</span>
                    <div>
                      <span className="text-xs font-black uppercase tracking-wider text-rose-300">
                        Launch Promotion · 75% OFF
                      </span>
                      <h4 className="text-sm font-black text-white">VIP Lover Pass (6 Months)</h4>
                    </div>
                  </div>
                  <span className="text-[11px] font-black bg-rose-500 text-white px-2.5 py-0.5 rounded-full shadow">
                    SAVE 75%
                  </span>
                </div>

                {/* Pricing Display */}
                <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-xs text-slate-400 font-medium line-through">₹199</span>
                      <span className="text-2xl font-black text-emerald-400 font-mono">₹50</span>
                      <span className="text-xs font-bold text-slate-300">for 6 Months</span>
                    </div>
                    <p className="text-[10px] text-amber-400 font-bold mt-0.5 flex items-center gap-1">
                      <span>✓ One-time payment</span>
                      <span>·</span>
                      <span>No automatic renewal or recurring payment</span>
                    </p>
                  </div>

                  <button
                    onClick={() => handleTestPurchase()}
                    disabled={subscribing}
                    className="px-4 py-2.5 bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white font-bold text-xs rounded-xl shadow-lg cursor-pointer transition active:scale-95"
                  >
                    {subscribing ? 'Processing...' : 'Subscribe (₹50)'}
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-300">
                  <div className="flex items-center gap-1.5">
                    <span className="text-emerald-400">✓</span>
                    <span>6 Months VIP Access</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-emerald-400">✓</span>
                    <span>Golden Crown Profile Badge</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-emerald-400">✓</span>
                    <span>+5,000 Virtual Gift Coins</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-emerald-400">✓</span>
                    <span>Priority Dating Discovery</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Subscriptions Ledger Tab */}
          {tab === 'subscriptions' && (
            <div className="flex flex-col gap-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Completed Payment Records ({subscriptions.length})
              </span>

              <div className="flex flex-col gap-2">
                {subscriptions.map((sub) => (
                  <div
                    key={sub.id}
                    className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-purple-400">{sub.id}</span>
                        <span className="font-bold text-white">{sub.userName}</span>
                        <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded font-bold border border-emerald-500/30">
                          {sub.status.toUpperCase()}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-2">
                        <span>{sub.planName}</span>
                        <span>·</span>
                        <span className="text-amber-400 font-mono">+{sub.coinsGranted} 🪙</span>
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        Duration: {sub.duration || '6 Months'} · No Auto-Renew
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-xs text-slate-500 line-through">₹{sub.originalPriceInr || 199}</div>
                      <div className="font-mono font-black text-emerald-400 text-sm">
                        ₹{sub.finalPriceInr || 50}
                      </div>
                      <div className="text-[9px] text-slate-500">
                        {new Date(sub.purchasedAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Moderation Reports Tab */}
          {tab === 'reports' && (
            <div className="flex flex-col gap-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Community Safety Reports
              </span>

              {reports.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-500 bg-slate-950 rounded-2xl">
                  No safety reports filed. Community is healthy and peaceful!
                </div>
              ) : (
                reports.map((rep) => (
                  <div
                    key={rep.id}
                    className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col gap-2 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-rose-400">{rep.id}</span>
                        <span className="font-bold text-white">Target: {rep.targetUserName}</span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                            rep.status === 'pending'
                              ? 'bg-amber-500/20 text-amber-300'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {rep.status.toUpperCase()}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-500">
                        By {rep.reporterName} · {new Date(rep.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>

                    <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800 text-slate-300">
                      <strong className="text-rose-300">{rep.reason}</strong>: {rep.details || 'No additional details provided.'}
                    </div>

                    {rep.status === 'pending' && (
                      <div className="flex gap-2 justify-end mt-1">
                        <button
                          onClick={() => handleResolveReport(rep.id, 'dismiss')}
                          className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition cursor-pointer flex items-center gap-1 text-xs"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Dismiss</span>
                        </button>
                        <button
                          onClick={() => handleResolveReport(rep.id, 'ban')}
                          className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold transition cursor-pointer flex items-center gap-1 text-xs shadow-md shadow-rose-600/30"
                        >
                          <Ban className="w-3.5 h-3.5" />
                          <span>Ban User</span>
                        </button>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          )}

          {/* User Directory Tab */}
          {tab === 'users' && (
            <div className="flex flex-col gap-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Registered Users ({stats?.usersList?.length || 0})
              </span>

              <div className="flex flex-col gap-2">
                {stats?.usersList?.map((u) => (
                  <div
                    key={u.id}
                    className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <img src={u.photoUrl} alt={u.username} className="w-10 h-10 rounded-xl object-cover" />
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white">{u.username}</span>
                          <span className="text-rose-400 font-semibold">{u.age} y/o</span>
                          {u.isAdmin && (
                            <span className="text-[10px] bg-purple-500/20 text-purple-300 px-1.5 py-0.5 rounded font-bold">
                              Admin
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-400">{u.city} · {u.email}</div>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-amber-400 font-mono font-bold">{u.coins} 🪙</div>
                      {u.isBanned ? (
                        <span className="text-[10px] text-rose-500 font-bold">BANNED</span>
                      ) : (
                        <span className="text-[10px] text-emerald-400 font-medium">Active</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
