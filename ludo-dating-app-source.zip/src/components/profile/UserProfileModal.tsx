import React, { useState } from 'react';
import { User, PrivacySettings } from '../../types';
import { api } from '../../services/api';
import { sound } from '../../services/sound';
import {
  X,
  ShieldCheck,
  MapPin,
  Heart,
  Coins,
  Crown,
  Edit2,
  Check,
  LogOut,
  Users,
  Download,
  Lock,
  Eye,
  EyeOff,
  Phone,
  MessageSquare,
  Sparkles,
} from 'lucide-react';

interface UserProfileModalProps {
  user: User;
  onClose: () => void;
  onUpdateUser: (updated: User) => void;
  onSwitchUser: (userId: string) => void;
  onLogout: () => void;
  onOpenAdmin: () => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  user,
  onClose,
  onUpdateUser,
  onSwitchUser,
  onLogout,
  onOpenAdmin,
}) => {
  const [tab, setTab] = useState<'profile' | 'privacy' | 'vip'>('profile');
  const [isEditing, setIsEditing] = useState(false);
  const [bio, setBio] = useState(user.bio);
  const [city, setCity] = useState(user.city);
  const [lookingFor, setLookingFor] = useState(user.lookingFor);
  const [saving, setSaving] = useState(false);
  const [subscribing, setSubscribing] = useState(false);

  // Privacy Settings state
  const [privacy, setPrivacy] = useState<PrivacySettings>(
    user.privacy || {
      showOnlineStatus: true,
      showLastSeen: true,
      allowCallsFrom: 'friends_and_matches',
      allowMessagesFrom: 'everyone',
      profileVisibility: 'public',
    }
  );

  const [demoUsers, setDemoUsers] = useState<User[]>([]);
  const [showSwitchDrawer, setShowSwitchDrawer] = useState(false);

  const handleSaveProfile = async () => {
    setSaving(true);
    try {
      sound.playStep();
      const res = await api.updateProfile({
        bio,
        city,
        lookingFor,
      });
      onUpdateUser(res.user);
      setIsEditing(false);
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Save error');
    } finally {
      setSaving(false);
    }
  };

  const handleSavePrivacy = async (updated: Partial<PrivacySettings>) => {
    const next = { ...privacy, ...updated };
    setPrivacy(next);
    try {
      sound.playStep();
      const res = await api.updatePrivacy(next);
      onUpdateUser(res.user);
    } catch (err) {
      console.error(err);
    }
  };

  const handleActivateVip = async () => {
    setSubscribing(true);
    try {
      sound.playVictory();
      const res = await api.subscribe();
      alert(res.message);
      onUpdateUser(res.user);
    } catch (err) {
      alert(err instanceof Error ? err.message : 'VIP activation error');
    } finally {
      setSubscribing(false);
    }
  };

  const loadDemoUsers = async () => {
    try {
      const data = await api.getSeedUsers();
      setDemoUsers(data.users);
      setShowSwitchDrawer(true);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950/70">
          <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
            <span>Settings & Profile</span>
          </h3>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-800 bg-slate-950 text-xs">
          <button
            onClick={() => setTab('profile')}
            className={`flex-1 py-2.5 font-bold border-b-2 transition cursor-pointer ${
              tab === 'profile' ? 'border-rose-500 text-rose-300' : 'border-transparent text-slate-400'
            }`}
          >
            Profile
          </button>
          <button
            onClick={() => setTab('privacy')}
            className={`flex-1 py-2.5 font-bold border-b-2 transition cursor-pointer ${
              tab === 'privacy' ? 'border-emerald-500 text-emerald-300' : 'border-transparent text-slate-400'
            }`}
          >
            Privacy & Calls
          </button>
          <button
            onClick={() => setTab('vip')}
            className={`flex-1 py-2.5 font-bold border-b-2 transition cursor-pointer flex items-center justify-center gap-1 ${
              tab === 'vip' ? 'border-amber-500 text-amber-300' : 'border-transparent text-slate-400'
            }`}
          >
            <Crown className="w-3.5 h-3.5" />
            <span>VIP ₹50</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
          {tab === 'profile' && (
            <>
              {/* Profile Card */}
              <div className="flex items-center gap-3.5 p-3 rounded-2xl bg-slate-950/70 border border-slate-800">
                <img
                  src={user.photoUrl}
                  alt={user.username}
                  className="w-16 h-16 rounded-2xl object-cover border-2 border-rose-500 shadow-md"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-base font-black text-white truncate">{user.username}</span>
                    <span className="text-sm font-bold text-rose-400">{user.age}</span>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-slate-400 mt-0.5">
                    <MapPin className="w-3 h-3 text-rose-400" />
                    <span>{user.city}</span>
                  </div>
                  <div className="flex items-center gap-1.5 mt-1.5">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" />
                      <span>18+ Verified</span>
                    </span>
                    {user.vipTier !== 'none' && (
                      <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold border border-amber-500/30 flex items-center gap-1">
                        <Crown className="w-3 h-3" />
                        <span>VIP</span>
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Virtual Coins Notice */}
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/15 via-rose-500/10 to-transparent border border-amber-500/30 flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-300 flex items-center gap-1">
                    <Coins className="w-4 h-4 text-amber-400" />
                    <span>Virtual Coins</span>
                  </span>
                  <span className="text-base font-black text-amber-400 font-mono">{user.coins} 🪙</span>
                </div>
                <p className="text-[10px] text-slate-400">
                  Virtual entertainment credits only. Strictly no gambling, cash prizes, or withdrawals.
                </p>
              </div>

              {/* Bio & Details */}
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">About Me</span>
                  <button
                    onClick={() => setIsEditing(!isEditing)}
                    className="text-xs text-rose-400 font-bold flex items-center gap-1 cursor-pointer hover:underline"
                  >
                    <Edit2 className="w-3 h-3" />
                    <span>{isEditing ? 'Cancel' : 'Edit'}</span>
                  </button>
                </div>

                {isEditing ? (
                  <div className="flex flex-col gap-2 bg-slate-950 p-3 rounded-2xl border border-slate-800">
                    <label className="text-[11px] text-slate-400">Bio:</label>
                    <textarea
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      rows={3}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-rose-500"
                    />

                    <label className="text-[11px] text-slate-400">City:</label>
                    <input
                      type="text"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="bg-slate-900 border border-slate-700 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-rose-500"
                    />

                    <label className="text-[11px] text-slate-400">Looking For:</label>
                    <select
                      value={lookingFor}
                      onChange={(e) => setLookingFor(e.target.value as 'men' | 'women' | 'everyone')}
                      className="bg-slate-900 border border-slate-700 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-rose-500"
                    >
                      <option value="men">Men</option>
                      <option value="women">Women</option>
                      <option value="everyone">Everyone</option>
                    </select>

                    <button
                      onClick={handleSaveProfile}
                      disabled={saving}
                      className="mt-1 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{saving ? 'Saving...' : 'Save Profile'}</span>
                    </button>
                  </div>
                ) : (
                  <p className="text-xs text-slate-200 leading-relaxed bg-slate-950/60 p-3 rounded-2xl border border-slate-800/80">
                    {user.bio}
                  </p>
                )}
              </div>

              {/* Interests */}
              <div className="flex flex-col gap-1.5">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Interests</span>
                <div className="flex flex-wrap gap-1.5">
                  {user.interests.map((tag, i) => (
                    <span
                      key={i}
                      className="text-xs bg-slate-800 text-slate-300 px-2.5 py-1 rounded-xl border border-slate-700"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Quick Persona Switcher */}
              <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1">
                    <Users className="w-3.5 h-3.5 text-blue-400" />
                    <span>Switch Test Persona</span>
                  </span>
                  <button
                    onClick={loadDemoUsers}
                    className="text-xs text-blue-400 hover:underline cursor-pointer font-bold"
                  >
                    Change
                  </button>
                </div>

                {showSwitchDrawer && (
                  <div className="grid grid-cols-2 gap-1.5 mt-1">
                    {demoUsers.map((du) => (
                      <button
                        key={du.id}
                        onClick={() => {
                          onSwitchUser(du.id);
                          onClose();
                        }}
                        className={`p-2 rounded-xl border text-left flex items-center gap-2 cursor-pointer transition ${
                          du.id === user.id
                            ? 'bg-rose-600/30 border-rose-500'
                            : 'bg-slate-900 border-slate-800 hover:bg-slate-800'
                        }`}
                      >
                        <img src={du.photoUrl} alt={du.username} className="w-7 h-7 rounded-full object-cover" />
                        <div className="truncate">
                          <div className="text-[11px] font-bold text-white truncate">{du.username}</div>
                          <div className="text-[9px] text-slate-400">{du.isAdmin ? 'Admin' : `${du.age} y/o`}</div>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </>
          )}

          {tab === 'privacy' && (
            <div className="flex flex-col gap-3.5">
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
                <Lock className="w-4 h-4" />
                <span>Privacy & Communication Permissions</span>
              </div>

              {/* Online Presence */}
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col gap-3 text-xs">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-bold text-white">Show Online Status</div>
                    <div className="text-[10px] text-slate-400">Let friends see when you are active</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={privacy.showOnlineStatus}
                    onChange={(e) => handleSavePrivacy({ showOnlineStatus: e.target.checked })}
                    className="w-4 h-4 accent-emerald-500"
                  />
                </div>

                <div className="flex items-center justify-between border-t border-slate-900 pt-2">
                  <div>
                    <div className="font-bold text-white">Show Last Seen</div>
                    <div className="text-[10px] text-slate-400">Display last active timestamp</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={privacy.showLastSeen}
                    onChange={(e) => handleSavePrivacy({ showLastSeen: e.target.checked })}
                    className="w-4 h-4 accent-emerald-500"
                  />
                </div>
              </div>

              {/* Call Permissions (Strangers cannot call without permission) */}
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col gap-2 text-xs">
                <div className="flex items-center gap-1.5 font-bold text-white">
                  <Phone className="w-3.5 h-3.5 text-blue-400" />
                  <span>Who Can Call You (Voice & Video)</span>
                </div>
                <p className="text-[10px] text-slate-400">Strangers cannot call you without your permission.</p>

                <select
                  value={privacy.allowCallsFrom}
                  onChange={(e) =>
                    handleSavePrivacy({
                      allowCallsFrom: e.target.value as 'everyone' | 'friends_and_matches' | 'friends_only',
                    })
                  }
                  className="bg-slate-900 border border-slate-700 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-rose-500"
                >
                  <option value="friends_and_matches">Friends & Mutual Matches Only (Recommended)</option>
                  <option value="friends_only">Close Friends Only</option>
                  <option value="everyone">Everyone</option>
                </select>
              </div>

              {/* Messaging Permissions */}
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col gap-2 text-xs">
                <div className="flex items-center gap-1.5 font-bold text-white">
                  <MessageSquare className="w-3.5 h-3.5 text-rose-400" />
                  <span>Who Can Send Private Messages</span>
                </div>

                <select
                  value={privacy.allowMessagesFrom}
                  onChange={(e) =>
                    handleSavePrivacy({
                      allowMessagesFrom: e.target.value as 'everyone' | 'matches_only' | 'friends_only',
                    })
                  }
                  className="bg-slate-900 border border-slate-700 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-rose-500"
                >
                  <option value="everyone">Everyone (Dating Discovery)</option>
                  <option value="matches_only">Mutual Matches Only</option>
                  <option value="friends_only">Accepted Friends Only</option>
                </select>
              </div>

              {/* Profile Visibility */}
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col gap-2 text-xs">
                <div className="flex items-center gap-1.5 font-bold text-white">
                  <Eye className="w-3.5 h-3.5 text-amber-400" />
                  <span>Profile Visibility</span>
                </div>

                <select
                  value={privacy.profileVisibility}
                  onChange={(e) =>
                    handleSavePrivacy({
                      profileVisibility: e.target.value as 'public' | 'friends_only' | 'hidden',
                    })
                  }
                  className="bg-slate-900 border border-slate-700 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-rose-500"
                >
                  <option value="public">Public (Show in Dating Discovery)</option>
                  <option value="friends_only">Friends Only</option>
                  <option value="hidden">Hidden (Incognito Mode)</option>
                </select>
              </div>
            </div>
          )}

          {tab === 'vip' && (
            /* Dedicated VIP Membership Promotion */
            <div className="flex flex-col gap-3">
              <div className="p-4 rounded-3xl bg-gradient-to-br from-rose-950/70 via-slate-900 to-amber-950/60 border-2 border-rose-500/50 flex flex-col gap-3 shadow-2xl">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black uppercase tracking-wider text-rose-300 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>Special Launch Offer</span>
                  </span>
                  <span className="text-[10px] font-black bg-rose-500 text-white px-2 py-0.5 rounded-full shadow">
                    SAVE 75%
                  </span>
                </div>

                <h3 className="text-base font-black text-white">VIP Lover Pass (6 Months)</h3>

                {/* Price Display */}
                <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-baseline justify-between">
                  <div>
                    <span className="text-sm text-slate-500 line-through font-bold">₹199</span>
                    <span className="text-3xl font-black text-emerald-400 font-mono ml-2">₹50</span>
                    <span className="text-xs text-slate-300 font-bold ml-1">/ 6 Months</span>
                  </div>
                  <span className="text-[11px] font-bold text-amber-300">75% OFF</span>
                </div>

                <p className="text-[11px] text-amber-400 font-semibold">
                  ✓ One-time payment · No automatic renewal or recurring billing.
                </p>

                <div className="flex flex-col gap-1.5 text-xs text-slate-300 mt-1">
                  <div className="flex items-center gap-2">
                    <span className="text-emerald-400">✓</span>
                    <span>Full 6 Months VIP membership</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-emerald-400">✓</span>
                    <span>VIP Golden Crown profile badge</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-emerald-400">✓</span>
                    <span>+5,000 Virtual dating gift coins</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-emerald-400">✓</span>
                    <span>Unlimited swipes & priority matching</span>
                  </div>
                </div>

                <button
                  onClick={handleActivateVip}
                  disabled={subscribing}
                  className="w-full mt-2 py-3 bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white font-black text-sm rounded-2xl shadow-xl shadow-rose-600/30 cursor-pointer transition active:scale-95"
                >
                  {subscribing ? 'Activating...' : 'Activate for ₹50'}
                </button>
              </div>
            </div>
          )}

          {/* Download Source Code (.ZIP) */}
          <a
            href="/api/download-zip"
            download="ludo-dating-app-source.zip"
            className="w-full py-2.5 bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white font-bold rounded-2xl text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg transition active:scale-95"
          >
            <Download className="w-4 h-4" />
            <span>Download Source Code (.ZIP)</span>
          </a>

          {/* Admin Dashboard Entry (if Admin) */}
          {user.isAdmin && (
            <button
              onClick={() => {
                onClose();
                onOpenAdmin();
              }}
              className="w-full py-2.5 bg-gradient-to-r from-purple-700 to-indigo-700 hover:from-purple-600 hover:to-indigo-600 text-white font-bold rounded-2xl text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg"
            >
              <Crown className="w-4 h-4 text-amber-300" />
              <span>Open Admin Dashboard</span>
            </button>
          )}

          {/* Logout */}
          <button
            onClick={onLogout}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-rose-300 hover:text-rose-200 font-bold rounded-2xl text-xs flex items-center justify-center gap-2 cursor-pointer border border-slate-700/80 transition"
          >
            <LogOut className="w-4 h-4" />
            <span>Log Out</span>
          </button>
        </div>
      </div>
    </div>
  );
};
