import React, { useState, useEffect } from 'react';
import { User } from '../../types';
import { api } from '../../services/api';
import { sound } from '../../services/sound';
import {
  Users,
  UserPlus,
  Phone,
  Video,
  MessageCircle,
  Dices,
  Check,
  X,
  UserX,
  Clock,
  Sparkles,
} from 'lucide-react';

interface FriendsViewProps {
  currentUser: User;
  onOpenChat: (userId: string) => void;
  onStartCall: (targetUser: User, callType: 'voice' | 'video') => void;
  onInviteToLudo: (otherUserId: string) => void;
}

export const FriendsView: React.FC<FriendsViewProps> = ({
  currentUser,
  onOpenChat,
  onStartCall,
  onInviteToLudo,
}) => {
  const [friends, setFriends] = useState<(User & { isFriend: boolean })[]>([]);
  const [pendingIncoming, setPendingIncoming] = useState<{ id: string; fromUser: User; createdAt: string }[]>([]);
  const [pendingOutgoing, setPendingOutgoing] = useState<{ id: string; toUser: User; createdAt: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [targetUsername, setTargetUsername] = useState('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  useEffect(() => {
    loadFriendsData();
  }, []);

  const loadFriendsData = async () => {
    setLoading(true);
    try {
      const data = await api.getFriends();
      setFriends(data.friends);
      setPendingIncoming(data.pendingIncoming);
      setPendingOutgoing(data.pendingOutgoing);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSendRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetUsername.trim()) return;

    try {
      sound.playNotification();
      // Search from seed users or registered users
      const seedRes = await api.getSeedUsers();
      const match = seedRes.users.find(
        (u) => u.username.toLowerCase() === targetUsername.trim().toLowerCase()
      );

      if (!match) {
        setStatusMessage(`User "${targetUsername}" not found. Try Maya, Arjun, or Zara!`);
        return;
      }

      await api.sendFriendRequest(match.id);
      setStatusMessage(`Friend request sent to ${match.username}!`);
      setTargetUsername('');
      loadFriendsData();
    } catch (err) {
      setStatusMessage(err instanceof Error ? err.message : 'Error sending request');
    }
  };

  const handleRespond = async (userId: string, action: 'accept' | 'reject') => {
    try {
      sound.playStep();
      await api.respondFriendRequest(userId, action);
      loadFriendsData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleCancel = async (userId: string) => {
    try {
      sound.playStep();
      await api.cancelFriendRequest(userId);
      loadFriendsData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleRemoveFriend = async (userId: string, name: string) => {
    if (!confirm(`Are you sure you want to remove ${name} from your friends?`)) return;
    try {
      sound.playStep();
      await api.removeFriend(userId);
      loadFriendsData();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-md mx-auto w-full px-3 py-3 flex flex-col gap-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-white flex items-center gap-1.5">
            <Users className="w-5 h-5 text-rose-500" />
            <span>Online Friends ({friends.length})</span>
          </h2>
          <p className="text-xs text-slate-400">Play, call and chat privately with close friends</p>
        </div>
      </div>

      {/* Add Friend Input */}
      <form onSubmit={handleSendRequest} className="flex gap-2">
        <input
          type="text"
          placeholder="Add friend by username (e.g. Maya, Arjun)..."
          value={targetUsername}
          onChange={(e) => setTargetUsername(e.target.value)}
          className="flex-1 bg-slate-900 border border-slate-800 rounded-2xl px-3 py-2 text-xs text-white focus:outline-none focus:border-rose-500"
        />
        <button
          type="submit"
          className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-2xl shadow flex items-center gap-1 transition cursor-pointer"
        >
          <UserPlus className="w-4 h-4" />
          <span>Add</span>
        </button>
      </form>

      {statusMessage && (
        <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-amber-300">
          {statusMessage}
        </div>
      )}

      {/* Pending Incoming Requests */}
      {pendingIncoming.length > 0 && (
        <div className="flex flex-col gap-2">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Received Friend Requests ({pendingIncoming.length})</span>
          </span>

          {pendingIncoming.map((req) => (
            <div
              key={req.id}
              className="p-3 rounded-2xl bg-gradient-to-r from-amber-500/10 to-transparent border border-amber-500/30 flex items-center justify-between"
            >
              <div className="flex items-center gap-2.5">
                <img
                  src={req.fromUser.photoUrl}
                  alt={req.fromUser.username}
                  className="w-10 h-10 rounded-full object-cover border border-amber-400"
                />
                <div>
                  <div className="text-xs font-bold text-white">{req.fromUser.username}</div>
                  <div className="text-[10px] text-slate-400">{req.fromUser.city}</div>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => handleRespond(req.fromUser.id, 'accept')}
                  className="p-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer shadow"
                  title="Accept"
                >
                  <Check className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleRespond(req.fromUser.id, 'reject')}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white cursor-pointer"
                  title="Decline"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Pending Outgoing Requests */}
      {pendingOutgoing.length > 0 && (
        <div className="flex flex-col gap-2">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Sent Requests ({pendingOutgoing.length})
          </span>

          {pendingOutgoing.map((req) => (
            <div
              key={req.id}
              className="p-2.5 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-center justify-between text-xs"
            >
              <div className="flex items-center gap-2">
                <img src={req.toUser.photoUrl} alt={req.toUser.username} className="w-7 h-7 rounded-full object-cover" />
                <span className="text-white font-semibold">{req.toUser.username}</span>
                <span className="text-[10px] text-slate-500">· Pending</span>
              </div>
              <button
                onClick={() => handleCancel(req.toUser.id)}
                className="text-xs text-rose-400 hover:underline cursor-pointer"
              >
                Cancel
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Friends List */}
      <div className="flex flex-col gap-2.5">
        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
          All Friends
        </span>

        {loading ? (
          <div className="text-center py-6 text-xs text-slate-500">Loading friends...</div>
        ) : friends.length === 0 ? (
          <div className="text-center py-8 p-4 bg-slate-900/60 border border-slate-800 rounded-3xl flex flex-col items-center gap-2">
            <Users className="w-8 h-8 text-slate-600" />
            <h3 className="text-sm font-bold text-white">No friends added yet</h3>
            <p className="text-xs text-slate-400 max-w-xs">
              Add players by username or match with players in Dating Discovery to chat and play!
            </p>
          </div>
        ) : (
          friends.map((friend) => (
            <div
              key={friend.id}
              className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between shadow-sm"
            >
              {/* Friend Info & Presence */}
              <div className="flex items-center gap-3 min-w-0">
                <div className="relative">
                  <img
                    src={friend.photoUrl}
                    alt={friend.username}
                    className="w-11 h-11 rounded-full object-cover border border-slate-700"
                  />
                  {friend.privacy.showOnlineStatus && (
                    <span
                      className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-slate-950 ${
                        friend.isOnline ? 'bg-emerald-500' : 'bg-slate-500'
                      }`}
                    />
                  )}
                </div>

                <div className="truncate">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-white truncate">{friend.username}</span>
                    <span className="text-[11px] text-rose-300 font-medium">{friend.age}</span>
                  </div>
                  <div className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                    {friend.privacy.showOnlineStatus && friend.isOnline ? (
                      <span className="text-emerald-400 font-semibold">Online now</span>
                    ) : friend.privacy.showLastSeen ? (
                      <span className="flex items-center gap-0.5">
                        <Clock className="w-2.5 h-2.5" />
                        <span>Seen {friend.lastSeen || 'recently'}</span>
                      </span>
                    ) : (
                      <span>{friend.city}</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Action Buttons: Voice Call, Video Call, Chat, Ludo, Remove */}
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => onStartCall(friend, 'voice')}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-emerald-600 hover:text-white text-slate-300 transition cursor-pointer"
                  title="Voice Call"
                >
                  <Phone className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => onStartCall(friend, 'video')}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-blue-600 hover:text-white text-slate-300 transition cursor-pointer"
                  title="Video Call"
                >
                  <Video className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => onInviteToLudo(friend.id)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-amber-600 hover:text-white text-slate-300 transition cursor-pointer"
                  title="Play Ludo Together"
                >
                  <Dices className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => onOpenChat(friend.id)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-rose-600 hover:text-white text-slate-300 transition cursor-pointer"
                  title="Private Message"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => handleRemoveFriend(friend.id, friend.username)}
                  className="p-2 rounded-xl text-slate-600 hover:text-rose-400 transition cursor-pointer"
                  title="Remove Friend"
                >
                  <UserX className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
