import React from 'react';
import { GameState, PlayerColor, Token } from '../../types';
import { COLOR_CONFIG, SAFE_CELLS, TRACK_CELLS, getTokenCoordinates } from '../../services/ludoEngine';
import { sound } from '../../services/sound';

interface LudoBoardProps {
  gameState: GameState;
  onSelectToken: (tokenIndex: number) => void;
  canInteract: boolean;
  highlightedTokens?: number[];
}

export const LudoBoard: React.FC<LudoBoardProps> = ({
  gameState,
  onSelectToken,
  canInteract,
  highlightedTokens = [],
}) => {
  const currentP = gameState.players[gameState.currentTurnIndex];

  // Helper to check if a track cell is safe
  const isSafeTrackCell = (cellIdx: number) => SAFE_CELLS.includes(cellIdx);

  // Group tokens by approximate position to spread overlapping tokens
  const tokenPositionGroups = new Map<string, { playerIdx: number; token: Token; index: number }[]>();

  gameState.players.forEach((p, pIdx) => {
    p.tokens.forEach((t, tIdx) => {
      const coords = getTokenCoordinates(p.color, t.step, t.id);
      const key = `${coords.x.toFixed(1)}_${coords.y.toFixed(1)}`;
      if (!tokenPositionGroups.has(key)) {
        tokenPositionGroups.set(key, []);
      }
      tokenPositionGroups.get(key)!.push({ playerIdx: pIdx, token: t, index: tIdx });
    });
  });

  return (
    <div className="relative w-full max-w-[540px] aspect-square mx-auto select-none rounded-2xl p-1 bg-gradient-to-b from-slate-800 to-slate-900 shadow-2xl border border-slate-700/60 overflow-hidden">
      <svg
        viewBox="0 0 15 15"
        className="w-full h-full rounded-xl bg-white shadow-inner"
        style={{ shapeRendering: 'geometricPrecision' }}
      >
        <defs>
          {/* Subtle drop shadows for tokens */}
          <filter id="tokenShadow" x="-30%" y="-30%" width="160%" height="160%">
            <feDropShadow dx="0" dy="0.08" stdDeviation="0.08" floodColor="#000000" floodOpacity="0.45" />
          </filter>
          <filter id="pulseGlow" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="0" dy="0" stdDeviation="0.16" floodColor="#fbbf24" floodOpacity="0.9" />
          </filter>
        </defs>

        {/* 1. Base Grid Background */}
        <rect x="0" y="0" width="15" height="15" fill="#f8fafc" />

        {/* 2. Four Corner Home Yards */}
        {/* Red Home Yard (Top-Left) */}
        <rect x="0" y="0" width="6" height="6" fill="#ef4444" />
        <rect x="1" y="1" width="4" height="4" rx="0.5" fill="#ffffff" />
        {/* Red Yard Token Bases */}
        {[
          { x: 1.8, y: 1.8 },
          { x: 3.8, y: 1.8 },
          { x: 1.8, y: 3.8 },
          { x: 3.8, y: 3.8 },
        ].map((spot, i) => (
          <circle key={`red-yard-${i}`} cx={spot.x} cy={spot.y} r="0.6" fill="#fee2e2" stroke="#dc2626" strokeWidth="0.08" />
        ))}

        {/* Green Home Yard (Top-Right) */}
        <rect x="9" y="0" width="6" height="6" fill="#10b981" />
        <rect x="10" y="1" width="4" height="4" rx="0.5" fill="#ffffff" />
        {[
          { x: 10.8, y: 1.8 },
          { x: 12.8, y: 1.8 },
          { x: 10.8, y: 3.8 },
          { x: 12.8, y: 3.8 },
        ].map((spot, i) => (
          <circle key={`green-yard-${i}`} cx={spot.x} cy={spot.y} r="0.6" fill="#d1fae5" stroke="#059669" strokeWidth="0.08" />
        ))}

        {/* Yellow Home Yard (Bottom-Right) */}
        <rect x="9" y="9" width="6" height="6" fill="#f59e0b" />
        <rect x="10" y="10" width="4" height="4" rx="0.5" fill="#ffffff" />
        {[
          { x: 10.8, y: 10.8 },
          { x: 12.8, y: 10.8 },
          { x: 10.8, y: 12.8 },
          { x: 12.8, y: 12.8 },
        ].map((spot, i) => (
          <circle key={`yellow-yard-${i}`} cx={spot.x} cy={spot.y} r="0.6" fill="#fef3c7" stroke="#d97706" strokeWidth="0.08" />
        ))}

        {/* Blue Home Yard (Bottom-Left) */}
        <rect x="0" y="9" width="6" height="6" fill="#3b82f6" />
        <rect x="1" y="10" width="4" height="4" rx="0.5" fill="#ffffff" />
        {[
          { x: 1.8, y: 10.8 },
          { x: 3.8, y: 10.8 },
          { x: 1.8, y: 12.8 },
          { x: 3.8, y: 12.8 },
        ].map((spot, i) => (
          <circle key={`blue-yard-${i}`} cx={spot.x} cy={spot.y} r="0.6" fill="#dbeafe" stroke="#2563eb" strokeWidth="0.08" />
        ))}

        {/* 3. Center Victory Triangles (6..9) */}
        <polygon points="6,6 9,6 7.5,7.5" fill="#10b981" />
        <polygon points="9,6 9,9 7.5,7.5" fill="#f59e0b" />
        <polygon points="6,9 9,9 7.5,7.5" fill="#3b82f6" />
        <polygon points="6,6 6,9 7.5,7.5" fill="#ef4444" />
        <rect x="6" y="6" width="3" height="3" fill="none" stroke="#cbd5e1" strokeWidth="0.04" />

        {/* 4. Colored Home Run Columns */}
        {/* Red Home Run (1..5, 7) */}
        {[1, 2, 3, 4, 5].map((x) => (
          <rect key={`red-home-${x}`} x={x} y="7" width="1" height="1" fill="#ef4444" stroke="#e2e8f0" strokeWidth="0.03" />
        ))}
        {/* Green Home Run (7, 1..5) */}
        {[1, 2, 3, 4, 5].map((y) => (
          <rect key={`green-home-${y}`} x="7" y={y} width="1" height="1" fill="#10b981" stroke="#e2e8f0" strokeWidth="0.03" />
        ))}
        {/* Yellow Home Run (9..13, 7) */}
        {[9, 10, 11, 12, 13].map((x) => (
          <rect key={`yellow-home-${x}`} x={x} y="7" width="1" height="1" fill="#f59e0b" stroke="#e2e8f0" strokeWidth="0.03" />
        ))}
        {/* Blue Home Run (7, 9..13) */}
        {[9, 10, 11, 12, 13].map((y) => (
          <rect key={`blue-home-${y}`} x="7" y={y} width="1" height="1" fill="#3b82f6" stroke="#e2e8f0" strokeWidth="0.03" />
        ))}

        {/* 5. 52 Circuit Track Cells */}
        {TRACK_CELLS.map((cell, idx) => {
          const isSafe = isSafeTrackCell(idx);
          const isRedStart = idx === 0;
          const isGreenStart = idx === 13;
          const isYellowStart = idx === 26;
          const isBlueStart = idx === 39;

          let cellFill = '#ffffff';
          if (isRedStart) cellFill = '#fee2e2';
          else if (isGreenStart) cellFill = '#d1fae5';
          else if (isYellowStart) cellFill = '#fef3c7';
          else if (isBlueStart) cellFill = '#dbeafe';

          return (
            <g key={`track-cell-${idx}`}>
              <rect
                x={cell.x}
                y={cell.y}
                width="1"
                height="1"
                fill={cellFill}
                stroke="#cbd5e1"
                strokeWidth="0.04"
              />

              {/* Safe Star Indicator */}
              {isSafe && (
                <text
                  x={cell.x + 0.5}
                  y={cell.y + 0.65}
                  fontSize="0.48"
                  fontWeight="bold"
                  textAnchor="middle"
                  fill="#f59e0b"
                >
                  ★
                </text>
              )}

              {/* Arrow on Start Cells */}
              {isRedStart && !isSafe && (
                <text x={cell.x + 0.5} y={cell.y + 0.65} fontSize="0.45" textAnchor="middle" fill="#ef4444">
                  ➔
                </text>
              )}
            </g>
          );
        })}

        {/* 6. Active Tokens Rendered on Board */}
        {Array.from(tokenPositionGroups.entries()).map(([posKey, group]) => {
          const [baseX, baseY] = posKey.split('_').map(Number);
          const isMulti = group.length > 1;

          return group.map(({ playerIdx, token, index }, groupIdx) => {
            const p = gameState.players[playerIdx];
            const isTurnPlayer = playerIdx === gameState.currentTurnIndex;
            const isValidMove = isTurnPlayer && highlightedTokens.includes(index) && canInteract;

            // Compute offset if multiple tokens share the square
            let offsetX = 0;
            let offsetY = 0;
            if (isMulti) {
              const offsets = [
                { dx: -0.18, dy: -0.18 },
                { dx: 0.18, dy: -0.18 },
                { dx: -0.18, dy: 0.18 },
                { dx: 0.18, dy: 0.18 },
              ];
              const o = offsets[groupIdx % offsets.length];
              offsetX = o.dx;
              offsetY = o.dy;
            }

            const cx = (token.step === -1 ? baseX : baseX + 0.5) + offsetX;
            const cy = (token.step === -1 ? baseY : baseY + 0.5) + offsetY;
            const radius = isMulti ? 0.32 : 0.38;

            return (
              <g
                key={`token-${p.color}-${token.id}`}
                className={isValidMove ? 'cursor-pointer' : ''}
                onClick={() => {
                  if (isValidMove) {
                    sound.playStep();
                    if ('vibrate' in navigator) navigator.vibrate?.(35);
                    onSelectToken(index);
                  }
                }}
              >
                {/* Glow ring for selectable tokens */}
                {isValidMove && (
                  <>
                    <circle
                      cx={cx}
                      cy={cy}
                      r={radius + 0.22}
                      fill="none"
                      stroke="#f59e0b"
                      strokeWidth="0.08"
                      className="animate-ping"
                      opacity="0.75"
                    />
                    <circle
                      cx={cx}
                      cy={cy}
                      r={radius + 0.12}
                      fill="none"
                      stroke="#fbbf24"
                      strokeWidth="0.06"
                      filter="url(#pulseGlow)"
                    />
                  </>
                )}

                {/* Token Body */}
                <circle
                  cx={cx}
                  cy={cy}
                  r={radius}
                  fill={COLOR_CONFIG[p.color].themeHex}
                  stroke="#ffffff"
                  strokeWidth="0.07"
                  filter="url(#tokenShadow)"
                />

                {/* Inner decorative ring */}
                <circle
                  cx={cx}
                  cy={cy}
                  r={radius * 0.65}
                  fill={COLOR_CONFIG[p.color].lightHex}
                  opacity="0.9"
                />

                {/* Token ID or Crown if reached center */}
                <text
                  x={cx}
                  y={cy + (isMulti ? 0.1 : 0.12)}
                  fontSize={isMulti ? '0.26' : '0.32'}
                  fontWeight="900"
                  textAnchor="middle"
                  fill={COLOR_CONFIG[p.color].borderHex}
                >
                  {token.finished ? '👑' : token.id + 1}
                </text>
              </g>
            );
          });
        })}
      </svg>

      {/* Floating turn banner */}
      <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between px-3 py-1.5 rounded-xl bg-slate-900/85 backdrop-blur-md border border-slate-700/60 shadow-lg text-xs pointer-events-none">
        <div className="flex items-center gap-2">
          <span
            className="w-3 h-3 rounded-full shadow"
            style={{ backgroundColor: COLOR_CONFIG[currentP.color].themeHex }}
          />
          <span className="font-bold text-white tracking-wide">
            {currentP.name}&apos;s Turn
          </span>
          {currentP.isBot && <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded">AI Bot</span>}
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-slate-400">Timer:</span>
          <span
            className={`font-mono font-bold ${
              gameState.turnTimeLeft <= 5 ? 'text-rose-400 animate-pulse' : 'text-amber-400'
            }`}
          >
            {gameState.turnTimeLeft}s
          </span>
        </div>
      </div>
    </div>
  );
};
