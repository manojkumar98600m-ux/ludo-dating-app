import React, { useState } from 'react';
import { sound } from '../../services/sound';
import { PlayerColor } from '../../types';
import { COLOR_CONFIG } from '../../services/ludoEngine';

interface DiceRollProps {
  diceValue: number | null;
  hasRolled: boolean;
  canRoll: boolean;
  playerColor: PlayerColor;
  onRoll: () => void;
  disabledReason?: string;
}

export const DiceRoll: React.FC<DiceRollProps> = ({
  diceValue,
  hasRolled,
  canRoll,
  playerColor,
  onRoll,
  disabledReason,
}) => {
  const [isRolling, setIsRolling] = useState(false);

  const handleRollClick = () => {
    if (!canRoll || hasRolled || isRolling) return;

    setIsRolling(true);
    sound.playDiceRoll();
    if ('vibrate' in navigator) navigator.vibrate?.([20, 30, 20]);

    setTimeout(() => {
      setIsRolling(false);
      onRoll();
    }, 450);
  };

  // Dot patterns for standard dice faces 1..6
  const renderDots = (val: number) => {
    const dots: { [key: number]: string[] } = {
      1: ['center'],
      2: ['top-right', 'bottom-left'],
      3: ['top-right', 'center', 'bottom-left'],
      4: ['top-left', 'top-right', 'bottom-left', 'bottom-right'],
      5: ['top-left', 'top-right', 'center', 'bottom-left', 'bottom-right'],
      6: ['top-left', 'top-right', 'middle-left', 'middle-right', 'bottom-left', 'bottom-right'],
    };

    const currentDots = dots[val] || ['center'];

    return (
      <div className="relative w-full h-full p-2.5 grid grid-cols-3 grid-rows-3 gap-1">
        {['top-left', 'top-center', 'top-right',
          'middle-left', 'center', 'middle-right',
          'bottom-left', 'bottom-center', 'bottom-right'].map((pos) => {
          const isPresent = currentDots.includes(pos);
          return (
            <div key={pos} className="flex items-center justify-center">
              {isPresent && (
                <div
                  className="w-2.5 h-2.5 rounded-full shadow-inner"
                  style={{
                    backgroundColor: val === 6 ? '#ef4444' : '#1e293b',
                  }}
                />
              )}
            </div>
          );
        })}
      </div>
    );
  };

  const theme = COLOR_CONFIG[playerColor] || COLOR_CONFIG.red;

  return (
    <div className="flex items-center gap-4 bg-slate-900/90 border border-slate-800 rounded-2xl p-3 shadow-xl backdrop-blur-md">
      {/* 3D-Style Die Box */}
      <button
        type="button"
        onClick={handleRollClick}
        disabled={!canRoll || hasRolled || isRolling}
        className={`relative w-16 h-16 rounded-2xl bg-gradient-to-br from-white via-slate-100 to-slate-300 shadow-[0_8px_16px_rgba(0,0,0,0.4),inset_0_2px_4px_rgba(255,255,255,0.9)] border border-slate-300 transition-all duration-300 flex items-center justify-center ${
          canRoll && !hasRolled
            ? 'cursor-pointer hover:scale-105 active:scale-95 ring-4 ring-amber-400/50 shadow-amber-500/20'
            : 'opacity-90 cursor-default'
        } ${isRolling ? 'animate-spin scale-110' : ''}`}
      >
        {diceValue ? (
          renderDots(diceValue)
        ) : (
          <div className="text-2xl font-black text-slate-400">🎲</div>
        )}

        {/* Small corner color indicator */}
        <div
          className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full border-2 border-white shadow"
          style={{ backgroundColor: theme.themeHex }}
        />
      </button>

      {/* Action / Status text */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-xs uppercase tracking-wider font-semibold text-slate-400">
            Current Die
          </span>
          {diceValue === 6 && (
            <span className="text-[11px] font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded-full border border-rose-500/20">
              Rolled a 6! +Bonus Turn
            </span>
          )}
        </div>

        <div className="text-sm font-bold text-white truncate mt-0.5">
          {isRolling ? (
            <span className="text-amber-400 animate-pulse">Rolling...</span>
          ) : hasRolled ? (
            <span className="text-emerald-400">
              Rolled {diceValue}! Tap a token.
            </span>
          ) : canRoll ? (
            <span className="text-amber-300">Your turn to roll!</span>
          ) : (
            <span className="text-slate-400">{disabledReason || 'Waiting for opponent...'}</span>
          )}
        </div>

        {canRoll && !hasRolled && (
          <button
            onClick={handleRollClick}
            disabled={isRolling}
            className="mt-2 w-full py-1.5 px-3 bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-white text-xs font-bold rounded-xl shadow-lg shadow-rose-500/25 active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <span>Roll Dice</span>
            <span className="text-[10px] bg-white/20 px-1 rounded font-mono">🎲</span>
          </button>
        )}
      </div>
    </div>
  );
};
