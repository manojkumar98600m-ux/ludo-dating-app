import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { GameState, LudoPlayer, User } from '../../types';
import {
  chooseBestBotMove,
  createInitialGameState,
  executeMove,
  getValidTokenMoves,
} from '../../services/ludoEngine';
import { LudoBoard } from './LudoBoard';
import { DiceRoll } from './DiceRoll';
import { sound } from '../../services/sound';
import { RotateCcw, Users, Trophy, Sparkles, Volume2, VolumeX, ShieldCheck } from 'lucide-react';

interface LocalLudoGameProps {
  currentUser: User | null;
  onNavigateToDating?: () => void;
}

export const LocalLudoGame: React.FC<LocalLudoGameProps> = ({
  currentUser,
  onNavigateToDating,
}) => {
  const [playerCount, setPlayerCount] = useState<2 | 3 | 4>(2);
  const [isPassAndPlay, setIsPassAndPlay] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  const [gameState, setGameState] = useState<GameState>(() =>
    createInitialGameState(2, currentUser?.username || 'You', currentUser?.photoUrl)
  );

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize or reset game
  const resetGame = (count: 2 | 3 | 4 = playerCount, passAndPlay: boolean = isPassAndPlay) => {
    if (timerRef.current) clearInterval(timerRef.current);

    const initial = createInitialGameState(
      count,
      currentUser?.username || 'Player 1',
      currentUser?.photoUrl
    );

    // In pass-and-play, mark all players as human (not bots)
    if (passAndPlay) {
      initial.players = initial.players.map((p, i) => ({
        ...p,
        isBot: false,
        name: i === 0 ? currentUser?.username || 'Player 1' : `Player ${i + 1}`,
      }));
    }

    setGameState(initial);
  };

  // Toggle Mute
  const handleToggleMute = () => {
    const next = !isMuted;
    setIsMuted(next);
    sound.setMuted(next);
  };

  // Check turn timer
  useEffect(() => {
    if (gameState.status !== 'playing') {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      setGameState((prev) => {
        if (prev.status !== 'playing') return prev;
        if (prev.turnTimeLeft <= 1) {
          // Time expired -> pass turn
          const curP = prev.players[prev.currentTurnIndex];
          const nextIndex = (prev.currentTurnIndex + 1) % prev.players.length;
          return {
            ...prev,
            currentTurnIndex: nextIndex,
            hasRolled: false,
            diceValue: null,
            validTokenMoves: [],
            turnTimeLeft: prev.turnDuration,
            consecutiveSixes: 0,
            lastActionLog: `${curP.name} ran out of time! Turn passed.`,
          };
        }
        return { ...prev, turnTimeLeft: prev.turnTimeLeft - 1 };
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [gameState.status, gameState.currentTurnIndex]);

  // Handle AI Bot Turn
  useEffect(() => {
    if (gameState.status !== 'playing') return;
    const currentP = gameState.players[gameState.currentTurnIndex];

    if (currentP.isBot) {
      // 1. Roll dice for bot after delay
      const rollTimeout = setTimeout(() => {
        if (gameState.hasRolled) return;

        const dice = Math.floor(Math.random() * 6) + 1;
        sound.playDiceRoll();

        const validMoves = getValidTokenMoves(currentP, dice);

        setGameState((prev) => ({
          ...prev,
          diceValue: dice,
          hasRolled: true,
          validTokenMoves: validMoves,
          lastActionLog: `${currentP.name} rolled a ${dice}!`,
        }));

        // 2. Select bot move or pass if no valid moves
        if (validMoves.length === 0) {
          setTimeout(() => {
            setGameState((prev) => {
              const nextIndex = (prev.currentTurnIndex + 1) % prev.players.length;
              return {
                ...prev,
                currentTurnIndex: nextIndex,
                hasRolled: false,
                diceValue: null,
                validTokenMoves: [],
                turnTimeLeft: prev.turnDuration,
                consecutiveSixes: 0,
                lastActionLog: `${currentP.name} has no valid moves.`,
              };
            });
          }, 1200);
        } else {
          setTimeout(() => {
            setGameState((prev) => {
              const chosenToken = chooseBestBotMove(prev, validMoves);
              const { newState, result } = executeMove(prev, chosenToken);

              if (result.captured) sound.playCapture();
              else if (result.finished) sound.playHomeFinish();
              else sound.playStep();

              if (result.gameOver) {
                sound.playVictory();
                confetti({ particleCount: 120, spread: 80, origin: { y: 0.6 } });
              }

              return newState;
            });
          }, 1200);
        }
      }, 900);

      return () => clearTimeout(rollTimeout);
    }
  }, [gameState.currentTurnIndex, gameState.hasRolled, gameState.status]);

  // Human Rolls Dice
  const handleHumanRoll = () => {
    if (gameState.hasRolled || gameState.status !== 'playing') return;
    const curP = gameState.players[gameState.currentTurnIndex];

    const dice = Math.floor(Math.random() * 6) + 1;
    const validMoves = getValidTokenMoves(curP, dice);

    setGameState((prev) => ({
      ...prev,
      diceValue: dice,
      hasRolled: true,
      validTokenMoves: validMoves,
      lastActionLog: `${curP.name} rolled a ${dice}!`,
    }));

    if (validMoves.length === 0) {
      setTimeout(() => {
        setGameState((prev) => {
          const nextIndex = (prev.currentTurnIndex + 1) % prev.players.length;
          return {
            ...prev,
            currentTurnIndex: nextIndex,
            hasRolled: false,
            diceValue: null,
            validTokenMoves: [],
            turnTimeLeft: prev.turnDuration,
            consecutiveSixes: 0,
            lastActionLog: `${curP.name} has no legal moves. Passing turn.`,
          };
        });
      }, 1400);
    }
  };

  // Human Selects Token to Move
  const handleSelectToken = (tokenIndex: number) => {
    if (!gameState.hasRolled || !gameState.validTokenMoves.includes(tokenIndex)) return;

    setGameState((prev) => {
      const { newState, result } = executeMove(prev, tokenIndex);

      if (result.captured) {
        sound.playCapture();
      } else if (result.finished) {
        sound.playHomeFinish();
      } else {
        sound.playStep();
      }

      if (result.gameOver) {
        sound.playVictory();
        confetti({ particleCount: 150, spread: 90, origin: { y: 0.6 } });
      }

      return newState;
    });
  };

  const currentP = gameState.players[gameState.currentTurnIndex];
  const isHumanTurn = !currentP.isBot;

  return (
    <div className="flex flex-col gap-3 max-w-lg mx-auto w-full px-2 py-2">
      {/* Top Header & Settings bar */}
      <div className="flex items-center justify-between bg-slate-900/90 border border-slate-800 rounded-2xl p-3 shadow-lg backdrop-blur-md">
        <div>
          <h2 className="text-base font-extrabold text-white flex items-center gap-1.5">
            <span>🎲 Classic Ludo</span>
            <span className="text-[10px] bg-rose-500/20 text-rose-300 font-bold px-2 py-0.5 rounded-full border border-rose-500/30">
              {isPassAndPlay ? 'Pass & Play' : 'Solo vs AI'}
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {gameState.playerCount} Players · Standard Tournament Rules
          </p>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={handleToggleMute}
            className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition cursor-pointer"
            title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>
          <button
            onClick={() => resetGame()}
            className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition cursor-pointer"
            title="Restart Game"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Mode selection buttons */}
      <div className="grid grid-cols-2 gap-2 text-xs">
        <button
          onClick={() => {
            setIsPassAndPlay(false);
            resetGame(playerCount, false);
          }}
          className={`py-2 px-3 rounded-xl font-bold flex items-center justify-center gap-1.5 border transition cursor-pointer ${
            !isPassAndPlay
              ? 'bg-rose-600/30 border-rose-500 text-rose-200 shadow-md'
              : 'bg-slate-900/70 border-slate-800 text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Practice vs AI Bots</span>
        </button>

        <button
          onClick={() => {
            setIsPassAndPlay(true);
            resetGame(playerCount, true);
          }}
          className={`py-2 px-3 rounded-xl font-bold flex items-center justify-center gap-1.5 border transition cursor-pointer ${
            isPassAndPlay
              ? 'bg-rose-600/30 border-rose-500 text-rose-200 shadow-md'
              : 'bg-slate-900/70 border-slate-800 text-slate-400 hover:text-slate-200'
          }`}
        >
          <Users className="w-3.5 h-3.5 text-rose-400" />
          <span>Pass & Play (Couple)</span>
        </button>
      </div>

      {/* Player Count Chips */}
      <div className="flex items-center justify-between px-2 text-xs text-slate-400">
        <span>Number of Players:</span>
        <div className="flex gap-1.5">
          {([2, 3, 4] as const).map((cnt) => (
            <button
              key={cnt}
              onClick={() => {
                setPlayerCount(cnt);
                resetGame(cnt, isPassAndPlay);
              }}
              className={`px-3 py-1 rounded-lg font-bold cursor-pointer transition ${
                playerCount === cnt
                  ? 'bg-rose-500 text-white shadow-sm'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {cnt} Players
            </button>
          ))}
        </div>
      </div>

      {/* The 15x15 SVG Ludo Board */}
      <LudoBoard
        gameState={gameState}
        onSelectToken={handleSelectToken}
        canInteract={isHumanTurn}
        highlightedTokens={gameState.validTokenMoves}
      />

      {/* Players Progress Bar (Tokens Home vs Finished) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {gameState.players.map((p, idx) => {
          const isCurrent = idx === gameState.currentTurnIndex;
          const homeTokens = p.tokens.filter((t) => t.step === -1).length;
          const finishedTokens = p.tokens.filter((t) => t.finished).length;

          return (
            <div
              key={p.id}
              className={`p-2.5 rounded-xl border transition-all ${
                isCurrent
                  ? 'bg-slate-800/90 border-amber-400 shadow-md ring-1 ring-amber-400/40'
                  : 'bg-slate-900/60 border-slate-800 opacity-80'
              }`}
            >
              <div className="flex items-center gap-1.5 truncate">
                <img
                  src={p.avatar}
                  alt={p.name}
                  className="w-5 h-5 rounded-full object-cover border border-slate-600"
                />
                <span className="text-xs font-bold text-white truncate">{p.name}</span>
              </div>
              <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
                <span>Yard: {homeTokens}</span>
                <span className="text-emerald-400 font-bold">Done: {finishedTokens}/4</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* 3D Dice and Controls */}
      <DiceRoll
        diceValue={gameState.diceValue}
        hasRolled={gameState.hasRolled}
        canRoll={isHumanTurn && !gameState.hasRolled && gameState.status === 'playing'}
        playerColor={currentP.color}
        onRoll={handleHumanRoll}
        disabledReason={currentP.isBot ? `${currentP.name} is thinking...` : undefined}
      />

      {/* Game Action Log Feed */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-2.5 text-xs text-slate-300 flex items-center justify-between">
        <div className="flex items-center gap-2 truncate">
          <span className="text-amber-400">📢</span>
          <span className="truncate">{gameState.lastActionLog}</span>
        </div>
        <div className="flex items-center gap-1 text-[11px] text-slate-500 whitespace-nowrap">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>★ 8 Safe Cells</span>
        </div>
      </div>

      {/* Game Over Victory Modal */}
      {gameState.status === 'ended' && gameState.winner && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-500/40 rounded-3xl p-6 max-w-sm w-full text-center shadow-2xl animate-in fade-in zoom-in-95">
            <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-amber-500/30">
              <Trophy className="w-8 h-8 text-white" />
            </div>

            <h3 className="text-2xl font-black text-white">Match Victory! 🏆</h3>
            <p className="text-slate-300 text-sm mt-1">
              <strong className="text-amber-400">{gameState.winner.name}</strong> brought all 4 tokens home first!
            </p>

            <div className="mt-4 p-3 rounded-2xl bg-slate-800/70 border border-slate-700/60 flex items-center justify-center gap-3">
              <img
                src={gameState.winner.avatar}
                alt={gameState.winner.name}
                className="w-12 h-12 rounded-full object-cover border-2 border-amber-400 shadow"
              />
              <div className="text-left">
                <div className="text-sm font-bold text-white">{gameState.winner.name}</div>
                <div className="text-xs text-emerald-400 font-semibold">+100 Virtual Match Coins 🪙</div>
              </div>
            </div>

            <div className="mt-6 flex flex-col gap-2">
              <button
                onClick={() => resetGame()}
                className="w-full py-3 bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-white font-bold rounded-2xl shadow-lg cursor-pointer transition active:scale-95"
              >
                Play Rematch
              </button>

              {onNavigateToDating && (
                <button
                  onClick={onNavigateToDating}
                  className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-2xl border border-slate-700 transition cursor-pointer text-sm"
                >
                  Find a Dating Match to Play Online
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
