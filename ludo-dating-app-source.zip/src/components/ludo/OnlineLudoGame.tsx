import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { GameState, PlayerColor, User } from '../../types';
import { LudoBoard } from './LudoBoard';
import { DiceRoll } from './DiceRoll';
import { sound } from '../../services/sound';
import { webrtcVoice } from '../../services/webrtc';
import {
  Mic,
  MicOff,
  Copy,
  Check,
  Send,
  Users,
  Heart,
  RotateCcw,
  Volume2,
  VolumeX,
  Play,
  ArrowLeft,
  Sparkles,
} from 'lucide-react';

interface OnlineLudoGameProps {
  currentUser: User | null;
  initialRoomCode?: string;
  onExit: () => void;
}

interface InGameChatMessage {
  sender: string;
  text?: string;
  emoji?: string;
  timestamp: string;
}

export const OnlineLudoGame: React.FC<OnlineLudoGameProps> = ({
  currentUser,
  initialRoomCode,
  onExit,
}) => {
  const [roomCode, setRoomCode] = useState<string>(initialRoomCode || '');
  const [inputCode, setInputCode] = useState<string>('');
  const [inRoom, setInRoom] = useState<boolean>(false);
  const [isHost, setIsHost] = useState<boolean>(false);
  const [myColor, setMyColor] = useState<PlayerColor>('red');
  const [copied, setCopied] = useState<boolean>(false);
  const [playerCount, setPlayerCount] = useState<2 | 3 | 4>(2);
  const [isCoupleRoom, setIsCoupleRoom] = useState<boolean>(true);

  const [gameState, setGameState] = useState<GameState | null>(null);
  const [chatMessages, setChatMessages] = useState<InGameChatMessage[]>([]);
  const [chatInput, setChatInput] = useState<string>('');
  const [floatingReaction, setFloatingReaction] = useState<{ emoji: string; sender: string } | null>(null);

  // Voice Chat State
  const [isVoiceActive, setIsVoiceActive] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  // Sound Mute
  const [isGameSoundMuted, setIsGameSoundMuted] = useState<boolean>(false);

  const socketRef = useRef<WebSocket | null>(null);
  const chatBottomRef = useRef<HTMLDivElement | null>(null);

  // Connect WebSocket
  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);
    socketRef.current = ws;

    ws.onopen = () => {
      // Authenticate socket session
      const token = localStorage.getItem('ludo_dating_token');
      if (token) {
        ws.send(JSON.stringify({ type: 'auth', token }));
      }

      if (initialRoomCode) {
        ws.send(
          JSON.stringify({
            type: 'room:join',
            roomCode: initialRoomCode,
            token,
          })
        );
      }
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);

        switch (data.type) {
          case 'room:joined':
            setInRoom(true);
            setRoomCode(data.roomCode);
            setIsHost(data.isHost);
            setMyColor(data.playerColor);
            setGameState(data.gameState);
            sound.playNotification();
            break;

          case 'room:error':
            alert(data.message || 'Room error');
            break;

          case 'room:player_joined':
            setGameState(data.gameState);
            sound.playNotification();
            break;

          case 'room:player_left':
            sound.playNotification();
            break;

          case 'game:started':
          case 'game:state':
            setGameState(data.gameState);
            break;

          case 'game:tick':
            setGameState((prev) => (prev ? { ...prev, turnTimeLeft: data.timeLeft } : prev));
            break;

          case 'game:dice_rolled':
            sound.playDiceRoll();
            setGameState(data.gameState);
            break;

          case 'game:token_moved':
            if (data.result?.captured) sound.playCapture();
            else if (data.result?.finished) sound.playHomeFinish();
            else sound.playStep();

            if (data.result?.gameOver) {
              sound.playVictory();
              confetti({ particleCount: 150, spread: 90, origin: { y: 0.6 } });
            }

            setGameState(data.gameState);
            break;

          case 'game:chat_message':
            setChatMessages((prev) => [...prev, data]);
            sound.playNotification();
            setTimeout(() => {
              chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
            }, 50);
            break;

          case 'game:reaction_received':
            setFloatingReaction({ emoji: data.emoji, sender: data.sender });
            setTimeout(() => setFloatingReaction(null), 2500);
            break;

          case 'voice:signal':
            // Pass WebRTC signal
            if (data.signal) {
              webrtcVoice.handleIncomingSignal(data.fromUserId, data.signal);
            }
            break;

          default:
            break;
        }
      } catch (err) {
        console.error('WS parse error:', err);
      }
    };

    return () => {
      ws.close();
      webrtcVoice.disableMicrophone();
    };
  }, [initialRoomCode]);

  // Setup WebRTC voice signal callback
  useEffect(() => {
    webrtcVoice.setCallbacks(
      (toPeerId, signal) => {
        if (socketRef.current?.readyState === WebSocket.OPEN) {
          socketRef.current.send(
            JSON.stringify({
              type: 'voice:signal',
              toUserId: toPeerId,
              signal,
            })
          );
        }
      },
      () => {}
    );

    // Interval to poll voice speaking activity
    const interval = setInterval(() => {
      if (webrtcVoice.hasMicrophone()) {
        const speaking = webrtcVoice.getIsSpeaking();
        setIsSpeaking(speaking);
      }
    }, 200);

    return () => clearInterval(interval);
  }, []);

  // Voice Chat Toggle
  const toggleVoice = async () => {
    if (!isVoiceActive) {
      const ok = await webrtcVoice.enableMicrophone();
      if (ok) {
        setIsVoiceActive(true);
        setIsMuted(false);
        sound.playNotification();
      } else {
        alert('Microphone permission denied or device not supported.');
      }
    } else {
      webrtcVoice.disableMicrophone();
      setIsVoiceActive(false);
    }
  };

  const toggleMute = () => {
    const muted = webrtcVoice.toggleMute();
    setIsMuted(muted);
  };

  // Create Room
  const handleCreateRoom = (mode: 'casual' | 'couple') => {
    const token = localStorage.getItem('ludo_dating_token');
    const customCode = `LUDO-${Math.floor(1000 + Math.random() * 9000)}`;
    socketRef.current?.send(
      JSON.stringify({
        type: 'room:create',
        playerCount: mode === 'couple' ? 2 : playerCount,
        isCoupleRoom: mode === 'couple',
        customCode,
        token,
      })
    );
  };

  // Join Room
  const handleJoinRoom = () => {
    if (!inputCode.trim()) return;
    const token = localStorage.getItem('ludo_dating_token');
    socketRef.current?.send(
      JSON.stringify({
        type: 'room:join',
        roomCode: inputCode.trim(),
        token,
      })
    );
  };

  // Start Room Game
  const handleStartGame = () => {
    socketRef.current?.send(JSON.stringify({ type: 'room:start' }));
  };

  // Roll Dice
  const handleRollDice = () => {
    socketRef.current?.send(JSON.stringify({ type: 'game:roll' }));
  };

  // Move Token
  const handleSelectToken = (tokenIndex: number) => {
    socketRef.current?.send(
      JSON.stringify({
        type: 'game:move',
        tokenIndex,
      })
    );
  };

  // Send Chat Message
  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    socketRef.current?.send(
      JSON.stringify({
        type: 'game:chat',
        senderName: currentUser?.username || 'Player',
        text: chatInput.trim(),
      })
    );
    setChatInput('');
  };

  // Send Quick Reaction Emoji
  const handleSendReaction = (emoji: string) => {
    socketRef.current?.send(
      JSON.stringify({
        type: 'game:reaction',
        senderName: currentUser?.username || 'Player',
        emoji,
      })
    );
  };

  // Copy Room Link / Code
  const handleCopyCode = () => {
    navigator.clipboard.writeText(roomCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // View: Room Lobby Setup (Before Joining)
  if (!inRoom || !gameState) {
    return (
      <div className="max-w-md mx-auto w-full px-3 py-4 flex flex-col gap-4">
        {/* Back navigation */}
        <button
          onClick={onExit}
          className="flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-white transition cursor-pointer self-start"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>

        {/* Hero Card */}
        <div className="bg-gradient-to-br from-rose-950/70 via-slate-900 to-slate-950 border border-rose-500/30 rounded-3xl p-5 shadow-2xl text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-rose-500 to-amber-500 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-rose-500/30">
            <Heart className="w-8 h-8 text-white fill-current animate-pulse" />
          </div>
          <h2 className="text-xl font-black text-white">Online Multiplayer & Voice</h2>
          <p className="text-xs text-rose-200/80 mt-1 max-w-xs mx-auto">
            Create a private Couple Date room with live voice chat, or play standard 2–4 player Ludo with friends!
          </p>
        </div>

        {/* 1. Couple 1-on-1 Date Room */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 shadow-xl flex flex-col gap-3">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-rose-500/20 text-rose-400">❤️</span>
            <div>
              <h3 className="text-sm font-bold text-white">Couple 1-on-1 Date Room</h3>
              <p className="text-[11px] text-slate-400">2-Player classic game with private voice chat</p>
            </div>
          </div>

          <button
            onClick={() => handleCreateRoom('couple')}
            className="w-full py-3 bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white font-bold rounded-2xl shadow-lg shadow-rose-600/30 transition cursor-pointer active:scale-95 flex items-center justify-center gap-2 text-sm"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>Create Couple Date Room</span>
          </button>
        </div>

        {/* 2. Custom 2-4 Player Room */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 shadow-xl flex flex-col gap-3">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-500/20 text-amber-400">🎲</span>
            <div>
              <h3 className="text-sm font-bold text-white">Standard 2–4 Player Room</h3>
              <p className="text-[11px] text-slate-400">Custom match with multiple friends or date double</p>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Players:</span>
            <div className="flex gap-2">
              {([2, 3, 4] as const).map((cnt) => (
                <button
                  key={cnt}
                  onClick={() => setPlayerCount(cnt)}
                  className={`px-3 py-1 rounded-xl font-bold cursor-pointer transition ${
                    playerCount === cnt
                      ? 'bg-amber-500 text-slate-950 shadow'
                      : 'bg-slate-800 text-slate-300 hover:text-white'
                  }`}
                >
                  {cnt} Players
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={() => handleCreateRoom('casual')}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-2xl border border-slate-700 transition cursor-pointer text-xs"
          >
            Create {playerCount}-Player Room
          </button>
        </div>

        {/* 3. Join with Code */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 shadow-xl flex flex-col gap-2.5">
          <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
            <Users className="w-4 h-4 text-blue-400" />
            <span>Join with Room Code</span>
          </h3>

          <div className="flex gap-2">
            <input
              type="text"
              placeholder="e.g. LUDO-4921"
              value={inputCode}
              onChange={(e) => setInputCode(e.target.value.toUpperCase())}
              className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-sm uppercase tracking-wider focus:outline-none focus:border-rose-500"
            />
            <button
              onClick={handleJoinRoom}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl shadow-md cursor-pointer transition text-xs"
            >
              Join
            </button>
          </div>
        </div>
      </div>
    );
  }

  // View: Active Online Room
  const currentP = gameState.players[gameState.currentTurnIndex];
  const isMyTurn = currentP && currentP.color === myColor;

  return (
    <div className="flex flex-col gap-3 max-w-lg mx-auto w-full px-2 py-2">
      {/* Floating Reaction Animation */}
      {floatingReaction && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-50 pointer-events-none animate-bounce">
          <div className="bg-slate-900/90 backdrop-blur-md border border-rose-500/40 px-4 py-2 rounded-2xl shadow-2xl flex items-center gap-2">
            <span className="text-3xl">{floatingReaction.emoji}</span>
            <span className="text-xs font-bold text-white">{floatingReaction.sender} reacted!</span>
          </div>
        </div>
      )}

      {/* Top Room Bar: Code, Voice Chat HUD & Sound */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3 shadow-lg flex items-center justify-between backdrop-blur-md">
        <div>
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-mono font-bold bg-slate-800 text-rose-300 px-2 py-0.5 rounded-lg border border-slate-700">
              {roomCode}
            </span>
            <button
              onClick={handleCopyCode}
              className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
              title="Copy Room Code"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5 flex items-center gap-1">
            <span>You:</span>
            <span className="font-bold uppercase tracking-wider text-amber-400">{myColor}</span>
          </div>
        </div>

        {/* Voice Chat Control */}
        <div className="flex items-center gap-2">
          <button
            onClick={toggleVoice}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer border ${
              isVoiceActive
                ? isSpeaking
                  ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 shadow-md animate-pulse'
                  : 'bg-emerald-600/30 border-emerald-500 text-emerald-200'
                : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
          >
            {isVoiceActive ? <Mic className="w-3.5 h-3.5 text-emerald-400" /> : <MicOff className="w-3.5 h-3.5" />}
            <span>{isVoiceActive ? (isMuted ? 'Muted' : 'Voice Live') : 'Enable Voice'}</span>
          </button>

          {isVoiceActive && (
            <button
              onClick={toggleMute}
              className={`p-1.5 rounded-xl border text-xs cursor-pointer ${
                isMuted
                  ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                  : 'bg-slate-800 border-slate-700 text-slate-300'
              }`}
            >
              {isMuted ? 'Unmute' : 'Mute'}
            </button>
          )}

          <button
            onClick={onExit}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
            title="Leave Room"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Waiting Lobby Banner (if waiting for players to start) */}
      {gameState.status === 'waiting' && (
        <div className="bg-gradient-to-r from-amber-500/20 via-rose-500/20 to-purple-500/20 border border-amber-500/30 rounded-2xl p-4 text-center flex flex-col gap-2">
          <h3 className="text-sm font-bold text-amber-200">Room Ready!</h3>
          <p className="text-xs text-slate-300">
            Share code <strong className="text-white font-mono">{roomCode}</strong> with your partner/friends.
            Empty slots will be played by friendly bots if you start now.
          </p>

          {isHost ? (
            <button
              onClick={handleStartGame}
              className="py-2.5 px-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl shadow-lg transition cursor-pointer flex items-center justify-center gap-1.5 text-xs mx-auto"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Start Match Now</span>
            </button>
          ) : (
            <span className="text-xs text-slate-400 italic">Waiting for host to click Start...</span>
          )}
        </div>
      )}

      {/* Synchronized Ludo Board */}
      <LudoBoard
        gameState={gameState}
        onSelectToken={handleSelectToken}
        canInteract={isMyTurn && gameState.status === 'playing'}
        highlightedTokens={isMyTurn ? gameState.validTokenMoves : []}
      />

      {/* Players Progress Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {gameState.players.map((p, idx) => {
          const isCurrent = idx === gameState.currentTurnIndex;
          const homeTokens = p.tokens.filter((t) => t.step === -1).length;
          const finishedTokens = p.tokens.filter((t) => t.finished).length;

          return (
            <div
              key={p.id}
              className={`p-2 rounded-xl border transition-all ${
                isCurrent
                  ? 'bg-slate-800/90 border-amber-400 shadow-md ring-1 ring-amber-400/30'
                  : 'bg-slate-900/60 border-slate-800 opacity-80'
              }`}
            >
              <div className="flex items-center gap-1.5 truncate">
                <img
                  src={p.avatar}
                  alt={p.name}
                  className="w-5 h-5 rounded-full object-cover border border-slate-600"
                />
                <span className="text-xs font-bold text-white truncate">{p.name}</span>
                {p.color === myColor && <span className="text-[9px] text-amber-400">(You)</span>}
              </div>
              <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1">
                <span>Yard: {homeTokens}</span>
                <span className="text-emerald-400 font-bold">Done: {finishedTokens}/4</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* 3D Dice */}
      <DiceRoll
        diceValue={gameState.diceValue}
        hasRolled={gameState.hasRolled}
        canRoll={isMyTurn && !gameState.hasRolled && gameState.status === 'playing'}
        playerColor={currentP.color}
        onRoll={handleRollDice}
        disabledReason={
          gameState.status === 'waiting'
            ? 'Waiting to start game'
            : !isMyTurn
            ? `Waiting for ${currentP.name}...`
            : undefined
        }
      />

      {/* Romantic / Fun Quick Reaction Bar */}
      <div className="flex items-center justify-between bg-slate-900/80 border border-slate-800 rounded-2xl px-3 py-2">
        <span className="text-[11px] font-bold text-slate-400">Reaction:</span>
        <div className="flex gap-2">
          {['❤️', '😂', '🔥', '🎲', '👏', '💍'].map((emoji) => (
            <button
              key={emoji}
              onClick={() => handleSendReaction(emoji)}
              className="text-lg hover:scale-125 active:scale-95 transition cursor-pointer p-1 rounded-lg hover:bg-slate-800"
            >
              {emoji}
            </button>
          ))}
        </div>
      </div>

      {/* Room In-Game Chat Feed */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3 shadow-lg flex flex-col gap-2">
        <div className="text-xs font-bold text-slate-400 flex items-center justify-between">
          <span>Room Chat</span>
          <span className="text-[10px] text-slate-500">Live with players</span>
        </div>

        <div className="h-24 overflow-y-auto flex flex-col gap-1.5 text-xs pr-1">
          {chatMessages.length === 0 ? (
            <span className="text-slate-500 italic my-auto text-center">
              Say hi or send an encouraging message to your date!
            </span>
          ) : (
            chatMessages.map((msg, i) => (
              <div key={i} className="flex items-baseline gap-1.5">
                <span className="font-bold text-rose-300">{msg.sender}:</span>
                <span className="text-slate-200">{msg.text}</span>
                <span className="text-[9px] text-slate-500 ml-auto">{msg.timestamp}</span>
              </div>
            ))
          )}
          <div ref={chatBottomRef} />
        </div>

        <form onSubmit={handleSendChat} className="flex gap-2">
          <input
            type="text"
            placeholder="Type a message..."
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            maxLength={120}
            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-rose-500"
          />
          <button
            type="submit"
            className="p-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white transition cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
