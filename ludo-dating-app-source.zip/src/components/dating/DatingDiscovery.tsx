import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { DatingProfile, Match, User } from '../../types';
import { api } from '../../services/api';
import { sound } from '../../services/sound';
import {
  Heart,
  X,
  Star,
  ShieldCheck,
  MapPin,
  Trophy,
  Dices,
  Sparkles,
  Flag,
  MessageCircle,
  Play,
} from 'lucide-react';

interface DatingDiscoveryProps {
  currentUser: User | null;
  onOpenChatWithMatch: (match: Match) => void;
  onInviteToLudo: (otherUserId: string) => void;
  onReportUser: (targetUser: DatingProfile) => void;
}

export const DatingDiscovery: React.FC<DatingDiscoveryProps> = ({
  currentUser,
  onOpenChatWithMatch,
  onInviteToLudo,
  onReportUser,
}) => {
  const [profiles, setProfiles] = useState<DatingProfile[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);
  const [swipeAnimation, setSwipeAnimation] = useState<'like' | 'pass' | null>(null);
  const [currentMatch, setCurrentMatch] = useState<Match | null>(null);

  useEffect(() => {
    loadProfiles();
  }, []);

  const loadProfiles = async () => {
    setLoading(true);
    try {
      const data = await api.getDiscoverProfiles();
      setProfiles(data.profiles);
      setCurrentIndex(0);
    } catch (err) {
      console.error('Failed to load discovery profiles:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSwipe = async (action: 'like' | 'pass') => {
    if (currentIndex >= profiles.length) return;
    const profile = profiles[currentIndex];

    setSwipeAnimation(action);
    if (action === 'like') {
      sound.playNotification();
    }

    try {
      const res = await api.swipe(profile.id, action);
      if (res.isMatch && res.match) {
        sound.playVictory();
        confetti({ particleCount: 120, spread: 80, origin: { y: 0.6 } });
        setCurrentMatch(res.match);
      }
    } catch (err) {
      console.error('Swipe error:', err);
    }

    setTimeout(() => {
      setSwipeAnimation(null);
      setCurrentIndex((prev) => prev + 1);
    }, 280);
  };

  const currentProfile = profiles[currentIndex];

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[420px] text-slate-400 gap-3">
        <div className="w-10 h-10 border-4 border-rose-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-sm font-semibold">Finding Ludo players near you...</span>
      </div>
    );
  }

  if (!currentProfile) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[420px] text-center p-6 bg-slate-900/60 border border-slate-800 rounded-3xl max-w-sm mx-auto">
        <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center mb-3">
          <Sparkles className="w-8 h-8 text-amber-400" />
        </div>
        <h3 className="text-lg font-bold text-white">You&apos;ve seen all matches!</h3>
        <p className="text-xs text-slate-400 mt-1 max-w-xs">
          New single Ludo players join daily. Reset your discovery stack to explore players again!
        </p>
        <button
          onClick={loadProfiles}
          className="mt-4 px-6 py-2.5 bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white font-bold rounded-2xl shadow-lg cursor-pointer text-xs"
        >
          Explore Again
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-sm mx-auto w-full px-2 py-2 flex flex-col gap-3">
      {/* Dating Profile Card */}
      <div
        className={`relative aspect-[3/4] w-full rounded-3xl overflow-hidden shadow-2xl border border-slate-800 transition-all duration-300 ${
          swipeAnimation === 'like'
            ? 'translate-x-32 rotate-12 opacity-0'
            : swipeAnimation === 'pass'
            ? '-translate-x-32 -rotate-12 opacity-0'
            : ''
        }`}
      >
        {/* Profile Image */}
        <img
          src={currentProfile.photoUrl}
          alt={currentProfile.username}
          className="w-full h-full object-cover"
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent pointer-events-none" />

        {/* Top Badges: Age Verification & Report */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950/70 backdrop-blur-md border border-emerald-500/40 text-[11px] font-bold text-emerald-400 shadow">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>18+ Verified</span>
          </div>

          <button
            onClick={() => onReportUser(currentProfile)}
            className="p-2 rounded-full bg-slate-950/70 backdrop-blur-md border border-slate-700/60 text-slate-400 hover:text-rose-400 transition cursor-pointer"
            title="Report or Block User"
          >
            <Flag className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Bottom Profile Details */}
        <div className="absolute bottom-0 left-0 right-0 p-5 flex flex-col gap-2">
          {/* Name, Age, Distance */}
          <div>
            <div className="flex items-baseline gap-2">
              <h2 className="text-2xl font-black text-white">{currentProfile.username}</h2>
              <span className="text-xl font-bold text-rose-300">{currentProfile.age}</span>
            </div>

            <div className="flex items-center gap-3 text-xs text-slate-300 mt-1">
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-rose-400" />
                {currentProfile.city} · {currentProfile.distanceKm} km away
              </span>
              <span className="text-amber-400 font-semibold">
                ★ {currentProfile.matchCompatibility}% Match
              </span>
            </div>
          </div>

          {/* Ludo Gaming Stats */}
          <div className="flex items-center gap-3 p-2 rounded-xl bg-slate-900/80 backdrop-blur-md border border-slate-800 text-xs text-slate-300">
            <span className="flex items-center gap-1.5 text-amber-300 font-bold">
              <Trophy className="w-3.5 h-3.5" />
              {currentProfile.ludoWins} Wins
            </span>
            <span className="text-slate-600">|</span>
            <span className="flex items-center gap-1 text-slate-300">
              <Dices className="w-3.5 h-3.5 text-blue-400" />
              {currentProfile.ludoGames} Matches
            </span>
          </div>

          {/* Bio */}
          <p className="text-xs text-slate-200 line-clamp-3 leading-relaxed">
            {currentProfile.bio}
          </p>

          {/* Interest Chips */}
          <div className="flex flex-wrap gap-1.5 mt-0.5">
            {currentProfile.interests.slice(0, 4).map((tag, i) => (
              <span
                key={i}
                className="text-[10px] font-semibold bg-white/10 backdrop-blur-md border border-white/15 px-2 py-0.5 rounded-lg text-slate-200"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Swipe Action Controls: Pass, Super Like, Like */}
      <div className="flex items-center justify-center gap-5 mt-1">
        <button
          onClick={() => handleSwipe('pass')}
          className="w-14 h-14 rounded-full bg-slate-900 border border-slate-800 text-rose-400 hover:bg-rose-500/10 hover:border-rose-500 shadow-xl flex items-center justify-center cursor-pointer transition active:scale-90"
          title="Pass"
        >
          <X className="w-6 h-6 stroke-[2.5]" />
        </button>

        <button
          onClick={() => {
            sound.playStep();
            handleSwipe('like');
          }}
          className="w-12 h-12 rounded-full bg-slate-900 border border-slate-800 text-amber-400 hover:bg-amber-500/10 hover:border-amber-500 shadow-xl flex items-center justify-center cursor-pointer transition active:scale-90"
          title="Super Like"
        >
          <Star className="w-5 h-5 fill-current" />
        </button>

        <button
          onClick={() => handleSwipe('like')}
          className="w-16 h-16 rounded-full bg-gradient-to-tr from-rose-600 to-pink-600 text-white shadow-xl shadow-rose-600/30 flex items-center justify-center cursor-pointer hover:scale-105 active:scale-95 transition"
          title="Like"
        >
          <Heart className="w-8 h-8 fill-current" />
        </button>
      </div>

      {/* Match Celebratory Dialog */}
      {currentMatch && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-500/50 rounded-3xl p-6 max-w-sm w-full text-center shadow-2xl animate-in fade-in zoom-in-95">
            <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-rose-500 to-pink-500 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-rose-500/40">
              <Heart className="w-8 h-8 text-white fill-current animate-bounce" />
            </div>

            <h3 className="text-2xl font-black text-white">It&apos;s a Match! ❤️</h3>
            <p className="text-slate-300 text-xs mt-1">
              You and <strong className="text-rose-400">{currentMatch.otherUser.username}</strong> liked each other!
            </p>

            <div className="flex items-center justify-center gap-4 my-5">
              <img
                src={currentUser?.photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                alt="You"
                className="w-16 h-16 rounded-full object-cover border-2 border-rose-500 shadow-lg"
              />
              <span className="text-2xl text-amber-400 animate-pulse">🎲</span>
              <img
                src={currentMatch.otherUser.photoUrl}
                alt={currentMatch.otherUser.username}
                className="w-16 h-16 rounded-full object-cover border-2 border-rose-500 shadow-lg"
              />
            </div>

            <div className="flex flex-col gap-2">
              <button
                onClick={() => {
                  const m = currentMatch;
                  setCurrentMatch(null);
                  onInviteToLudo(m.otherUser.id);
                }}
                className="w-full py-3 bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white font-bold rounded-2xl shadow-lg transition cursor-pointer flex items-center justify-center gap-2 text-sm"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Play Ludo Date Room</span>
              </button>

              <button
                onClick={() => {
                  const m = currentMatch;
                  setCurrentMatch(null);
                  onOpenChatWithMatch(m);
                }}
                className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-2xl border border-slate-700 transition cursor-pointer text-xs flex items-center justify-center gap-1.5"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Send a Chat Message</span>
              </button>

              <button
                onClick={() => setCurrentMatch(null)}
                className="text-xs text-slate-400 hover:text-white mt-1"
              >
                Keep Swiping
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
