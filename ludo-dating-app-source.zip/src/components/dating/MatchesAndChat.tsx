import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage, Match, User } from '../../types';
import { api } from '../../services/api';
import { sound } from '../../services/sound';
import {
  Send,
  Gift,
  Dices,
  Flag,
  ArrowLeft,
  Sparkles,
  Check,
  CheckCheck,
  Phone,
  Video,
  Image as ImageIcon,
  Mic,
  Trash2,
  StopCircle,
} from 'lucide-react';

interface MatchesAndChatProps {
  currentUser: User | null;
  selectedMatch: Match | null;
  onSelectMatch: (match: Match | null) => void;
  onStartLudoWithRoom: (roomCode: string) => void;
  onStartCall: (targetUser: User, callType: 'voice' | 'video') => void;
  onReportUser: (targetUser: User) => void;
  onUserCoinsUpdated: (coins: number) => void;
}

export const MatchesAndChat: React.FC<MatchesAndChatProps> = ({
  currentUser,
  selectedMatch,
  onSelectMatch,
  onStartLudoWithRoom,
  onStartCall,
  onReportUser,
  onUserCoinsUpdated,
}) => {
  const [matches, setMatches] = useState<Match[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState<string>('');
  const [showGiftDrawer, setShowGiftDrawer] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);

  // Audio Voice Note Recording
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const chatEndRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    loadMatches();
  }, []);

  const loadMatches = async () => {
    try {
      const data = await api.getMatches();
      setMatches(data.matches);
    } catch (err) {
      console.error('Failed to load matches:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedMatch) {
      loadMessages(selectedMatch.otherUser.id);
    }
  }, [selectedMatch]);

  const loadMessages = async (otherUserId: string) => {
    try {
      const data = await api.getMessages(otherUserId);
      setMessages(data.messages);
      setTimeout(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 50);
    } catch (err) {
      console.error('Failed to load messages:', err);
    }
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if ((!inputText.trim() && !selectedPhoto) || !selectedMatch) return;

    const textToSend = inputText.trim();
    const photoToSend = selectedPhoto;

    setInputText('');
    setSelectedPhoto(null);

    try {
      sound.playStep();
      const res = await api.sendMessage({
        recipientId: selectedMatch.otherUser.id,
        text: textToSend,
        photoUrl: photoToSend || undefined,
      });
      setMessages((prev) => [...prev, res.message]);
      setTimeout(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 50);
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Error sending message');
    }
  };

  // Voice Note Recording
  const startRecordingVoice = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = async () => {
          const base64Audio = reader.result as string;
          if (selectedMatch) {
            try {
              sound.playStep();
              const res = await api.sendMessage({
                recipientId: selectedMatch.otherUser.id,
                audioUrl: base64Audio,
                text: '🎙️ Voice Message',
              });
              setMessages((prev) => [...prev, res.message]);
              setTimeout(() => {
                chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
              }, 50);
            } catch (err) {
              console.error(err);
            }
          }
        };
        stream.getTracks().forEach((track) => track.stop());
      };

      recorder.start();
      setIsRecording(true);
    } catch {
      alert('Microphone access is required to record voice notes.');
    }
  };

  const stopRecordingVoice = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  // Photo Attachment Handler
  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setSelectedPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Delete message
  const handleDeleteMessage = async (msgId: string) => {
    try {
      sound.playStep();
      await api.deleteMessage(msgId);
      setMessages((prev) => prev.filter((m) => m.id !== msgId));
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Delete error');
    }
  };

  // Virtual Gift
  const handleSendGift = async (giftType: string, giftName: string, cost: number) => {
    if (!selectedMatch) return;
    if ((currentUser?.coins || 0) < cost) {
      alert(`You need ${cost} virtual coins to send a ${giftName}. Check your profile or subscription!`);
      return;
    }

    try {
      sound.playNotification();
      const res = await api.sendMessage({
        recipientId: selectedMatch.otherUser.id,
        giftType,
        text: `Sent a virtual ${giftName}! 🎁`,
      });

      if (res.remainingCoins !== undefined) {
        onUserCoinsUpdated(res.remainingCoins);
      }

      setMessages((prev) => [...prev, res.message]);
      setShowGiftDrawer(false);
      setTimeout(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 50);
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Gift error');
    }
  };

  // Ludo Invite
  const handleSendGameInvite = async () => {
    if (!selectedMatch) return;
    const roomCode = `DATE-${Math.floor(1000 + Math.random() * 9000)}`;

    try {
      sound.playNotification();
      const res = await api.sendMessage({
        recipientId: selectedMatch.otherUser.id,
        gameInviteRoomId: roomCode,
        text: `Let's play a romantic 1-on-1 Ludo match! Room: ${roomCode} 🎲❤️`,
      });

      setMessages((prev) => [...prev, res.message]);
      setTimeout(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 50);
    } catch (err) {
      console.error('Invite error:', err);
    }
  };

  // View: Conversation Thread
  if (selectedMatch) {
    const other = selectedMatch.otherUser;

    return (
      <div className="flex flex-col h-[600px] max-w-md mx-auto w-full bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
        {/* Chat Header with Voice Call & Video Call */}
        <div className="flex items-center justify-between p-3.5 bg-slate-950/90 border-b border-slate-800 backdrop-blur-md">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => onSelectMatch(null)}
              className="p-1 rounded-xl text-slate-400 hover:text-white transition cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            <div className="relative">
              <img
                src={other.photoUrl}
                alt={other.username}
                className="w-10 h-10 rounded-full object-cover border border-rose-500"
              />
              <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-slate-950" />
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-bold text-white">{other.username}</span>
                <span className="text-xs text-rose-300 font-semibold">{other.age}</span>
              </div>
              <span className="text-[10px] text-emerald-400 font-medium">Online · Private Chat</span>
            </div>
          </div>

          {/* Action Icons: Voice Call, Video Call, Ludo Invite, Report */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => onStartCall(other, 'voice')}
              className="p-2 rounded-xl bg-slate-800 hover:bg-emerald-600 hover:text-white text-slate-300 transition cursor-pointer"
              title="Start Voice Call"
            >
              <Phone className="w-4 h-4" />
            </button>

            <button
              onClick={() => onStartCall(other, 'video')}
              className="p-2 rounded-xl bg-slate-800 hover:bg-blue-600 hover:text-white text-slate-300 transition cursor-pointer"
              title="Start Video Call"
            >
              <Video className="w-4 h-4" />
            </button>

            <button
              onClick={handleSendGameInvite}
              className="p-2 rounded-xl bg-gradient-to-r from-amber-500 to-rose-500 text-white shadow-md transition cursor-pointer"
              title="Invite to Play Ludo"
            >
              <Dices className="w-4 h-4" />
            </button>

            <button
              onClick={() => onReportUser(other)}
              className="p-2 rounded-xl text-slate-400 hover:text-rose-400 transition cursor-pointer"
              title="Report or Block"
            >
              <Flag className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Messages Scroll Area */}
        <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3 bg-gradient-to-b from-slate-950/40 to-slate-900/60">
          <div className="text-center my-1 p-2.5 rounded-2xl bg-slate-900/70 border border-slate-800 text-[11px] text-slate-400 max-w-xs mx-auto">
            <span>🔒 Messages and calls are private and encrypted.</span>
          </div>

          {messages.map((m) => {
            const isMe = m.senderId === currentUser?.id;

            return (
              <div
                key={m.id}
                className={`group flex flex-col max-w-[85%] ${
                  isMe ? 'self-end items-end' : 'self-start items-start'
                }`}
              >
                {/* Ludo Game Invite */}
                {m.gameInviteRoomId ? (
                  <div className="p-3.5 rounded-2xl bg-gradient-to-br from-rose-950 via-slate-900 to-purple-950 border border-rose-500/40 shadow-xl flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold">
                        🎲
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">Couple Ludo Challenge!</div>
                        <div className="text-[10px] text-rose-300 font-mono">Room: {m.gameInviteRoomId}</div>
                      </div>
                    </div>
                    <p className="text-xs text-slate-300">{m.text}</p>
                    <button
                      onClick={() => onStartLudoWithRoom(m.gameInviteRoomId!)}
                      className="w-full py-1.5 bg-gradient-to-r from-rose-600 to-amber-600 text-white text-xs font-bold rounded-xl shadow cursor-pointer transition active:scale-95"
                    >
                      Join Ludo Match Now
                    </button>
                  </div>
                ) : m.photoUrl ? (
                  /* Photo Message */
                  <div className="flex flex-col gap-1">
                    <img
                      src={m.photoUrl}
                      alt="Attachment"
                      className="max-w-[240px] max-h-[240px] rounded-2xl object-cover border border-slate-700 shadow-md"
                    />
                    {m.text && <p className="text-xs text-slate-200 mt-1">{m.text}</p>}
                  </div>
                ) : m.audioUrl ? (
                  /* Voice Note Message */
                  <div
                    className={`p-3 rounded-2xl border flex items-center gap-2.5 ${
                      isMe ? 'bg-rose-600/30 border-rose-500/40 text-white' : 'bg-slate-800 border-slate-700 text-slate-200'
                    }`}
                  >
                    <span className="text-xl">🎙️</span>
                    <audio controls src={m.audioUrl} className="h-8 max-w-[200px]" />
                  </div>
                ) : m.giftType ? (
                  /* Virtual Gift */
                  <div
                    className={`p-3 rounded-2xl border flex items-center gap-2.5 ${
                      isMe ? 'bg-rose-600/30 border-rose-500/40 text-white' : 'bg-slate-800 border-slate-700 text-slate-200'
                    }`}
                  >
                    <span className="text-2xl">
                      {m.giftType === 'rose'
                        ? '🌹'
                        : m.giftType === 'chocolate'
                        ? '🍫'
                        : m.giftType === 'letter'
                        ? '💌'
                        : '💍'}
                    </span>
                    <div>
                      <div className="text-xs font-bold">{m.text}</div>
                      <div className="text-[10px] text-amber-400 font-medium">Virtual Romantic Gift</div>
                    </div>
                  </div>
                ) : (
                  /* Standard Text */
                  <div
                    className={`px-3.5 py-2 rounded-2xl text-xs leading-relaxed ${
                      isMe
                        ? 'bg-rose-600 text-white rounded-br-none'
                        : 'bg-slate-800 text-slate-200 rounded-bl-none border border-slate-700/60'
                    }`}
                  >
                    {m.text}
                  </div>
                )}

                {/* Timestamp, Read Status, & Delete Option */}
                <div className="flex items-center gap-1.5 text-[9px] text-slate-500 mt-0.5 px-1">
                  <span>
                    {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                  {isMe && (
                    <span>
                      {m.status === 'read' ? (
                        <CheckCheck className="w-3 h-3 text-rose-400" />
                      ) : (
                        <Check className="w-3 h-3 text-slate-400" />
                      )}
                    </span>
                  )}
                  {isMe && (
                    <button
                      onClick={() => handleDeleteMessage(m.id)}
                      className="opacity-0 group-hover:opacity-100 hover:text-rose-400 transition cursor-pointer ml-1"
                      title="Delete message"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
          <div ref={chatEndRef} />
        </div>

        {/* Selected Photo Preview */}
        {selectedPhoto && (
          <div className="p-2 bg-slate-950 border-t border-slate-800 flex items-center gap-3">
            <img src={selectedPhoto} alt="Selected" className="w-12 h-12 rounded-xl object-cover border border-rose-500" />
            <span className="text-xs text-slate-300">Photo attached ready to send</span>
            <button
              onClick={() => setSelectedPhoto(null)}
              className="ml-auto text-xs text-rose-400 font-bold hover:underline cursor-pointer"
            >
              Remove
            </button>
          </div>
        )}

        {/* Virtual Gifts Drawer */}
        {showGiftDrawer && (
          <div className="p-3 bg-slate-950 border-t border-slate-800 flex flex-col gap-2 animate-in slide-in-from-bottom-5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-white flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Send a Virtual Gift (Virtual Coins Only)</span>
              </span>
              <span className="text-amber-400 font-mono font-bold">
                Balance: {currentUser?.coins || 0} 🪙
              </span>
            </div>

            <div className="grid grid-cols-4 gap-2">
              {[
                { type: 'rose', name: 'Rose', icon: '🌹', cost: 50 },
                { type: 'chocolate', name: 'Chocolate', icon: '🍫', cost: 100 },
                { type: 'letter', name: 'Letter', icon: '💌', cost: 150 },
                { type: 'ring', name: 'Ring', icon: '💍', cost: 500 },
              ].map((g) => (
                <button
                  key={g.type}
                  onClick={() => handleSendGift(g.type, g.name, g.cost)}
                  className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-rose-500/50 hover:bg-slate-800 text-center flex flex-col items-center gap-1 transition cursor-pointer active:scale-95"
                >
                  <span className="text-2xl">{g.icon}</span>
                  <span className="text-[10px] font-bold text-white">{g.name}</span>
                  <span className="text-[9px] text-amber-400 font-mono">{g.cost} 🪙</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Chat Input Bar */}
        <form
          onSubmit={handleSendMessage}
          className="p-2.5 bg-slate-950 border-t border-slate-800 flex items-center gap-2"
        >
          {/* Virtual Gift Button */}
          <button
            type="button"
            onClick={() => setShowGiftDrawer(!showGiftDrawer)}
            className={`p-2 rounded-xl transition cursor-pointer ${
              showGiftDrawer ? 'bg-rose-500 text-white' : 'bg-slate-800 text-slate-400 hover:text-rose-400'
            }`}
            title="Send Virtual Gift"
          >
            <Gift className="w-4 h-4" />
          </button>

          {/* Photo Upload Attachment Button */}
          <input
            type="file"
            accept="image/*"
            ref={fileInputRef}
            onChange={handlePhotoSelect}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-blue-400 transition cursor-pointer"
            title="Attach Photo"
          >
            <ImageIcon className="w-4 h-4" />
          </button>

          {/* Voice Note Button */}
          {isRecording ? (
            <button
              type="button"
              onClick={stopRecordingVoice}
              className="p-2 rounded-xl bg-rose-600 text-white animate-pulse transition cursor-pointer flex items-center gap-1 text-xs"
              title="Stop and Send Voice Note"
            >
              <StopCircle className="w-4 h-4" />
              <span>Recording...</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={startRecordingVoice}
              className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-emerald-400 transition cursor-pointer"
              title="Record Voice Note"
            >
              <Mic className="w-4 h-4" />
            </button>
          )}

          {/* Text Input */}
          <input
            type="text"
            placeholder="Type your message..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-rose-500"
          />

          <button
            type="submit"
            disabled={!inputText.trim() && !selectedPhoto}
            className="p-2 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-white transition cursor-pointer shadow"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    );
  }

  // View: Matches & Conversations List
  return (
    <div className="max-w-md mx-auto w-full px-2 py-2 flex flex-col gap-4">
      {/* Top Banner */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black text-white">Matches & Chats</h2>
          <p className="text-xs text-slate-400">Connect, call, and play with your matches</p>
        </div>
        <div className="px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs text-amber-400 font-bold flex items-center gap-1">
          <span>🪙 {currentUser?.coins || 0}</span>
        </div>
      </div>

      {/* Horizontal Matches Row */}
      <div className="flex flex-col gap-2">
        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
          New Matches ({matches.length})
        </span>

        {loading ? (
          <div className="text-xs text-slate-500 py-3">Loading matches...</div>
        ) : matches.length === 0 ? (
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 text-center text-xs text-slate-400">
            No matches yet! Swipe right on players in Discovery to get matches.
          </div>
        ) : (
          <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-none">
            {matches.map((m) => (
              <button
                key={m.id}
                onClick={() => onSelectMatch(m)}
                className="flex flex-col items-center gap-1 flex-shrink-0 cursor-pointer group"
              >
                <div className="relative">
                  <img
                    src={m.otherUser.photoUrl}
                    alt={m.otherUser.username}
                    className="w-14 h-14 rounded-full object-cover border-2 border-rose-500 group-hover:scale-105 transition shadow-md"
                  />
                  <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-slate-950" />
                </div>
                <span className="text-[11px] font-bold text-white max-w-[64px] truncate">
                  {m.otherUser.username.split(' ')[0]}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Vertical Conversations List */}
      <div className="flex flex-col gap-2">
        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
          Conversations
        </span>

        {matches.map((m) => (
          <button
            key={m.id}
            onClick={() => onSelectMatch(m)}
            className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 hover:bg-slate-900 transition flex items-center gap-3 cursor-pointer text-left shadow-sm"
          >
            <div className="relative">
              <img
                src={m.otherUser.photoUrl}
                alt={m.otherUser.username}
                className="w-12 h-12 rounded-full object-cover border border-slate-700"
              />
              <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-slate-950" />
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-white truncate">{m.otherUser.username}</span>
                <span className="text-[10px] text-slate-500">
                  {new Date(m.lastMessageTime || m.matchedAt).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate mt-0.5">
                {m.lastMessage || 'Start a conversation...'}
              </p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
