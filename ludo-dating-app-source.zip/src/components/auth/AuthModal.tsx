import React, { useState } from 'react';
import { User } from '../../types';
import { api } from '../../services/api';
import { sound } from '../../services/sound';
import { ShieldCheck, Heart, Sparkles, AlertCircle, ArrowRight, UserPlus, LogIn } from 'lucide-react';

interface AuthModalProps {
  onSuccess: (user: User) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ onSuccess }) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [age, setAge] = useState<number>(22);
  const [gender, setGender] = useState<'female' | 'male' | 'non-binary' | 'other'>('female');
  const [lookingFor, setLookingFor] = useState<'men' | 'women' | 'everyone'>('everyone');
  const [bio, setBio] = useState('Passionate about classic Ludo and meeting romantic matches! 🎲❤️');
  const [city, setCity] = useState('New York, NY');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Quick Demo Login Personas
  const demoUsers = [
    { id: 'user-maya', name: 'Maya Sharma', age: 24, role: 'Ludo Pro', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150' },
    { id: 'user-arjun', name: 'Arjun Mehta', age: 26, role: 'Software Eng', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150' },
    { id: 'user-zara', name: 'Zara Chen', age: 23, role: 'Architect', avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150' },
    { id: 'user-admin', name: 'Admin Ludo', age: 28, role: 'Moderator', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150' },
  ];

  const handleQuickSwitch = async (userId: string) => {
    setLoading(true);
    setError(null);
    try {
      sound.playNotification();
      const res = await api.quickSwitch(userId);
      onSuccess(res.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login error');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (mode === 'login') {
        const res = await api.login(email, password);
        sound.playNotification();
        onSuccess(res.user);
      } else {
        if (age < 18) {
          setError('Age verification: You must be at least 18 years old to join.');
          setLoading(false);
          return;
        }

        const res = await api.register({
          username,
          email,
          password,
          age,
          gender,
          lookingFor,
          bio,
          city,
          photoUrl:
            gender === 'female'
              ? 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500'
              : 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=500',
        });
        sound.playNotification();
        onSuccess(res.user);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-3">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full overflow-hidden shadow-2xl p-6 flex flex-col gap-4 animate-in zoom-in-95">
        {/* App Branding */}
        <div className="text-center">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-rose-500 to-amber-500 flex items-center justify-center mx-auto mb-2 shadow-lg shadow-rose-500/30">
            <Heart className="w-7 h-7 text-white fill-current animate-pulse" />
          </div>
          <h1 className="text-xl font-black text-white">Ludo Dating App ❤️</h1>
          <p className="text-xs text-rose-300/80 mt-0.5">
            Play Classic Ludo · Match & Chat · Live Voice
          </p>
        </div>

        {/* 18+ Verified Notice */}
        <div className="flex items-center gap-2 p-2.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-[11px] text-emerald-300 font-semibold">
          <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>Strict 18+ Adults Only Community. Fair play & safe dating verified.</span>
        </div>

        {/* 1-Click Demo Login Personas */}
        <div className="flex flex-col gap-1.5">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Quick 1-Click Login (Instant Testing)
          </span>
          <div className="grid grid-cols-2 gap-2">
            {demoUsers.map((du) => (
              <button
                key={du.id}
                onClick={() => handleQuickSwitch(du.id)}
                disabled={loading}
                className="p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-rose-500/50 hover:bg-slate-800/80 flex items-center gap-2 cursor-pointer transition text-left active:scale-95"
              >
                <img src={du.avatar} alt={du.name} className="w-7 h-7 rounded-full object-cover" />
                <div className="truncate">
                  <div className="text-xs font-bold text-white truncate">{du.name.split(' ')[0]}</div>
                  <div className="text-[10px] text-slate-400">{du.role}</div>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 text-slate-600 text-xs my-0.5">
          <div className="flex-1 h-px bg-slate-800" />
          <span>or your credentials</span>
          <div className="flex-1 h-px bg-slate-800" />
        </div>

        {/* Form Error Banner */}
        {error && (
          <div className="p-2.5 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Login / Register Toggle */}
        <div className="flex rounded-xl bg-slate-950 p-1 border border-slate-800 text-xs font-bold">
          <button
            type="button"
            onClick={() => setMode('login')}
            className={`flex-1 py-1.5 rounded-lg transition cursor-pointer ${
              mode === 'login' ? 'bg-rose-600 text-white shadow' : 'text-slate-400'
            }`}
          >
            Login
          </button>
          <button
            type="button"
            onClick={() => setMode('register')}
            className={`flex-1 py-1.5 rounded-lg transition cursor-pointer ${
              mode === 'register' ? 'bg-rose-600 text-white shadow' : 'text-slate-400'
            }`}
          >
            Sign Up (18+)
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="flex flex-col gap-2.5 text-xs">
          {mode === 'register' && (
            <>
              <div>
                <label className="text-[10px] text-slate-400">Username:</label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. Alex Rivera"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs mt-0.5 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-slate-400">Age (18+ only):</label>
                  <input
                    type="number"
                    min={18}
                    max={99}
                    required
                    value={age}
                    onChange={(e) => setAge(parseInt(e.target.value, 10))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs mt-0.5 focus:outline-none focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400">City:</label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs mt-0.5 focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>
            </>
          )}

          <div>
            <label className="text-[10px] text-slate-400">Email:</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs mt-0.5 focus:outline-none focus:border-rose-500"
            />
          </div>

          <div>
            <label className="text-[10px] text-slate-400">Password:</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs mt-0.5 focus:outline-none focus:border-rose-500"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="mt-2 py-3 bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white font-bold rounded-2xl shadow-lg shadow-rose-600/30 cursor-pointer transition active:scale-95 flex items-center justify-center gap-1.5"
          >
            {mode === 'login' ? <LogIn className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
            <span>{loading ? 'Please wait...' : mode === 'login' ? 'Login' : 'Complete 18+ Sign Up'}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
