import React, { useState } from 'react';
import { User } from '../../types';
import { api } from '../../services/api';
import { X, ShieldAlert, Ban, AlertTriangle, Check } from 'lucide-react';

interface ReportModalProps {
  targetUser: { id: string; username: string };
  onClose: () => void;
  onUserBlocked?: () => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  targetUser,
  onClose,
  onUserBlocked,
}) => {
  const [reason, setReason] = useState<string>('Inappropriate behavior');
  const [details, setDetails] = useState<string>('');
  const [alsoBlock, setAlsoBlock] = useState<boolean>(true);
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await api.reportUser(targetUser.id, reason, details);
      if (alsoBlock) {
        await api.blockUser(targetUser.id);
        onUserBlocked?.();
      }
      setSubmitted(true);
      setTimeout(() => {
        onClose();
      }, 1800);
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Error submitting report');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-5 shadow-2xl animate-in zoom-in-95">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
            <ShieldAlert className="w-5 h-5" />
            <span>Safety: Report User</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-xl text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="py-8 text-center flex flex-col items-center gap-2">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Check className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-white">Report Submitted</h4>
            <p className="text-xs text-slate-400">
              Thank you for keeping our community safe. {alsoBlock && `${targetUser.username} is now blocked.`}
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col gap-3.5 mt-3">
            <p className="text-xs text-slate-300">
              Report <strong className="text-white">{targetUser.username}</strong> for violation of community standards.
            </p>

            <div className="flex flex-col gap-1">
              <label className="text-[11px] font-semibold text-slate-400">Reason:</label>
              <select
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-rose-500"
              >
                <option value="Inappropriate behavior">Inappropriate banter or language</option>
                <option value="Suspected under 18 years old">Suspected under 18 years old (Age Violation)</option>
                <option value="Harassment or bullying">Harassment or bullying</option>
                <option value="Spam or fraudulent link">Spam or external link solicitation</option>
                <option value="Other violation">Other community safety violation</option>
              </select>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-[11px] font-semibold text-slate-400">Details (optional):</label>
              <textarea
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder="Describe what occurred during the match or chat..."
                rows={3}
                className="bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-rose-500"
              />
            </div>

            <label className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={alsoBlock}
                onChange={(e) => setAlsoBlock(e.target.checked)}
                className="w-4 h-4 rounded text-rose-600 focus:ring-0 bg-slate-900 border-slate-700"
              />
              <span className="flex items-center gap-1.5 font-semibold text-rose-300">
                <Ban className="w-3.5 h-3.5" />
                <span>Also block this user immediately</span>
              </span>
            </label>

            <div className="flex gap-2 mt-1">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs transition cursor-pointer shadow-lg shadow-rose-600/30 flex items-center justify-center gap-1"
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>{loading ? 'Submitting...' : 'Submit Report'}</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
