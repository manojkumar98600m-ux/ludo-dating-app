import { GameState, LudoPlayer, PlayerColor, Token } from '../types';

export const TRACK_CELLS: { x: number; y: number }[] = [
  // 0..4 (Red arm going right)
  { x: 1, y: 6 }, // 0: Red Start (Safe ★)
  { x: 2, y: 6 }, // 1
  { x: 3, y: 6 }, // 2
  { x: 4, y: 6 }, // 3
  { x: 5, y: 6 }, // 4
  // 5..10 (Green arm going up)
  { x: 6, y: 5 }, // 5
  { x: 6, y: 4 }, // 6
  { x: 6, y: 3 }, // 7
  { x: 6, y: 2 }, // 8: Safe ★
  { x: 6, y: 1 }, // 9
  { x: 6, y: 0 }, // 10
  // 11..12 (Top crossing)
  { x: 7, y: 0 }, // 11
  { x: 8, y: 0 }, // 12
  // 13..17 (Green arm going down)
  { x: 8, y: 1 }, // 13: Green Start (Safe ★)
  { x: 8, y: 2 }, // 14
  { x: 8, y: 3 }, // 15
  { x: 8, y: 4 }, // 16
  { x: 8, y: 5 }, // 17
  // 18..23 (Yellow arm going right)
  { x: 9, y: 6 }, // 18
  { x: 10, y: 6 }, // 19
  { x: 11, y: 6 }, // 20
  { x: 12, y: 6 }, // 21: Safe ★
  { x: 13, y: 6 }, // 22
  { x: 14, y: 6 }, // 23
  // 24..25 (Right crossing)
  { x: 14, y: 7 }, // 24
  { x: 14, y: 8 }, // 25
  // 26..30 (Yellow arm going left)
  { x: 13, y: 8 }, // 26: Yellow Start (Safe ★)
  { x: 12, y: 8 }, // 27
  { x: 11, y: 8 }, // 28
  { x: 10, y: 8 }, // 29
  { x: 9, y: 8 }, // 30
  // 31..36 (Blue arm going down)
  { x: 8, y: 9 }, // 31
  { x: 8, y: 10 }, // 32
  { x: 8, y: 11 }, // 33
  { x: 8, y: 12 }, // 34: Safe ★
  { x: 8, y: 13 }, // 35
  { x: 8, y: 14 }, // 36
  // 37..38 (Bottom crossing)
  { x: 7, y: 14 }, // 37
  { x: 6, y: 14 }, // 38
  // 39..43 (Blue arm going up)
  { x: 6, y: 13 }, // 39: Blue Start (Safe ★)
  { x: 6, y: 12 }, // 40
  { x: 6, y: 11 }, // 41
  { x: 6, y: 10 }, // 42
  { x: 6, y: 9 }, // 43
  // 44..49 (Red arm going left)
  { x: 5, y: 8 }, // 44
  { x: 4, y: 8 }, // 45
  { x: 3, y: 8 }, // 46
  { x: 2, y: 8 }, // 47: Safe ★
  { x: 1, y: 8 }, // 48
  { x: 0, y: 8 }, // 49
  // 50..51 (Left crossing)
  { x: 0, y: 7 }, // 50
  { x: 0, y: 6 }, // 51
];

export const SAFE_CELLS = [0, 8, 13, 21, 26, 34, 39, 47];

export const COLOR_CONFIG: Record<
  PlayerColor,
  {
    name: string;
    startCell: number;
    homeCol: { x: number; y: number }[];
    finishPoint: { x: number; y: number };
    yardSpots: { x: number; y: number }[];
    themeHex: string;
    lightHex: string;
    borderHex: string;
  }
> = {
  red: {
    name: 'Red',
    startCell: 0,
    homeCol: [
      { x: 1, y: 7 },
      { x: 2, y: 7 },
      { x: 3, y: 7 },
      { x: 4, y: 7 },
      { x: 5, y: 7 },
    ],
    finishPoint: { x: 6.5, y: 7 },
    yardSpots: [
      { x: 1.8, y: 1.8 },
      { x: 3.8, y: 1.8 },
      { x: 1.8, y: 3.8 },
      { x: 3.8, y: 3.8 },
    ],
    themeHex: '#ef4444',
    lightHex: '#fee2e2',
    borderHex: '#dc2626',
  },
  green: {
    name: 'Green',
    startCell: 13,
    homeCol: [
      { x: 7, y: 1 },
      { x: 7, y: 2 },
      { x: 7, y: 3 },
      { x: 7, y: 4 },
      { x: 7, y: 5 },
    ],
    finishPoint: { x: 7, y: 6.5 },
    yardSpots: [
      { x: 10.8, y: 1.8 },
      { x: 12.8, y: 1.8 },
      { x: 10.8, y: 3.8 },
      { x: 12.8, y: 3.8 },
    ],
    themeHex: '#10b981',
    lightHex: '#d1fae5',
    borderHex: '#059669',
  },
  yellow: {
    name: 'Yellow',
    startCell: 26,
    homeCol: [
      { x: 13, y: 7 },
      { x: 12, y: 7 },
      { x: 11, y: 7 },
      { x: 10, y: 7 },
      { x: 9, y: 7 },
    ],
    finishPoint: { x: 7.5, y: 7 },
    yardSpots: [
      { x: 10.8, y: 10.8 },
      { x: 12.8, y: 10.8 },
      { x: 10.8, y: 12.8 },
      { x: 12.8, y: 12.8 },
    ],
    themeHex: '#f59e0b',
    lightHex: '#fef3c7',
    borderHex: '#d97706',
  },
  blue: {
    name: 'Blue',
    startCell: 39,
    homeCol: [
      { x: 7, y: 13 },
      { x: 7, y: 12 },
      { x: 7, y: 11 },
      { x: 7, y: 10 },
      { x: 7, y: 9 },
    ],
    finishPoint: { x: 7, y: 7.5 },
    yardSpots: [
      { x: 1.8, y: 10.8 },
      { x: 3.8, y: 10.8 },
      { x: 1.8, y: 12.8 },
      { x: 3.8, y: 12.8 },
    ],
    themeHex: '#3b82f6',
    lightHex: '#dbeafe',
    borderHex: '#2563eb',
  },
};

/**
 * Calculates (x,y) on the 15x15 board for a token given its step and color.
 */
export function getTokenCoordinates(
  color: PlayerColor,
  step: number,
  tokenId: number
): { x: number; y: number } {
  const cfg = COLOR_CONFIG[color];
  if (step === -1) {
    return cfg.yardSpots[tokenId] || { x: 1, y: 1 };
  }
  if (step === 56) {
    return cfg.finishPoint;
  }
  if (step >= 51 && step <= 55) {
    const idx = step - 51;
    return cfg.homeCol[idx] || cfg.finishPoint;
  }
  // outer circuit
  const globalCell = (cfg.startCell + step) % 52;
  return TRACK_CELLS[globalCell] || { x: 7, y: 7 };
}

/**
 * Checks which tokens are valid to move given a dice value
 */
export function getValidTokenMoves(player: LudoPlayer, diceValue: number): number[] {
  if (!diceValue || diceValue < 1 || diceValue > 6) return [];
  const valid: number[] = [];

  player.tokens.forEach((t, index) => {
    if (t.finished) return;
    if (t.step === -1) {
      if (diceValue === 6) {
        valid.push(index);
      }
    } else {
      if (t.step + diceValue <= 56) {
        valid.push(index);
      }
    }
  });

  return valid;
}

/**
 * Creates initial tokens for a player
 */
export function createTokens(color: PlayerColor): Token[] {
  return [0, 1, 2, 3].map((id) => ({
    id,
    color,
    step: -1,
    finished: false,
  }));
}

/**
 * Creates initial local game state
 */
export function createInitialGameState(
  playerCount: 2 | 3 | 4 = 2,
  userPlayerName: string = 'You',
  userAvatar: string = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop'
): GameState {
  const colors: PlayerColor[] =
    playerCount === 2
      ? ['red', 'yellow']
      : playerCount === 3
      ? ['red', 'green', 'yellow']
      : ['red', 'green', 'yellow', 'blue'];

  const players: LudoPlayer[] = colors.map((col, idx) => {
    const isUser = idx === 0;
    const botNames = ['Cupid Bot', 'Rose Bot', 'Sweetheart Bot'];
    const botAvatars = [
      'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop',
    ];

    return {
      id: isUser ? 'local-user' : `bot-${idx}`,
      name: isUser ? userPlayerName : botNames[idx - 1] || `Player ${idx + 1}`,
      avatar: isUser ? userAvatar : botAvatars[idx - 1] || userAvatar,
      color: col,
      isBot: !isUser,
      isHost: isUser,
      tokens: createTokens(col),
      hasRolled: false,
      hasFinished: false,
    };
  });

  return {
    mode: 'local',
    playerCount,
    players,
    currentTurnIndex: 0,
    diceValue: null,
    hasRolled: false,
    validTokenMoves: [],
    status: 'playing',
    turnTimeLeft: 30,
    turnDuration: 30,
    lastActionLog: 'New match started! ' + players[0].name + ' rolls first.',
    consecutiveSixes: 0,
    moveHistory: [
      {
        player: players[0].name,
        action: 'Game started',
        timestamp: Date.now(),
      },
    ],
  };
}

export interface MoveResult {
  captured: boolean;
  capturedPlayerName?: string;
  finished: boolean;
  earnedBonusTurn: boolean;
  gameOver: boolean;
  winner?: LudoPlayer;
}

/**
 * Pure function to execute a token move on state
 */
export function executeMove(
  state: GameState,
  tokenIndex: number
): { newState: GameState; result: MoveResult } {
  const currentP = state.players[state.currentTurnIndex];
  const dice = state.diceValue || 0;
  const token = currentP.tokens[tokenIndex];

  let captured = false;
  let capturedPlayerName: string | undefined;
  let earnedBonusTurn = false;
  let finished = false;

  // Clone players array deeply
  const newPlayers = state.players.map((p, pIdx) => {
    if (pIdx !== state.currentTurnIndex) return { ...p, tokens: p.tokens.map((t) => ({ ...t })) };
    return {
      ...p,
      tokens: p.tokens.map((t, tIdx) => {
        if (tIdx !== tokenIndex) return { ...t };
        // Moving this token
        if (t.step === -1) {
          return { ...t, step: 0 };
        }
        const nextStep = t.step + dice;
        if (nextStep >= 56) {
          return { ...t, step: 56, finished: true };
        }
        return { ...t, step: nextStep };
      }),
    };
  });

  const movedToken = newPlayers[state.currentTurnIndex].tokens[tokenIndex];

  if (movedToken.step === 56 && !token.finished) {
    finished = true;
    earnedBonusTurn = true;
  }

  // Check captures if on outer track
  if (movedToken.step >= 0 && movedToken.step <= 50) {
    const curStart = COLOR_CONFIG[currentP.color].startCell;
    const globalPos = (curStart + movedToken.step) % 52;

    if (!SAFE_CELLS.includes(globalPos)) {
      newPlayers.forEach((otherP, otherIdx) => {
        if (otherIdx === state.currentTurnIndex) return;
        const oStart = COLOR_CONFIG[otherP.color].startCell;
        otherP.tokens.forEach((ot) => {
          if (ot.step >= 0 && ot.step <= 50 && !ot.finished) {
            const oGlobal = (oStart + ot.step) % 52;
            if (oGlobal === globalPos) {
              // Captured!
              ot.step = -1;
              captured = true;
              capturedPlayerName = otherP.name;
              earnedBonusTurn = true;
            }
          }
        });
      });
    }
  }

  // Bonus turn on dice 6
  if (dice === 6 && state.consecutiveSixes < 3) {
    earnedBonusTurn = true;
  }

  // Check if player won
  const allFinished = newPlayers[state.currentTurnIndex].tokens.every((t) => t.finished);
  let gameOver = false;
  let winner: LudoPlayer | undefined;

  if (allFinished) {
    gameOver = true;
    winner = newPlayers[state.currentTurnIndex];
    newPlayers[state.currentTurnIndex].hasFinished = true;
  }

  let nextTurnIndex = state.currentTurnIndex;
  let consecutiveSixes = state.consecutiveSixes;

  if (gameOver) {
    // Game ended
  } else if (earnedBonusTurn) {
    if (dice === 6) {
      consecutiveSixes += 1;
      if (consecutiveSixes >= 3) {
        // Penalty for 3 consecutive sixes -> forfeit bonus turn!
        nextTurnIndex = (state.currentTurnIndex + 1) % state.players.length;
        consecutiveSixes = 0;
      }
    }
  } else {
    nextTurnIndex = (state.currentTurnIndex + 1) % state.players.length;
    consecutiveSixes = 0;
  }

  const logMessage = captured
    ? `${currentP.name} captured ${capturedPlayerName}'s token! 💥 Earns another turn!`
    : finished
    ? `${currentP.name} reached Home! 🏆`
    : dice === 6
    ? `${currentP.name} rolled a 6 and rolls again!`
    : `${currentP.name} moved token ${tokenIndex + 1}.`;

  const newState: GameState = {
    ...state,
    players: newPlayers,
    currentTurnIndex: nextTurnIndex,
    diceValue: null,
    hasRolled: false,
    validTokenMoves: [],
    status: gameOver ? 'ended' : 'playing',
    winner,
    turnTimeLeft: state.turnDuration,
    consecutiveSixes,
    lastActionLog: logMessage,
    moveHistory: [
      {
        player: currentP.name,
        action: logMessage,
        timestamp: Date.now(),
      },
      ...state.moveHistory.slice(0, 20),
    ],
  };

  return {
    newState,
    result: {
      captured,
      capturedPlayerName,
      finished,
      earnedBonusTurn,
      gameOver,
      winner,
    },
  };
}

/**
 * Intelligent AI Move Chooser
 */
export function chooseBestBotMove(state: GameState, validMoves: number[]): number {
  if (validMoves.length === 1) return validMoves[0];
  const bot = state.players[state.currentTurnIndex];
  const dice = state.diceValue || 0;
  const botStart = COLOR_CONFIG[bot.color].startCell;

  // 1. Move that captures an opponent
  for (const idx of validMoves) {
    const t = bot.tokens[idx];
    const targetStep = t.step === -1 ? 0 : t.step + dice;
    if (targetStep >= 0 && targetStep <= 50) {
      const globalPos = (botStart + targetStep) % 52;
      if (!SAFE_CELLS.includes(globalPos)) {
        for (let pIdx = 0; pIdx < state.players.length; pIdx++) {
          if (pIdx === state.currentTurnIndex) continue;
          const other = state.players[pIdx];
          const oStart = COLOR_CONFIG[other.color].startCell;
          const hasVictim = other.tokens.some(
            (ot) =>
              ot.step >= 0 &&
              ot.step <= 50 &&
              !ot.finished &&
              (oStart + ot.step) % 52 === globalPos
          );
          if (hasVictim) return idx;
        }
      }
    }
  }

  // 2. Move token into home victory (step 56)
  for (const idx of validMoves) {
    const t = bot.tokens[idx];
    if (t.step + dice === 56) return idx;
  }

  // 3. Move token from home yard out into board
  if (dice === 6) {
    const yardIdx = validMoves.find((i) => bot.tokens[i].step === -1);
    if (yardIdx !== undefined) return yardIdx;
  }

  // 4. Move token into safe colored home lane (>= 51)
  for (const idx of validMoves) {
    const t = bot.tokens[idx];
    if (t.step < 51 && t.step + dice >= 51) return idx;
  }

  // 5. Move furthest advanced token
  let bestIdx = validMoves[0];
  let maxStep = bot.tokens[bestIdx].step;
  for (const idx of validMoves) {
    if (bot.tokens[idx].step > maxStep) {
      maxStep = bot.tokens[idx].step;
      bestIdx = idx;
    }
  }
  return bestIdx;
}
