import {
  User,
  DatingProfile,
  Match,
  ChatMessage,
  ReportItem,
  SubscriptionRecord,
  CallRecord,
  PrivacySettings,
} from '../types';

const TOKEN_KEY = 'ludo_dating_token';
const USER_KEY = 'ludo_dating_user';

export const api = {
  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  },

  setSession(token: string, user: User) {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  },

  clearSession() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  },

  getCachedUser(): User | null {
    try {
      const data = localStorage.getItem(USER_KEY);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  },

  async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const token = this.getToken();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string>),
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const res = await fetch(endpoint, {
      ...options,
      headers,
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Request failed');
    }
    return data as T;
  },

  // Auth
  async register(params: Partial<User> & { password: string }): Promise<{ token: string; user: User }> {
    const res = await this.request<{ token: string; user: User }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(params),
    });
    this.setSession(res.token, res.user);
    return res;
  },

  async login(email: string, password: string): Promise<{ token: string; user: User }> {
    const res = await this.request<{ token: string; user: User }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    this.setSession(res.token, res.user);
    return res;
  },

  async quickSwitch(userId: string): Promise<{ token: string; user: User }> {
    const res = await this.request<{ token: string; user: User }>('/api/auth/quick-switch', {
      method: 'POST',
      body: JSON.stringify({ userId }),
    });
    this.setSession(res.token, res.user);
    return res;
  },

  async getMe(): Promise<{ user: User }> {
    const res = await this.request<{ user: User }>('/api/auth/me');
    localStorage.setItem(USER_KEY, JSON.stringify(res.user));
    return res;
  },

  async getSeedUsers(): Promise<{ users: User[] }> {
    return this.request<{ users: User[] }>('/api/auth/seed-users');
  },

  async updateProfile(updates: Partial<User>): Promise<{ user: User }> {
    const res = await this.request<{ user: User }>('/api/profile/update', {
      method: 'POST',
      body: JSON.stringify(updates),
    });
    localStorage.setItem(USER_KEY, JSON.stringify(res.user));
    return res;
  },

  async updatePrivacy(privacy: Partial<PrivacySettings>): Promise<{ user: User }> {
    return this.updateProfile({ privacy: privacy as PrivacySettings });
  },

  // Dating
  async getDiscoverProfiles(): Promise<{ profiles: DatingProfile[] }> {
    return this.request<{ profiles: DatingProfile[] }>('/api/users/discover');
  },

  async swipe(targetUserId: string, action: 'like' | 'pass'): Promise<{ success: boolean; isMatch: boolean; match?: Match }> {
    return this.request<{ success: boolean; isMatch: boolean; match?: Match }>('/api/dating/swipe', {
      method: 'POST',
      body: JSON.stringify({ targetUserId, action }),
    });
  },

  async getMatches(): Promise<{ matches: Match[] }> {
    return this.request<{ matches: Match[] }>('/api/dating/matches');
  },

  // Online Friends
  async getFriends(): Promise<{
    friends: (User & { isFriend: boolean })[];
    pendingIncoming: { id: string; fromUser: User; createdAt: string }[];
    pendingOutgoing: { id: string; toUser: User; createdAt: string }[];
  }> {
    return this.request('/api/friends/list');
  },

  async sendFriendRequest(targetUserId: string): Promise<{ success: boolean; message: string }> {
    return this.request('/api/friends/request', {
      method: 'POST',
      body: JSON.stringify({ targetUserId }),
    });
  },

  async respondFriendRequest(targetUserId: string, action: 'accept' | 'reject'): Promise<{ success: boolean; message: string }> {
    return this.request('/api/friends/respond', {
      method: 'POST',
      body: JSON.stringify({ targetUserId, action }),
    });
  },

  async cancelFriendRequest(targetUserId: string): Promise<{ success: boolean; message: string }> {
    return this.request('/api/friends/cancel', {
      method: 'POST',
      body: JSON.stringify({ targetUserId }),
    });
  },

  async removeFriend(targetUserId: string): Promise<{ success: boolean; message: string }> {
    return this.request('/api/friends/remove', {
      method: 'POST',
      body: JSON.stringify({ targetUserId }),
    });
  },

  // Private Multimedia Messaging
  async getMessages(otherUserId: string): Promise<{ messages: ChatMessage[] }> {
    return this.request<{ messages: ChatMessage[] }>(`/api/chat/messages/${otherUserId}`);
  },

  async sendMessage(params: {
    recipientId: string;
    text?: string;
    photoUrl?: string;
    audioUrl?: string;
    giftType?: string;
    gameInviteRoomId?: string;
  }): Promise<{ message: ChatMessage; remainingCoins?: number }> {
    return this.request<{ message: ChatMessage; remainingCoins?: number }>('/api/chat/send', {
      method: 'POST',
      body: JSON.stringify(params),
    });
  },

  async deleteMessage(messageId: string): Promise<{ success: boolean; message: string }> {
    return this.request(`/api/chat/messages/${messageId}`, {
      method: 'DELETE',
    });
  },

  // Call History
  async getCallHistory(): Promise<{ history: CallRecord[] }> {
    return this.request<{ history: CallRecord[] }>('/api/calls/history');
  },

  // Safety
  async reportUser(targetUserId: string, reason: string, details: string): Promise<{ success: boolean; message: string }> {
    return this.request<{ success: boolean; message: string }>('/api/safety/report', {
      method: 'POST',
      body: JSON.stringify({ targetUserId, reason, details }),
    });
  },

  async blockUser(targetUserId: string): Promise<{ success: boolean; message: string }> {
    return this.request<{ success: boolean; message: string }>('/api/safety/block', {
      method: 'POST',
      body: JSON.stringify({ targetUserId }),
    });
  },

  // VIP Membership (₹199 crossed out, ₹50 launch offer, no auto-renewal)
  async getVipPlan(): Promise<{
    plan: {
      id: string;
      name: string;
      originalPriceInr: number;
      discountPercent: number;
      finalPriceInr: number;
      duration: string;
      billingNote: string;
      promotionTag: string;
      coinsGranted: number;
      features: string[];
    };
  }> {
    return this.request('/api/subscriptions/plans');
  },

  async subscribe(): Promise<{ success: boolean; user: User; message: string }> {
    return this.request<{ success: boolean; user: User; message: string }>('/api/subscriptions/subscribe', {
      method: 'POST',
      body: JSON.stringify({ planTier: 'gold' }),
    });
  },

  // Admin Dashboard
  async getAdminStats(): Promise<{
    totalUsers: number;
    activeReports: number;
    totalRevenue: number;
    subscriptionsCount: number;
    usersList: User[];
  }> {
    return this.request('/api/admin/stats');
  },

  async getAdminReports(): Promise<{ reports: ReportItem[] }> {
    return this.request<{ reports: ReportItem[] }>('/api/admin/reports');
  },

  async resolveReport(reportId: string, action: 'ban' | 'dismiss'): Promise<{ success: boolean; report: ReportItem }> {
    return this.request('/api/admin/reports/resolve', {
      method: 'POST',
      body: JSON.stringify({ reportId, action }),
    });
  },

  async getAdminSubscriptions(): Promise<{ subscriptions: SubscriptionRecord[] }> {
    return this.request<{ subscriptions: SubscriptionRecord[] }>('/api/admin/subscriptions');
  },
};
