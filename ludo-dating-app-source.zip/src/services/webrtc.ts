export interface VoicePeer {
  userId: string;
  userName: string;
  isMuted: boolean;
  isSpeaking: boolean;
}

class WebRTCVoiceService {
  private localStream: MediaStream | null = null;
  private peerConnections: Map<string, RTCPeerConnection> = new Map();
  private sendSignalCallback: ((to: string, signal: unknown) => void) | null = null;
  private onPeersChangeCallback: ((peers: VoicePeer[]) => void) | null = null;
  private isMuted: boolean = false;
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private animationFrameId: number | null = null;
  private isSpeaking: boolean = false;

  private rtcConfig: RTCConfiguration = {
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
    ],
  };

  public setCallbacks(
    sendSignal: (to: string, signal: unknown) => void,
    onPeersChange: (peers: VoicePeer[]) => void
  ) {
    this.sendSignalCallback = sendSignal;
    this.onPeersChangeCallback = onPeersChange;
  }

  public async enableMicrophone(): Promise<boolean> {
    try {
      if (!this.localStream) {
        this.localStream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
          video: false,
        });

        this.setupAudioAnalysis();
      }
      return true;
    } catch (err) {
      console.warn('Microphone permission not granted or device unavailable:', err);
      return false;
    }
  }

  public disableMicrophone() {
    if (this.localStream) {
      this.localStream.getTracks().forEach((track) => track.stop());
      this.localStream = null;
    }
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
    if (this.audioContext) {
      this.audioContext.close().catch(() => {});
      this.audioContext = null;
    }
    this.peerConnections.forEach((pc) => pc.close());
    this.peerConnections.clear();
  }

  public toggleMute(): boolean {
    if (!this.localStream) return true;
    this.isMuted = !this.isMuted;
    this.localStream.getAudioTracks().forEach((track) => {
      track.enabled = !this.isMuted;
    });
    return this.isMuted;
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  public getIsSpeaking(): boolean {
    return this.isSpeaking;
  }

  public hasMicrophone(): boolean {
    return Boolean(this.localStream);
  }

  private setupAudioAnalysis() {
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx || !this.localStream) return;

      this.audioContext = new AudioCtx();
      const source = this.audioContext.createMediaStreamSource(this.localStream);
      this.analyser = this.audioContext.createAnalyser();
      this.analyser.fftSize = 256;
      source.connect(this.analyser);

      const bufferLength = this.analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      const checkVolume = () => {
        if (!this.analyser) return;
        this.analyser.getByteFrequencyData(dataArray);

        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
          sum += dataArray[i];
        }
        const avg = sum / bufferLength;

        const speakingNow = !this.isMuted && avg > 18;
        if (speakingNow !== this.isSpeaking) {
          this.isSpeaking = speakingNow;
        }

        this.animationFrameId = requestAnimationFrame(checkVolume);
      };

      checkVolume();
    } catch {
      // Audio analysis fallback
    }
  }

  public async createOfferForPeer(peerId: string) {
    if (!this.localStream) return;

    const pc = new RTCPeerConnection(this.rtcConfig);
    this.peerConnections.set(peerId, pc);

    this.localStream.getTracks().forEach((track) => {
      if (this.localStream) {
        pc.addTrack(track, this.localStream);
      }
    });

    pc.onicecandidate = (event) => {
      if (event.candidate && this.sendSignalCallback) {
        this.sendSignalCallback(peerId, { candidate: event.candidate });
      }
    };

    pc.ontrack = (event) => {
      const remoteAudio = new Audio();
      remoteAudio.srcObject = event.streams[0];
      remoteAudio.autoplay = true;
    };

    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);

    if (this.sendSignalCallback) {
      this.sendSignalCallback(peerId, { description: pc.localDescription });
    }
  }

  public async handleIncomingSignal(fromUserId: string, signal: { description?: RTCSessionDescriptionInit; candidate?: RTCIceCandidateInit }) {
    let pc = this.peerConnections.get(fromUserId);

    if (signal.description) {
      if (!pc) {
        pc = new RTCPeerConnection(this.rtcConfig);
        this.peerConnections.set(fromUserId, pc);

        if (this.localStream) {
          this.localStream.getTracks().forEach((track) => {
            if (this.localStream) {
              pc!.addTrack(track, this.localStream);
            }
          });
        }

        pc.onicecandidate = (event) => {
          if (event.candidate && this.sendSignalCallback) {
            this.sendSignalCallback(fromUserId, { candidate: event.candidate });
          }
        };

        pc.ontrack = (event) => {
          const remoteAudio = new Audio();
          remoteAudio.srcObject = event.streams[0];
          remoteAudio.autoplay = true;
        };
      }

      await pc.setRemoteDescription(new RTCSessionDescription(signal.description));

      if (signal.description.type === 'offer') {
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        if (this.sendSignalCallback) {
          this.sendSignalCallback(fromUserId, { description: pc.localDescription });
        }
      }
    } else if (signal.candidate && pc) {
      try {
        await pc.addIceCandidate(new RTCIceCandidate(signal.candidate));
      } catch (e) {
        console.warn('Error adding ice candidate:', e);
      }
    }
  }
}

export const webrtcVoice = new WebRTCVoiceService();
