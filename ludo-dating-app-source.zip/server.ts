import express, { Request, Response, NextFunction } from 'express';
import { createServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import AdmZip from 'adm-zip';
import {
  GameState,
  LudoPlayer,
  PlayerColor,
  User,
  DatingProfile,
  Match,
  ChatMessage,
  FriendRelationship,
  CallRecord,
  ReportItem,
  SubscriptionRecord,
  PrivacySettings,
} from './src/types/index.ts';
import {
  createTokens,
  executeMove,
  getValidTokenMoves,
  chooseBestBotMove,
} from './src/services/ludoEngine.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const httpServer = createServer(app);
const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

app.use(express.json({ limit: '20mb' })); // Support base64 photos and voice audio

// In-Memory Database
const users: Map<string, User & { passwordHash: string }> = new Map();
const tokensToUserId: Map<string, string> = new Map();
const swipes: Map<string, { [targetId: string]: 'like' | 'pass' }> = new Map();
const matches: Map<string, Match> = new Map();
const chatMessages: ChatMessage[] = [];
const friendships: Map<string, { status: 'pending' | 'accepted' | 'declined'; createdAt: string }> = new Map(); // "userA:userB"
const callHistory: CallRecord[] = [];
const blockedUsers: Map<string, Set<string>> = new Map(); // userId -> Set(blockedUserIds)
const reports: ReportItem[] = [];
const subscriptions: SubscriptionRecord[] = [];

// Helper for hashing
function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex');
}

const DEFAULT_PRIVACY: PrivacySettings = {
  showOnlineStatus: true,
  showLastSeen: true,
  allowCallsFrom: 'friends_and_matches',
  allowMessagesFrom: 'everyone',
  profileVisibility: 'public',
};

// Seed Users with Photos, 18+ verification, and bios
const SEED_USERS = [
  {
    id: 'user-admin',
    username: 'Admin Ludo',
    email: 'admin@ludo.love',
    password: 'admin123password',
    age: 28,
    gender: 'non-binary' as const,
    lookingFor: 'everyone' as const,
    bio: 'Platform Moderator & Ludo Grandmaster. Ensuring safety, fair play, and authentic dating.',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop',
    interests: ['Ludo Champion', 'Board Games', 'Matchmaking', 'Community Safety'],
    city: 'Mumbai, India',
    coins: 50000,
    vipTier: 'gold' as const,
    isAdmin: true,
    privacy: { ...DEFAULT_PRIVACY, allowCallsFrom: 'everyone' as const },
  },
  {
    id: 'user-maya',
    username: 'Maya Sharma',
    email: 'maya@example.com',
    password: 'password123',
    age: 24,
    gender: 'female' as const,
    lookingFor: 'men' as const,
    bio: 'Competitive Ludo player who never shows mercy with a 6. Coffee addict, UI designer & sunset lover. Challenge me to a 1-on-1 match! 🎲✨',
    photoUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=500&auto=format&fit=crop',
    interests: ['Ludo Pro', 'Coffee', 'Design', 'Indie Rock', 'Late Night Drives'],
    city: 'Bengaluru, India',
    coins: 4800,
    vipTier: 'gold' as const,
    privacy: DEFAULT_PRIVACY,
  },
  {
    id: 'user-arjun',
    username: 'Arjun Mehta',
    email: 'arjun@example.com',
    password: 'password123',
    age: 26,
    gender: 'male' as const,
    lookingFor: 'women' as const,
    bio: 'Software engineer by day, Ludo strategist by night. Looking for someone who laughs when I send their token home! 🚀',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&auto=format&fit=crop',
    interests: ['Board Games', 'Tech', 'Hiking', 'Cooking', 'Dogs'],
    city: 'Delhi NCR, India',
    coins: 3500,
    vipTier: 'gold' as const,
    privacy: DEFAULT_PRIVACY,
  },
  {
    id: 'user-zara',
    username: 'Zara Chen',
    email: 'zara@example.com',
    password: 'password123',
    age: 23,
    gender: 'female' as const,
    lookingFor: 'everyone' as const,
    bio: 'Architect student obsessed with bright colors and rolling double sixes. Seeking someone for late night ludo dates & boba. 🧋',
    photoUrl: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=500&auto=format&fit=crop',
    interests: ['Architecture', 'Boba', 'Guitar', 'Ludo Tournaments', 'Photography'],
    city: 'Pune, India',
    coins: 2900,
    vipTier: 'none' as const,
    privacy: DEFAULT_PRIVACY,
  },
  {
    id: 'user-kabir',
    username: 'Kabir Roy',
    email: 'kabir@example.com',
    password: 'password123',
    age: 27,
    gender: 'male' as const,
    lookingFor: 'women' as const,
    bio: 'Musician & film enthusiast. True romantic compatibility is tested when you capture each other\'s tokens on cell 47! 🎸',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=500&auto=format&fit=crop',
    interests: ['Live Music', 'Cinema', 'Vinyl', 'Ludo Master', 'Travel'],
    city: 'Kolkata, India',
    coins: 1950,
    vipTier: 'none' as const,
    privacy: DEFAULT_PRIVACY,
  },
  {
    id: 'user-elena',
    username: 'Elena Rostova',
    email: 'elena@example.com',
    password: 'password123',
    age: 25,
    gender: 'female' as const,
    lookingFor: 'men' as const,
    bio: 'Psychologist & casual gamer. I can read your game strategy in 3 turns. Let\'s talk dreams, art, and roll some dice! 🌿',
    photoUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500&auto=format&fit=crop',
    interests: ['Psychology', 'Art', 'Yoga', 'Strategy Games', 'Tea'],
    city: 'Goa, India',
    coins: 3100,
    vipTier: 'gold' as const,
    privacy: DEFAULT_PRIVACY,
  },
];

SEED_USERS.forEach((u) => {
  const pHash = hashPassword(u.password);
  users.set(u.id, {
    ...u,
    passwordHash: pHash,
    createdAt: new Date(Date.now() - Math.random() * 1000000000).toISOString(),
    isOnline: true,
    lastSeen: 'Just now',
  });
  tokensToUserId.set(`token-${u.id}`, u.id);
});

// Seed an initial mutual match & friendship between Maya and Arjun
const seedMatchId = 'match-user-arjun-user-maya';
matches.set(seedMatchId, {
  id: seedMatchId,
  users: ['user-maya', 'user-arjun'],
  otherUser: users.get('user-arjun')!,
  matchedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
  lastMessage: 'Ready for our 1-on-1 Ludo match tonight? 🎲',
  lastMessageTime: new Date(Date.now() - 3600000).toISOString(),
});

friendships.set('user-maya:user-arjun', {
  status: 'accepted',
  createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
});

if (!swipes.has('user-maya')) swipes.set('user-maya', {});
if (!swipes.has('user-arjun')) swipes.set('user-arjun', {});
swipes.get('user-maya')!['user-arjun'] = 'like';
swipes.get('user-arjun')!['user-maya'] = 'like';

// Seed initial chat messages
chatMessages.push(
  {
    id: 'msg-1',
    senderId: 'user-maya',
    recipientId: 'user-arjun',
    text: 'Hi Arjun! Loved your bio. Are you really a software engineer by day and Ludo strategist by night? 😊',
    status: 'read',
    timestamp: new Date(Date.now() - 7200000).toISOString(),
  },
  {
    id: 'msg-2',
    senderId: 'user-arjun',
    recipientId: 'user-maya',
    text: 'Guilty as charged! 😂 And I heard you never show mercy when rolling a 6.',
    status: 'read',
    timestamp: new Date(Date.now() - 5400000).toISOString(),
  },
  {
    id: 'msg-3',
    senderId: 'user-maya',
    recipientId: 'user-arjun',
    text: 'Never! Sent you a lucky rose 🌹',
    giftType: 'rose',
    status: 'read',
    timestamp: new Date(Date.now() - 4000000).toISOString(),
  },
  {
    id: 'msg-4',
    senderId: 'user-arjun',
    recipientId: 'user-maya',
    text: 'Ready for our 1-on-1 Ludo match tonight? 🎲',
    status: 'read',
    timestamp: new Date(Date.now() - 3600000).toISOString(),
  }
);

// Seed initial VIP subscription record: ₹199 original, ₹50 launch offer, no auto-renewal
subscriptions.push(
  {
    id: 'SUB-98214',
    userId: 'user-maya',
    userName: 'Maya Sharma',
    planName: 'VIP Lover Pass (6 Months) — Launch Offer',
    originalPriceInr: 199,
    finalPriceInr: 50,
    discountPercent: 75,
    duration: '6 Months',
    autoRenew: false,
    coinsGranted: 5000,
    status: 'completed',
    purchasedAt: new Date(Date.now() - 86400000 * 4).toISOString(),
  },
  {
    id: 'SUB-98215',
    userId: 'user-zara',
    userName: 'Zara Chen',
    planName: 'VIP Lover Pass (6 Months) — Launch Offer',
    originalPriceInr: 199,
    finalPriceInr: 50,
    discountPercent: 75,
    duration: '6 Months',
    autoRenew: false,
    coinsGranted: 5000,
    status: 'completed',
    purchasedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
  }
);

// Auth Middleware
function authMiddleware(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized. Please login.' });
  }
  const token = authHeader.split(' ')[1];
  const userId = tokensToUserId.get(token);
  if (!userId || !users.has(userId)) {
    return res.status(401).json({ error: 'Session expired or invalid token.' });
  }
  const user = users.get(userId)!;
  if (user.isBanned) {
    return res.status(403).json({ error: 'Account suspended for policy violation.' });
  }
  (req as unknown as { user: User }).user = user;
  next();
}

// -------------------------------------------------------------
// REST API ROUTES
// -------------------------------------------------------------

// 1. Auth & Profiles
app.post('/api/auth/register', (req: Request, res: Response) => {
  const { username, email, password, age, gender, lookingFor, bio, photoUrl, interests, city } = req.body;

  if (!username || !email || !password || age === undefined) {
    return res.status(400).json({ error: 'Please provide all required fields.' });
  }

  const numericAge = parseInt(age, 10);
  if (isNaN(numericAge) || numericAge < 18) {
    return res.status(400).json({
      error: 'Age verification failed: You must be at least 18 years old to join Ludo Dating App.',
    });
  }

  const existing = Array.from(users.values()).find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    return res.status(400).json({ error: 'Email already registered.' });
  }

  const newId = `user-${Date.now()}`;
  const newUser: User & { passwordHash: string } = {
    id: newId,
    username: username.trim(),
    email: email.trim().toLowerCase(),
    passwordHash: hashPassword(password),
    age: numericAge,
    gender: gender || 'female',
    lookingFor: lookingFor || 'everyone',
    bio: bio || 'Excited to play classic Ludo and meet romantic matches! 🎲❤️',
    photoUrl: photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop',
    interests: Array.isArray(interests) && interests.length ? interests : ['Ludo Lover', 'Coffee', 'Music'],
    city: city || 'Mumbai, India',
    coins: 1000,
    vipTier: 'none',
    createdAt: new Date().toISOString(),
    isOnline: true,
    lastSeen: 'Just now',
    privacy: DEFAULT_PRIVACY,
  };

  users.set(newId, newUser);
  const token = `token-${newId}-${crypto.randomBytes(8).toString('hex')}`;
  tokensToUserId.set(token, newId);

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { passwordHash: _, ...safeUser } = newUser;
  return res.json({ token, user: safeUser });
});

app.post('/api/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Please enter email and password.' });
  }

  const user = Array.from(users.values()).find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (!user || user.passwordHash !== hashPassword(password)) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  if (user.isBanned) {
    return res.status(403).json({ error: 'Your account has been suspended.' });
  }

  user.isOnline = true;
  user.lastSeen = 'Just now';

  const token = `token-${user.id}-${crypto.randomBytes(8).toString('hex')}`;
  tokensToUserId.set(token, user.id);

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { passwordHash: _, ...safeUser } = user;
  return res.json({ token, user: safeUser });
});

app.post('/api/auth/quick-switch', (req: Request, res: Response) => {
  const { userId } = req.body;
  if (!userId || !users.has(userId)) {
    return res.status(400).json({ error: 'User not found.' });
  }
  const user = users.get(userId)!;
  user.isOnline = true;
  user.lastSeen = 'Just now';

  const token = `token-${user.id}-${crypto.randomBytes(8).toString('hex')}`;
  tokensToUserId.set(token, user.id);

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { passwordHash: _, ...safeUser } = user;
  return res.json({ token, user: safeUser });
});

app.get('/api/auth/me', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  return res.json({ user: curUser });
});

app.get('/api/auth/seed-users', (_req: Request, res: Response) => {
  const list = SEED_USERS.map((u) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { password: _, ...rest } = u;
    return rest;
  });
  return res.json({ users: list });
});

// Update Profile & Privacy
app.post('/api/profile/update', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  const { username, bio, photoUrl, interests, city, lookingFor, privacy } = req.body;

  const dbUser = users.get(curUser.id);
  if (!dbUser) return res.status(404).json({ error: 'User not found.' });

  if (username) dbUser.username = username.trim();
  if (bio !== undefined) dbUser.bio = bio;
  if (photoUrl) dbUser.photoUrl = photoUrl;
  if (Array.isArray(interests)) dbUser.interests = interests;
  if (city) dbUser.city = city;
  if (lookingFor) dbUser.lookingFor = lookingFor;
  if (privacy) dbUser.privacy = { ...dbUser.privacy, ...privacy };

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { passwordHash: _, ...safeUser } = dbUser;
  return res.json({ user: safeUser });
});

// 2. Dating Discovery & Swiping
app.get('/api/users/discover', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  const userSwipes = swipes.get(curUser.id) || {};
  const userBlocked = blockedUsers.get(curUser.id) || new Set();

  const profiles: DatingProfile[] = Array.from(users.values())
    .filter((u) => u.id !== curUser.id && !u.isBanned && !userBlocked.has(u.id))
    .filter((u) => u.privacy.profileVisibility !== 'hidden')
    .filter((u) => !userSwipes[u.id])
    .map((u, idx) => {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { passwordHash: _, ...safe } = u;
      return {
        ...safe,
        distanceKm: 3 + ((idx * 7) % 25),
        ludoWins: 12 + ((idx * 9) % 40),
        ludoGames: 20 + ((idx * 14) % 60),
        matchCompatibility: 82 + ((idx * 6) % 17),
      };
    });

  if (profiles.length === 0) {
    const allEligible = Array.from(users.values())
      .filter((u) => u.id !== curUser.id && !u.isBanned && !userBlocked.has(u.id))
      .map((u, idx) => {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { passwordHash: _, ...safe } = u;
        return {
          ...safe,
          distanceKm: 4 + idx * 3,
          ludoWins: 15 + idx * 5,
          ludoGames: 25 + idx * 8,
          matchCompatibility: 88,
        };
      });
    return res.json({ profiles: allEligible });
  }

  return res.json({ profiles });
});

app.post('/api/dating/swipe', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  const { targetUserId, action } = req.body;

  if (!targetUserId || !['like', 'pass'].includes(action)) {
    return res.status(400).json({ error: 'Invalid swipe parameters.' });
  }

  if (!swipes.has(curUser.id)) swipes.set(curUser.id, {});
  swipes.get(curUser.id)![targetUserId] = action;

  let isMatch = false;
  let matchObj: Match | null = null;

  if (action === 'like') {
    const targetSwipes = swipes.get(targetUserId);
    const targetUser = users.get(targetUserId);

    const isTargetLiked = targetSwipes?.[curUser.id] === 'like' || targetUserId.startsWith('user-');
    if (isTargetLiked && targetUser) {
      isMatch = true;
      const matchId = `match-${[curUser.id, targetUserId].sort().join('-')}`;
      matchObj = {
        id: matchId,
        users: [curUser.id, targetUserId],
        otherUser: targetUser,
        matchedAt: new Date().toISOString(),
        lastMessage: 'You matched! Play Ludo together to break the ice 🎲',
        lastMessageTime: new Date().toISOString(),
      };
      matches.set(matchId, matchObj);
    }
  }

  return res.json({ success: true, isMatch, match: matchObj });
});

app.get('/api/dating/matches', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  const userMatches: Match[] = [];

  matches.forEach((m) => {
    if (m.users.includes(curUser.id)) {
      const otherId = m.users.find((id) => id !== curUser.id)!;
      const otherUser = users.get(otherId);
      if (otherUser && !otherUser.isBanned) {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { passwordHash: _, ...safeOther } = otherUser;
        userMatches.push({
          ...m,
          otherUser: safeOther,
        });
      }
    }
  });

  return res.json({ matches: userMatches });
});

// 3. Online Friends System
app.get('/api/friends/list', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  const acceptedFriends: (User & { isFriend: boolean })[] = [];
  const pendingIncoming: { id: string; fromUser: User; createdAt: string }[] = [];
  const pendingOutgoing: { id: string; toUser: User; createdAt: string }[] = [];

  friendships.forEach((val, key) => {
    const [u1, u2] = key.split(':');
    if (val.status === 'accepted') {
      if (u1 === curUser.id || u2 === curUser.id) {
        const otherId = u1 === curUser.id ? u2 : u1;
        const other = users.get(otherId);
        if (other && !other.isBanned) {
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          const { passwordHash: _, ...safe } = other;
          acceptedFriends.push({ ...safe, isFriend: true });
        }
      }
    } else if (val.status === 'pending') {
      if (u2 === curUser.id) {
        const fromU = users.get(u1);
        if (fromU) {
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          const { passwordHash: _, ...safe } = fromU;
          pendingIncoming.push({ id: key, fromUser: safe, createdAt: val.createdAt });
        }
      } else if (u1 === curUser.id) {
        const toU = users.get(u2);
        if (toU) {
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          const { passwordHash: _, ...safe } = toU;
          pendingOutgoing.push({ id: key, toUser: safe, createdAt: val.createdAt });
        }
      }
    }
  });

  return res.json({
    friends: acceptedFriends,
    pendingIncoming,
    pendingOutgoing,
  });
});

app.post('/api/friends/request', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  const { targetUserId } = req.body;

  if (!targetUserId || !users.has(targetUserId)) {
    return res.status(404).json({ error: 'Target user not found.' });
  }

  const key1 = `${curUser.id}:${targetUserId}`;
  const key2 = `${targetUserId}:${curUser.id}`;

  if (friendships.has(key1) || friendships.has(key2)) {
    return res.json({ success: true, message: 'Friend request already exists or you are already friends.' });
  }

  friendships.set(key1, {
    status: 'pending',
    createdAt: new Date().toISOString(),
  });

  return res.json({ success: true, message: 'Friend request sent!' });
});

app.post('/api/friends/respond', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  const { targetUserId, action } = req.body; // 'accept' | 'reject'

  const key = `${targetUserId}:${curUser.id}`;
  const reqItem = friendships.get(key);
  if (!reqItem) {
    return res.status(404).json({ error: 'Friend request not found.' });
  }

  if (action === 'accept') {
    reqItem.status = 'accepted';
    return res.json({ success: true, message: 'Friend request accepted!' });
  } else {
    friendships.delete(key);
    return res.json({ success: true, message: 'Friend request rejected.' });
  }
});

app.post('/api/friends/cancel', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  const { targetUserId } = req.body;
  const key = `${curUser.id}:${targetUserId}`;
  friendships.delete(key);
  return res.json({ success: true, message: 'Friend request cancelled.' });
});

app.post('/api/friends/remove', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  const { targetUserId } = req.body;
  friendships.delete(`${curUser.id}:${targetUserId}`);
  friendships.delete(`${targetUserId}:${curUser.id}`);
  return res.json({ success: true, message: 'Friend removed.' });
});

// 4. Multimedia Private Messaging
app.get('/api/chat/messages/:otherUserId', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  const { otherUserId } = req.params;

  // Retrieve & mark as read
  const msgs = chatMessages.filter(
    (m) =>
      (m.senderId === curUser.id && m.recipientId === otherUserId) ||
      (m.senderId === otherUserId && m.recipientId === curUser.id)
  );

  msgs.forEach((m) => {
    if (m.recipientId === curUser.id) {
      m.status = 'read';
    }
  });

  return res.json({ messages: msgs });
});

app.post('/api/chat/send', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  const { recipientId, text, photoUrl, audioUrl, giftType, gameInviteRoomId } = req.body;

  if (!recipientId || (!text && !photoUrl && !audioUrl && !giftType && !gameInviteRoomId)) {
    return res.status(400).json({ error: 'Message cannot be empty.' });
  }

  const recipient = users.get(recipientId);
  if (!recipient) {
    return res.status(404).json({ error: 'Recipient not found.' });
  }

  // Safety check: is sender blocked by recipient?
  const recBlocked = blockedUsers.get(recipientId);
  if (recBlocked?.has(curUser.id)) {
    return res.status(403).json({ error: 'Unable to send message to this user.' });
  }

  // Privacy check: who can send messages?
  const isMatch = matches.has(`match-${[curUser.id, recipientId].sort().join('-')}`);
  const isFriend = friendships.get(`${curUser.id}:${recipientId}`)?.status === 'accepted' ||
                   friendships.get(`${recipientId}:${curUser.id}`)?.status === 'accepted';

  if (recipient.privacy.allowMessagesFrom === 'friends_only' && !isFriend) {
    return res.status(403).json({ error: `${recipient.username} only accepts messages from friends.` });
  }
  if (recipient.privacy.allowMessagesFrom === 'matches_only' && !isMatch && !isFriend) {
    return res.status(403).json({ error: `${recipient.username} only accepts messages from mutual matches.` });
  }

  // Deduct virtual coins if virtual gift
  const GIFT_COSTS: Record<string, number> = {
    rose: 50,
    chocolate: 100,
    letter: 150,
    ring: 500,
  };

  const dbSender = users.get(curUser.id);
  if (giftType && GIFT_COSTS[giftType]) {
    const cost = GIFT_COSTS[giftType];
    if (!dbSender || dbSender.coins < cost) {
      return res.status(400).json({ error: `Not enough virtual coins! Gift costs ${cost} coins.` });
    }
    dbSender.coins -= cost;
  }

  const newMsg: ChatMessage = {
    id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    senderId: curUser.id,
    recipientId,
    text: text || '',
    photoUrl,
    audioUrl,
    giftType,
    gameInviteRoomId,
    status: 'delivered',
    timestamp: new Date().toISOString(),
  };

  chatMessages.push(newMsg);

  // Update match last message preview
  const matchId = `match-${[curUser.id, recipientId].sort().join('-')}`;
  const match = matches.get(matchId);
  if (match) {
    match.lastMessage = giftType
      ? `Sent a virtual ${giftType} 🎁`
      : photoUrl
      ? '📷 Sent a photo'
      : audioUrl
      ? '🎙️ Sent a voice message'
      : text || 'Invited you to play Ludo!';
    match.lastMessageTime = newMsg.timestamp;
  }

  return res.json({
    message: newMsg,
    remainingCoins: dbSender?.coins,
  });
});

app.delete('/api/chat/messages/:messageId', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  const { messageId } = req.params;

  const idx = chatMessages.findIndex((m) => m.id === messageId && m.senderId === curUser.id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Message not found or unauthorized to delete.' });
  }

  chatMessages.splice(idx, 1);
  return res.json({ success: true, message: 'Message deleted.' });
});

// 5. Calls & Call History
app.get('/api/calls/history', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  const history = callHistory.filter((c) => c.callerId === curUser.id || c.receiverId === curUser.id);
  return res.json({ history });
});

// 6. Safety: Block & Report
app.post('/api/safety/report', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  const { targetUserId, reason, details } = req.body;

  const target = users.get(targetUserId);
  if (!target) return res.status(404).json({ error: 'Target user not found.' });

  const newReport: ReportItem = {
    id: `REP-${Date.now().toString().slice(-5)}`,
    reporterId: curUser.id,
    reporterName: curUser.username,
    targetUserId,
    targetUserName: target.username,
    reason: reason || 'Inappropriate behavior',
    details: details || '',
    timestamp: new Date().toISOString(),
    status: 'pending',
  };

  reports.push(newReport);
  return res.json({ success: true, message: 'Report submitted. Our moderation team will review it.' });
});

app.post('/api/safety/block', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  const { targetUserId } = req.body;

  if (!blockedUsers.has(curUser.id)) {
    blockedUsers.set(curUser.id, new Set());
  }
  blockedUsers.get(curUser.id)!.add(targetUserId);

  return res.json({ success: true, message: 'User blocked successfully.' });
});

// 7. VIP Membership (₹199 crossed out, ₹50 Launch Offer, No Auto-Renewal)
const VIP_LAUNCH_PLAN = {
  id: 'vip-launch-6m',
  name: 'VIP Lover Pass (6 Months)',
  originalPriceInr: 199,
  discountPercent: 75,
  finalPriceInr: 50,
  duration: '6 Months',
  billingNote: 'One-time payment · No automatic renewal',
  promotionTag: 'Special Launch Promotion (75% OFF)',
  coinsGranted: 5000,
  features: [
    '6 Months full VIP membership access',
    'VIP Golden Crown profile badge',
    'Unlimited discovery swipes & match priority',
    '+5,000 Virtual dating gift coins',
    'Exclusive couple room themes & animations',
    'Zero auto-renew: No recurring surprises',
  ],
};

app.get('/api/subscriptions/plans', (_req: Request, res: Response) => {
  return res.json({ plan: VIP_LAUNCH_PLAN });
});

app.post('/api/subscriptions/subscribe', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  const dbUser = users.get(curUser.id);
  if (!dbUser) return res.status(404).json({ error: 'User not found.' });

  dbUser.vipTier = 'gold';
  dbUser.coins += VIP_LAUNCH_PLAN.coinsGranted;

  const newSubRecord: SubscriptionRecord = {
    id: `SUB-${Math.floor(100000 + Math.random() * 900000)}`,
    userId: curUser.id,
    userName: curUser.username,
    planName: VIP_LAUNCH_PLAN.name,
    originalPriceInr: VIP_LAUNCH_PLAN.originalPriceInr,
    finalPriceInr: VIP_LAUNCH_PLAN.finalPriceInr,
    discountPercent: VIP_LAUNCH_PLAN.discountPercent,
    duration: VIP_LAUNCH_PLAN.duration,
    autoRenew: false,
    coinsGranted: VIP_LAUNCH_PLAN.coinsGranted,
    status: 'completed',
    purchasedAt: new Date().toISOString(),
  };

  subscriptions.unshift(newSubRecord);

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { passwordHash: _, ...safeUser } = dbUser;
  return res.json({
    success: true,
    user: safeUser,
    subscription: newSubRecord,
    message: `🎉 Congratulations! VIP Pass (6 Months) activated at launch price ₹50 (75% OFF). ${VIP_LAUNCH_PLAN.coinsGranted} virtual coins added!`,
  });
});

// 8. Admin Dashboard
app.get('/api/admin/stats', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  if (!curUser.isAdmin) {
    return res.status(403).json({ error: 'Admin access required.' });
  }

  const totalUsers = users.size;
  const activeReports = reports.filter((r) => r.status === 'pending').length;
  const totalRevenueInr = subscriptions.reduce((acc, s) => acc + (s.finalPriceInr || 50), 0);

  return res.json({
    totalUsers,
    activeReports,
    totalRevenue: totalRevenueInr,
    subscriptionsCount: subscriptions.length,
    usersList: Array.from(users.values()).map((u) => {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { passwordHash: _, ...safe } = u;
      return safe;
    }),
  });
});

app.get('/api/admin/reports', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  if (!curUser.isAdmin) return res.status(403).json({ error: 'Admin access required.' });
  return res.json({ reports });
});

app.post('/api/admin/reports/resolve', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  if (!curUser.isAdmin) return res.status(403).json({ error: 'Admin access required.' });
  const { reportId, action } = req.body;
  const rep = reports.find((r) => r.id === reportId);
  if (!rep) return res.status(404).json({ error: 'Report not found.' });

  if (action === 'ban') {
    const target = users.get(rep.targetUserId);
    if (target) target.isBanned = true;
    rep.status = 'resolved';
  } else {
    rep.status = 'dismissed';
  }

  return res.json({ success: true, report: rep });
});

app.get('/api/admin/subscriptions', authMiddleware, (req: Request, res: Response) => {
  const curUser = (req as unknown as { user: User }).user;
  if (!curUser.isAdmin) return res.status(403).json({ error: 'Admin access required.' });
  return res.json({ subscriptions });
});

// 9. Source Code ZIP Download with AdmZip
app.get('/api/download-zip', (_req: Request, res: Response) => {
  try {
    const zip = new AdmZip();
    zip.addLocalFolder(path.join(__dirname, 'src'), 'src');

    const rootFiles = [
      'package.json',
      'tsconfig.json',
      'vite.config.ts',
      'index.html',
      'metadata.json',
      '.env.example',
      'server.ts',
      'capacitor.config.json',
    ];

    for (const f of rootFiles) {
      try {
        const fullPath = path.join(__dirname, f);
        zip.addLocalFile(fullPath);
      } catch {
        // Continue
      }
    }

    const readmeContent = `# Ludo Dating App ❤️
A complete, mobile-first Ludo Dating application with 2–4 player tournament board logic, 18+ profile matchmaking, direct messaging with photos/voice, 1-on-1 WebRTC voice and video calls, WebSockets online rooms, PWA installability, and an administrative dashboard.

## VIP Membership Launch Pricing
- Original Price: ₹199 for 6 months
- Launch Discount: 75% OFF
- Offer Price: ₹50 for 6 months
- Terms: One-time payment (No auto-renewal or recurring charges)

## How to Run Locally
1. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`
2. Run development server:
   \`\`\`bash
   npm run dev
   \`\`\`
3. Open in your browser:
   \`\`\`
   http://localhost:3000
   \`\`\`

## How to Build Android APK with Capacitor
1. Install Capacitor CLI:
   \`\`\`bash
   npm install @capacitor/core @capacitor/cli @capacitor/android
   \`\`\`
2. Initialize Capacitor:
   \`\`\`bash
   npx cap init "Ludo Dating App" "com.ludodating.app" --web-dir dist
   \`\`\`
3. Build web assets:
   \`\`\`bash
   npm run build
   \`\`\`
4. Add Android platform:
   \`\`\`bash
   npx cap add android
   npx cap sync android
   \`\`\`
5. Open in Android Studio & Generate APK:
   \`\`\`bash
   npx cap open android
   \`\`\`
   In Android Studio, click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
`;
    zip.addFile('README.md', Buffer.from(readmeContent, 'utf8'));

    const buffer = zip.toBuffer();
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="ludo-dating-app-source.zip"');
    res.setHeader('Content-Length', buffer.length);
    return res.end(buffer);
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    return res.status(500).json({ error: errorMsg });
  }
});

// =============================================================
// REAL-TIME WEBSOCKET: ROOMS, ONLINE PRESENCE & WEBRTC CALLS
// =============================================================

interface RoomSession {
  code: string;
  hostUserId: string;
  playerCount: 2 | 3 | 4;
  isPrivate: boolean;
  isDatingCoupleRoom: boolean;
  clients: Map<string, { ws: WebSocket; user: User; color: PlayerColor }>;
  gameState: GameState;
  turnTimer: NodeJS.Timeout | null;
}

const activeRooms: Map<string, RoomSession> = new Map();
const userSockets: Map<string, WebSocket> = new Map(); // userId -> active WebSocket

function broadcastToRoom(room: RoomSession, message: object) {
  const payload = JSON.stringify(message);
  room.clients.forEach(({ ws }) => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(payload);
    }
  });
}

function stopRoomTimer(room: RoomSession) {
  if (room.turnTimer) {
    clearInterval(room.turnTimer);
    room.turnTimer = null;
  }
}

function startRoomTurnTimer(room: RoomSession) {
  stopRoomTimer(room);
  room.gameState.turnTimeLeft = 30;

  room.turnTimer = setInterval(() => {
    if (room.gameState.status !== 'playing') {
      stopRoomTimer(room);
      return;
    }

    room.gameState.turnTimeLeft -= 1;

    if (room.gameState.turnTimeLeft <= 0) {
      const curPlayer = room.gameState.players[room.gameState.currentTurnIndex];
      room.gameState.lastActionLog = `${curPlayer.name} ran out of time! Turn skipped.`;

      if (!room.gameState.hasRolled) {
        room.gameState.currentTurnIndex = (room.gameState.currentTurnIndex + 1) % room.gameState.players.length;
        room.gameState.hasRolled = false;
        room.gameState.diceValue = null;
        room.gameState.validTokenMoves = [];
        room.gameState.turnTimeLeft = 30;
      } else if (room.gameState.validTokenMoves.length > 0) {
        const tokenIdx = room.gameState.validTokenMoves[0];
        const { newState } = executeMove(room.gameState, tokenIdx);
        room.gameState = newState;
      } else {
        room.gameState.currentTurnIndex = (room.gameState.currentTurnIndex + 1) % room.gameState.players.length;
        room.gameState.hasRolled = false;
        room.gameState.diceValue = null;
        room.gameState.validTokenMoves = [];
        room.gameState.turnTimeLeft = 30;
      }

      broadcastToRoom(room, {
        type: 'game:state',
        gameState: room.gameState,
      });

      checkAndRunBotTurn(room);
    } else {
      broadcastToRoom(room, {
        type: 'game:tick',
        timeLeft: room.gameState.turnTimeLeft,
      });
    }
  }, 1000);
}

function checkAndRunBotTurn(room: RoomSession) {
  if (room.gameState.status !== 'playing') return;
  const curPlayer = room.gameState.players[room.gameState.currentTurnIndex];

  if (curPlayer && curPlayer.isBot) {
    setTimeout(() => {
      if (room.gameState.status !== 'playing') return;
      const dice = Math.floor(Math.random() * 6) + 1;
      room.gameState.diceValue = dice;
      room.gameState.hasRolled = true;

      const validMoves = getValidTokenMoves(curPlayer, dice);
      room.gameState.validTokenMoves = validMoves;

      broadcastToRoom(room, {
        type: 'game:dice_rolled',
        playerIndex: room.gameState.currentTurnIndex,
        dice,
        validMoves,
        gameState: room.gameState,
      });

      if (validMoves.length === 0) {
        setTimeout(() => {
          if (room.gameState.status !== 'playing') return;
          room.gameState.currentTurnIndex = (room.gameState.currentTurnIndex + 1) % room.gameState.players.length;
          room.gameState.hasRolled = false;
          room.gameState.diceValue = null;
          room.gameState.validTokenMoves = [];
          room.gameState.turnTimeLeft = 30;

          broadcastToRoom(room, {
            type: 'game:state',
            gameState: room.gameState,
          });
          checkAndRunBotTurn(room);
        }, 1200);
      } else {
        setTimeout(() => {
          if (room.gameState.status !== 'playing') return;
          const chosenIdx = chooseBestBotMove(room.gameState, validMoves);
          const { newState } = executeMove(room.gameState, chosenIdx);
          room.gameState = newState;

          broadcastToRoom(room, {
            type: 'game:token_moved',
            tokenIndex: chosenIdx,
            gameState: room.gameState,
          });

          if (room.gameState.status === 'playing') {
            checkAndRunBotTurn(room);
          }
        }, 1200);
      }
    }, 1000);
  }
}

wss.on('connection', (ws: WebSocket) => {
  let boundUserId: string | null = null;
  let currentRoomCode: string | null = null;

  ws.on('message', (data: string) => {
    try {
      const msg = JSON.parse(data.toString());

      switch (msg.type) {
        case 'auth': {
          const { token } = msg;
          const uId = tokensToUserId.get(token);
          if (uId && users.has(uId)) {
            boundUserId = uId;
            userSockets.set(uId, ws);
            const user = users.get(uId)!;
            user.isOnline = true;
            user.lastSeen = 'Just now';
            ws.send(JSON.stringify({ type: 'auth:success', userId: uId }));
          }
          break;
        }

        // 1-on-1 Voice and Video Call Signaling
        case 'call:initiate': {
          const { receiverId, callType } = msg;
          const caller = boundUserId ? users.get(boundUserId) : null;
          const receiver = users.get(receiverId);

          if (!caller || !receiver) {
            ws.send(JSON.stringify({ type: 'call:error', message: 'User not found.' }));
            return;
          }

          // Privacy Check: Strangers cannot call without permission
          const isMatch = matches.has(`match-${[caller.id, receiver.id].sort().join('-')}`);
          const isFriend = friendships.get(`${caller.id}:${receiver.id}`)?.status === 'accepted' ||
                           friendships.get(`${receiver.id}:${caller.id}`)?.status === 'accepted';

          if (receiver.privacy.allowCallsFrom === 'friends_only' && !isFriend) {
            ws.send(JSON.stringify({ type: 'call:rejected', reason: `${receiver.username} only accepts calls from friends.` }));
            return;
          }
          if (receiver.privacy.allowCallsFrom === 'friends_and_matches' && !isFriend && !isMatch) {
            ws.send(JSON.stringify({ type: 'call:rejected', reason: `${receiver.username} does not accept calls from strangers.` }));
            return;
          }

          const receiverWs = userSockets.get(receiverId);
          if (!receiverWs || receiverWs.readyState !== WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: 'call:rejected', reason: `${receiver.username} is currently offline.` }));
            return;
          }

          const callId = `call-${Date.now()}`;
          // Send incoming call prompt to receiver
          receiverWs.send(
            JSON.stringify({
              type: 'call:incoming',
              callId,
              caller: {
                id: caller.id,
                username: caller.username,
                photoUrl: caller.photoUrl,
              },
              callType,
            })
          );

          // Notify caller that call is ringing
          ws.send(JSON.stringify({ type: 'call:ringing', callId, receiverId }));
          break;
        }

        case 'call:accept': {
          const { callId, callerId } = msg;
          const callerWs = userSockets.get(callerId);
          if (callerWs && callerWs.readyState === WebSocket.OPEN) {
            callerWs.send(JSON.stringify({ type: 'call:accepted', callId, receiverId: boundUserId }));
          }
          break;
        }

        case 'call:reject': {
          const { callerId, reason } = msg;
          const callerWs = userSockets.get(callerId);
          if (callerWs && callerWs.readyState === WebSocket.OPEN) {
            callerWs.send(JSON.stringify({ type: 'call:rejected', reason: reason || 'Call declined' }));
          }
          break;
        }

        case 'call:hangup': {
          const { otherUserId, callType, durationSeconds } = msg;
          const otherWs = userSockets.get(otherUserId);
          if (otherWs && otherWs.readyState === WebSocket.OPEN) {
            otherWs.send(JSON.stringify({ type: 'call:ended' }));
          }

          if (boundUserId && otherUserId) {
            const u1 = users.get(boundUserId);
            const u2 = users.get(otherUserId);
            if (u1 && u2) {
              callHistory.unshift({
                id: `CALL-${Date.now()}`,
                callerId: u1.id,
                callerName: u1.username,
                callerAvatar: u1.photoUrl,
                receiverId: u2.id,
                receiverName: u2.username,
                receiverAvatar: u2.photoUrl,
                callType: callType || 'voice',
                status: durationSeconds > 0 ? 'completed' : 'missed',
                durationSeconds: durationSeconds || 0,
                timestamp: new Date().toISOString(),
              });
            }
          }
          break;
        }

        case 'call:signal': {
          // Relay WebRTC offer / answer / ICE candidates
          const { targetUserId, signal } = msg;
          const targetWs = userSockets.get(targetUserId);
          if (targetWs && targetWs.readyState === WebSocket.OPEN) {
            targetWs.send(
              JSON.stringify({
                type: 'call:signal',
                fromUserId: boundUserId,
                signal,
              })
            );
          }
          break;
        }

        // Ludo Multiplayer Room Operations
        case 'room:create': {
          const { playerCount = 2, isCoupleRoom = false, token, customCode } = msg;
          const userId = tokensToUserId.get(token) || boundUserId || `guest-${Date.now()}`;
          const user = users.get(userId) || {
            id: userId,
            username: 'Player 1',
            email: '',
            age: 21,
            gender: 'female' as const,
            lookingFor: 'everyone' as const,
            bio: '',
            photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
            interests: [],
            city: '',
            coins: 1000,
            vipTier: 'none' as const,
            createdAt: '',
            privacy: DEFAULT_PRIVACY,
          };

          const roomCode = customCode?.toUpperCase() || Math.random().toString(36).slice(2, 7).toUpperCase();

          const colors: PlayerColor[] =
            playerCount === 2
              ? ['red', 'yellow']
              : playerCount === 3
              ? ['red', 'green', 'yellow']
              : ['red', 'green', 'yellow', 'blue'];

          const hostPlayer: LudoPlayer = {
            id: user.id,
            name: user.username,
            avatar: user.photoUrl,
            color: colors[0],
            isBot: false,
            isHost: true,
            tokens: createTokens(colors[0]),
          };

          const initialPlayers: LudoPlayer[] = [hostPlayer];

          for (let i = 1; i < playerCount; i++) {
            const botNames = ['Cupid', 'Sweetheart', 'Valentine'];
            const botAvatars = [
              'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150',
              'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
              'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
            ];
            initialPlayers.push({
              id: `slot-${i}`,
              name: `Open Slot (or ${botNames[i - 1]} Bot)`,
              avatar: botAvatars[i - 1],
              color: colors[i],
              isBot: true,
              tokens: createTokens(colors[i]),
            });
          }

          const gameState: GameState = {
            roomId: roomCode,
            mode: 'online',
            playerCount: playerCount as 2 | 3 | 4,
            players: initialPlayers,
            currentTurnIndex: 0,
            diceValue: null,
            hasRolled: false,
            validTokenMoves: [],
            status: 'waiting',
            turnTimeLeft: 30,
            turnDuration: 30,
            lastActionLog: `Room ${roomCode} created by ${user.username}. Waiting for players or click Start!`,
            consecutiveSixes: 0,
            moveHistory: [],
          };

          const newRoom: RoomSession = {
            code: roomCode,
            hostUserId: user.id,
            playerCount: playerCount as 2 | 3 | 4,
            isPrivate: true,
            isDatingCoupleRoom: Boolean(isCoupleRoom),
            clients: new Map(),
            gameState,
            turnTimer: null,
          };

          newRoom.clients.set(user.id, { ws, user, color: colors[0] });
          activeRooms.set(roomCode, newRoom);
          currentRoomCode = roomCode;

          ws.send(
            JSON.stringify({
              type: 'room:joined',
              roomCode,
              isHost: true,
              playerColor: colors[0],
              gameState,
            })
          );
          break;
        }

        case 'room:join': {
          const { roomCode, token } = msg;
          const upperCode = roomCode?.trim().toUpperCase();
          const room = activeRooms.get(upperCode);

          if (!room) {
            ws.send(JSON.stringify({ type: 'room:error', message: 'Room not found. Check code.' }));
            return;
          }

          const userId = tokensToUserId.get(token) || boundUserId || `guest-${Date.now()}`;
          const user = users.get(userId) || {
            id: userId,
            username: 'Player ' + (room.clients.size + 1),
            email: '',
            age: 22,
            gender: 'female' as const,
            lookingFor: 'everyone' as const,
            bio: '',
            photoUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150',
            interests: [],
            city: '',
            coins: 1000,
            vipTier: 'none' as const,
            createdAt: '',
            privacy: DEFAULT_PRIVACY,
          };

          // Disconnection Rejoin Support: if user was in room, reconnect them
          const existingClient = room.clients.get(user.id);
          let assignedColor: PlayerColor;

          if (existingClient) {
            assignedColor = existingClient.color;
            existingClient.ws = ws;
          } else {
            const emptyIdx = room.gameState.players.findIndex((p) => p.isBot || p.id.startsWith('slot-'));
            if (emptyIdx === -1 && room.clients.size >= room.playerCount) {
              ws.send(JSON.stringify({ type: 'room:error', message: 'Room is full.' }));
              return;
            }

            const targetIdx = emptyIdx !== -1 ? emptyIdx : room.clients.size;
            assignedColor = room.gameState.players[targetIdx].color;

            room.gameState.players[targetIdx] = {
              id: user.id,
              name: user.username,
              avatar: user.photoUrl,
              color: assignedColor,
              isBot: false,
              isHost: false,
              tokens: createTokens(assignedColor),
            };

            room.clients.set(user.id, { ws, user, color: assignedColor });
          }

          currentRoomCode = upperCode;

          ws.send(
            JSON.stringify({
              type: 'room:joined',
              roomCode: upperCode,
              isHost: room.hostUserId === user.id,
              playerColor: assignedColor,
              gameState: room.gameState,
            })
          );

          broadcastToRoom(room, {
            type: 'room:player_joined',
            user: { id: user.id, username: user.username, photoUrl: user.photoUrl },
            color: assignedColor,
            gameState: room.gameState,
          });
          break;
        }

        case 'room:start': {
          if (!currentRoomCode) return;
          const room = activeRooms.get(currentRoomCode);
          if (!room) return;

          room.gameState.status = 'playing';
          room.gameState.lastActionLog = 'Game started! ' + room.gameState.players[0].name + ' rolls first.';
          room.gameState.turnTimeLeft = 30;

          broadcastToRoom(room, {
            type: 'game:started',
            gameState: room.gameState,
          });

          startRoomTurnTimer(room);
          checkAndRunBotTurn(room);
          break;
        }

        case 'game:roll': {
          if (!currentRoomCode) return;
          const room = activeRooms.get(currentRoomCode);
          if (!room || room.gameState.status !== 'playing') return;

          const curPlayer = room.gameState.players[room.gameState.currentTurnIndex];
          if (room.gameState.hasRolled) return;

          const dice = Math.floor(Math.random() * 6) + 1;
          room.gameState.diceValue = dice;
          room.gameState.hasRolled = true;

          const validMoves = getValidTokenMoves(curPlayer, dice);
          room.gameState.validTokenMoves = validMoves;
          room.gameState.lastActionLog = `${curPlayer.name} rolled a ${dice}!`;

          broadcastToRoom(room, {
            type: 'game:dice_rolled',
            playerIndex: room.gameState.currentTurnIndex,
            dice,
            validMoves,
            gameState: room.gameState,
          });

          if (validMoves.length === 0) {
            setTimeout(() => {
              if (room.gameState.status !== 'playing') return;
              room.gameState.currentTurnIndex = (room.gameState.currentTurnIndex + 1) % room.gameState.players.length;
              room.gameState.hasRolled = false;
              room.gameState.diceValue = null;
              room.gameState.validTokenMoves = [];
              room.gameState.turnTimeLeft = 30;

              broadcastToRoom(room, {
                type: 'game:state',
                gameState: room.gameState,
              });

              checkAndRunBotTurn(room);
            }, 1500);
          }
          break;
        }

        case 'game:move': {
          if (!currentRoomCode) return;
          const room = activeRooms.get(currentRoomCode);
          if (!room || room.gameState.status !== 'playing') return;

          const { tokenIndex } = msg;
          if (!room.gameState.validTokenMoves.includes(tokenIndex)) return;

          const { newState, result } = executeMove(room.gameState, tokenIndex);
          room.gameState = newState;

          broadcastToRoom(room, {
            type: 'game:token_moved',
            tokenIndex,
            result,
            gameState: room.gameState,
          });

          if (result.gameOver) {
            stopRoomTimer(room);
          } else {
            startRoomTurnTimer(room);
            checkAndRunBotTurn(room);
          }
          break;
        }

        case 'game:chat': {
          if (!currentRoomCode) return;
          const room = activeRooms.get(currentRoomCode);
          if (!room) return;

          broadcastToRoom(room, {
            type: 'game:chat_message',
            sender: msg.senderName || 'Player',
            text: msg.text,
            emoji: msg.emoji,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          });
          break;
        }

        case 'game:reaction': {
          if (!currentRoomCode) return;
          const room = activeRooms.get(currentRoomCode);
          if (!room) return;

          broadcastToRoom(room, {
            type: 'game:reaction_received',
            sender: msg.senderName || 'Player',
            emoji: msg.emoji,
          });
          break;
        }

        // Room in-game voice chat signaling
        case 'voice:signal': {
          if (!currentRoomCode) return;
          const room = activeRooms.get(currentRoomCode);
          if (!room) return;

          room.clients.forEach(({ ws: peerWs, user }) => {
            if (peerWs !== ws && peerWs.readyState === WebSocket.OPEN) {
              peerWs.send(
                JSON.stringify({
                  type: 'voice:signal',
                  fromUserId: boundUserId || 'peer',
                  fromUserName: user.username,
                  signal: msg.signal,
                  isSpeaking: msg.isSpeaking,
                  isMuted: msg.isMuted,
                })
              );
            }
          });
          break;
        }

        default:
          break;
      }
    } catch (err) {
      console.error('WS Message parsing error:', err);
    }
  });

  ws.on('close', () => {
    if (boundUserId) {
      userSockets.delete(boundUserId);
      const user = users.get(boundUserId);
      if (user) {
        user.isOnline = false;
        user.lastSeen = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      }
    }

    if (currentRoomCode) {
      const room = activeRooms.get(currentRoomCode);
      if (room && boundUserId) {
        // Keep in room state for rejoining, just update connection
        if (room.clients.size === 0) {
          stopRoomTimer(room);
          activeRooms.delete(currentRoomCode);
        } else {
          broadcastToRoom(room, {
            type: 'room:player_disconnected',
            userId: boundUserId,
          });
        }
      }
    }
  });
});

// Vite Middleware for Dev or Static Dist for Production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  const PORT = 3000;

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Ludo Dating App full-stack server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
